import{M as Q,i as U,n as y,D as j,y as Y,c as p,e as M,I as W,f as G,o as O,m as Ue,N as Oe,H as He,S as Ke,J as je,g as De,C as x,K as Ye,O as Se,d as We,L as Ge,A as Ve}from"./config-OjKexx4c.js";function pe(n){if(n.length===0)return[];const e=[],t=n[0].length;for(let s=0;s<t;s++){let i=255,r=0;for(const a of n){const c=a[s];c<i&&(i=c),c>r&&(r=c)}const o=r-i;e.push({byteIndex:s,min:i,max:r,variance:o})}return e}function de(n,e=3,t=50){const s=n.filter(o=>o.variance>t).sort((o,a)=>a.variance-o.variance),i=[],r=new Set;if(e===1)return s.length>0?[s[0]]:[];for(let o=0;o<n.length-1;o++){const a=n[o],c=n[o+1];if(!(r.has(a.byteIndex)||r.has(c.byteIndex))&&c.byteIndex===a.byteIndex+1&&(a.variance>t||c.variance>t)&&a.variance>0&&c.variance>0&&(i.push(a),i.push(c),r.add(a.byteIndex),r.add(c.byteIndex),i.length>=2))break}if(i.length===0){for(const o of s)if(!r.has(o.byteIndex)&&(i.push(o),r.add(o.byteIndex),i.length>=e))break}return i.sort((o,a)=>o.byteIndex-a.byteIndex)}function Ie(n){return n.length===0?[]:n.map(t=>t.byteIndex).sort((t,s)=>t-s)}function Be(n,e,t=!1){if(n.length===0||e.length===0)return 0;let s=0,i=null,r=0;for(const o of e){let a=0,c=!0;for(let l=0;l<n.length;l++){const d=n[l];if(d>=o.length){c=!1;break}a+=o[d]<<l*8}c&&(r++,a>s&&(s=a,i=o))}if(t&&i){const o=n.map(a=>`[${a}]=0x${i[a].toString(16).padStart(2,"0")}`).join(", ");console.log(`  calculateMultiByteMax: indices=[${n}], max=${s}, from ${r} packets`),console.log(`    Max packet bytes: ${o}`),console.log(`    Full packet: ${Array.from(i).map(a=>a.toString(16).padStart(2,"0")).join(" ")}`)}return s>0?s:n.length===2?65535:255}function Ee(n,e){if(e.length===0)return{positiveMax:127,negativeMin:128,negativeMax:255};const t=new Set;for(const c of e)n<c.length&&t.add(c[n]);if(t.size===0)return{positiveMax:127,negativeMin:128,negativeMax:255};let s=0,i=255,r=128,o=!1,a=!1;for(const c of t)c!==0&&(c<128?(o=!0,c>s&&(s=c)):(a=!0,c<i&&(i=c),c>r&&(r=c)));return o||(s=127),a||(i=128,r=255),{positiveMax:s,negativeMin:i,negativeMax:r}}function qe(n,e){if(n.length===0)return null;const t=pe(n);for(const s of t)if(!e.has(s.byteIndex)&&s.variance>0){const i=new Set;for(const r of n)i.add(r[s.byteIndex]);if(i.size>=2&&i.size<=20)return s.byteIndex}return null}function Xe(n,e,t,s,i,r,o,a=[],c=[],l=[],d=[],u=!0){var ee,te;const f=u?0:1,h=Ie(n),g=Ie(e),v=Ie(t),b=typeof globalThis<"u"&&typeof globalThis.process<"u"&&((te=(ee=globalThis.process)==null?void 0:ee.env)==null?void 0:te.DEBUG_WALKTHROUGH)==="1";b&&(console.log(`
[DEBUG] Calculating max values from`,o.length,"packets:"),console.log(`  packetIncludesReportId: ${u}, indexOffset: ${f}`));const m=Be(h,o,b),k=Be(g,o,b),w=Be(v,o,b),C=h.map(B=>B+f),z=g.map(B=>B+f),_=v.map(B=>B+f);if(d.length>0){const B=new Set(d.map($=>$.statusByte).filter($=>$!==void 0));for(const $ of B)r.has($)||($===0?r.set(0,{state:"keyboard"}):$>=1&&$<=6?r.set($,{state:"buttons"}):$===240&&r.set(240,{state:"buttons"}))}const E={x:{byteIndex:C,max:m,type:"multi-byte-range"},y:{byteIndex:z,max:k,type:"multi-byte-range"},pressure:{byteIndex:_,max:w,type:"multi-byte-range"}};if(r.size>0){const B=new Set([...u?[0]:[],...n.map(A=>A.byteIndex),...e.map(A=>A.byteIndex),...t.map(A=>A.byteIndex),...s.map(A=>A.byteIndex),...i.map(A=>A.byteIndex)]),$=qe(o,B),T=$!==null?$+f:null;if(T!==null){const A={};r.forEach((me,P)=>{A[P.toString()]=me}),E.status={byteIndex:[T],type:"code",values:A}}}if(s.length>0){const B=s.map(A=>A.byteIndex+f),$=c.length>0?c:o,T=Ee(s[0].byteIndex,$);b&&console.log(`  Tilt X range: positiveMax=${T.positiveMax}, negativeMin=${T.negativeMin}, negativeMax=${T.negativeMax}`),E.tiltX={byteIndex:B,positiveMax:T.positiveMax,negativeMin:T.negativeMin,negativeMax:T.negativeMax,type:"bipolar-range"}}if(i.length>0){const B=i.map(A=>A.byteIndex+f),$=l.length>0?l:o,T=Ee(i[0].byteIndex,$);b&&console.log(`  Tilt Y range: positiveMax=${T.positiveMax}, negativeMin=${T.negativeMin}, negativeMax=${T.negativeMax}`),E.tiltY={byteIndex:B,positiveMax:T.positiveMax,negativeMin:T.negativeMin,negativeMax:T.negativeMax,type:"bipolar-range"}}if(d.length>0){const B=d.filter(P=>P.interfaceType!=="keyboard"),$=d.filter(P=>P.interfaceType==="keyboard"),T=B.some(P=>P.key!==void 0),A=B.some(P=>P.scanCode!==void 0),me=new Map;for(const P of B)P.key!==void 0&&me.set(P.buttonNumber,P);if(A){const P={},D=[],F=new Map;for(const L of B)if(L.scanCode!==void 0){const re=F.get(L.scanCode)||[];re.push(L),F.set(L.scanCode,re)}for(const[L,re]of F){let ve;if(re.length>1){const be=[...re].sort((ae,ye)=>ae.buttonNumber-ye.buttonNumber);ve=be[0].buttonNumber;for(let ae=1;ae<be.length;ae++){const ye=be[ae].statusByte;ye!==void 0&&D.push({scanCode:L,statusByte:ye,buttonNumber:be[ae].buttonNumber})}}else ve=re[0].buttonNumber;const oe={button:ve},J=me.get(ve);J!=null&&J.key&&(oe.key=J.key,J.ctrlKey&&(oe.ctrl=!0),J.shiftKey&&(oe.shift=!0),J.altKey&&(oe.alt=!0),J.metaKey&&(oe.meta=!0)),P[String(L)]=oe}const V={byteIndex:[2],buttonCount:B.length,type:"code",values:P};D.length>0&&(V.statusOverrides=D),E.tabletButtons=V}else if(T){const P={};for(const D of B)if(D.key){const F={key:D.key};D.ctrlKey&&(F.ctrl=!0),D.shiftKey&&(F.shift=!0),D.altKey&&(F.alt=!0),D.metaKey&&(F.meta=!0),P[String(D.buttonNumber)]=F}E.tabletButtons={byteIndex:[],buttonCount:B.length,type:"code",values:P}}if($.length>0){const P=[];for(const D of $){let F=D.reportId;F===void 0&&(D.consumerCode!==void 0?F=4:D.scrollDelta!==void 0?F=5:(D.modifier!==void 0||D.keycode,F=3));let V;F===4?V="consumer":F===5?V="scroll":V="keyboard";const L={button:D.buttonNumber,reportId:F,type:V};V==="keyboard"?(D.modifier!==void 0&&(L.modifier=D.modifier),D.keycode!==void 0&&(L.keycode=D.keycode)):V==="consumer"?D.consumerCode!==void 0&&(L.consumerCode=D.consumerCode):V==="scroll"&&D.scrollDelta!==void 0&&(L.scrollDelta=D.scrollDelta),P.push(L)}E.keyboardButtons={description:"Buttons from keyboard HID interface (requires sudo on macOS)",usagePage:1,usage:6,buttonCount:$.length,buttons:P}}}else if(a.length>0){const B=a.map($=>$.byteIndex+f);E.tabletButtons={byteIndex:B,buttonCount:8,type:"bit-flags"}}return E}function $e(n,e,t){const s={};if(n.length<1)return s;const i=Array.from(n),r=e.buttons||[],o=e.buttonCount??r.length;let a,c;t!==void 0?(a=t,c=0):(a=i[0],c=1);for(let d=1;d<=o;d++)s[`button${d}`]=!1;s.tabletButtons=0,s.button=0;let l;if(a===3){if(i.length>=c+2){const d=i[c],u=i[c+1];if(u===0)return s;for(const f of r)if(f.reportId===3&&f.type==="keyboard"&&f.modifier===d&&f.keycode===u){l=f.button;break}}}else if(a===4){if(i.length>=c+1){const d=i[c];if(d===0)return s;for(const u of r)if(u.reportId===4&&u.type==="consumer"&&u.consumerCode===d){l=u.button;break}}}else if(a===5){const d=i.length-c,u=d>5?i[c+5]:d>0?i[i.length-1]:0;if(u===0)return s;for(const f of r)if(f.reportId===5&&f.type==="scroll"&&f.scrollDelta===u){l=f.button;break}}return l!==void 0&&(s.tabletButtons=l,s.button=l,s[`button${l}`]=!0,s.state="buttons"),s}function Ze(n){const t=(n.buttons||[]).filter(r=>r.type==="keyboard"&&r.reportId===3);if(t.length===0)return null;const s={4:"KeyA",5:"KeyB",6:"KeyC",7:"KeyD",8:"KeyE",9:"KeyF",10:"KeyG",11:"KeyH",12:"KeyI",13:"KeyJ",14:"KeyK",15:"KeyL",16:"KeyM",17:"KeyN",18:"KeyO",19:"KeyP",20:"KeyQ",21:"KeyR",22:"KeyS",23:"KeyT",24:"KeyU",25:"KeyV",26:"KeyW",27:"KeyX",28:"KeyY",29:"KeyZ",30:"Digit1",31:"Digit2",32:"Digit3",33:"Digit4",34:"Digit5",35:"Digit6",36:"Digit7",37:"Digit8",38:"Digit9",39:"Digit0",40:"Enter",41:"Escape",42:"Backspace",43:"Tab",44:"Space",45:"Minus",46:"Equal",47:"BracketLeft",48:"BracketRight",49:"Backslash",51:"Semicolon",52:"Quote",53:"Backquote",54:"Comma",55:"Period",56:"Slash",57:"CapsLock",58:"F1",59:"F2",60:"F3",61:"F4",62:"F5",63:"F6",64:"F7",65:"F8",66:"F9",67:"F10",68:"F11",69:"F12",70:"PrintScreen",71:"ScrollLock",72:"Pause",73:"Insert",74:"Home",75:"PageUp",76:"Delete",77:"End",78:"PageDown",79:"ArrowRight",80:"ArrowLeft",81:"ArrowDown",82:"ArrowUp"},i=t.map(r=>{const o=[],a=[],c=r.modifier??0;c&1&&(o.push("ControlLeft"),a.push(224)),c&2&&(o.push("ShiftLeft"),a.push(225)),c&4&&(o.push("AltLeft"),a.push(226)),c&8&&(o.push("MetaLeft"),a.push(227));const l=r.keycode??0;if(l>0){a.push(l);const d=s[l];d&&o.push(d)}return{button:r.button,usageIds:a,keys:o}});return{description:n.description,note:"Auto-converted from keyboardButtons config",buttons:i}}function Je(n,e,t){if(e>=n.length)return null;const s=String(n[e]);return t[s]||s}function Qe(n,e,t,s){if(e>=n.length)return 0;const i=n[e];return t===s?0:(i-t)/(s-t)}function et(n,e,t,s,i){let r=0;for(let o=0;o<e.length;o++){const a=e[o];if(a>=n.length)return 0;r+=n[a]<<o*8}return t===s?0:(r-t)/(s-t)}function tt(n,e,t,s,i,r){if(e>=n.length)return 0;const o=n[e];return o>=t&&o<=s?s===t?0:(o-t)/(s-t):o>=i&&o<=r?r===i?0:-((r-o)/(r-i)):0}function st(n,e,t){const s={};if(e>=n.length)return s;const i=n[e];for(let r=0;r<t;r++){const o=r+1;s[`button${o}`]=(i&1<<r)!==0}return s}function ne(n,e,t=0,s){const i=Array.from(n),r={};if(!e)return r;let o=!1;t===0&&i.length>0&&(s==null?void 0:s.buttonInterfaceReportId)!==void 0&&(o=i[0]===s.buttonInterfaceReportId);let a=null,c=null;for(const[l,d]of Object.entries(e))if(d.type===Q.CODE){const u=d.byteIndex??0,h=(Array.isArray(u)?u[0]:u)+t;if(h>=0&&h<i.length){c=h;const g=Je(i,h,d.values??{});if(typeof g=="object"&&g!==null)Object.assign(r,g),a=g.state??null;else{const v=i[h];v===0||v===192?(r.state="none",a="none"):(r.state=`unknown(${v})`,r[l]=g)}break}}!a&&i.every(l=>l===0)&&(r.state="none",a="none"),a==="keyboard"&&(o=!0);for(const[l,d]of Object.entries(e)){const u=d.type,f=d.byteIndex??0,h=u===Q.MULTI_BYTE_RANGE?Array.isArray(f)?f.map(g=>g+t):[f+t]:Array.isArray(f)?f[0]+t:f+t;if(!(u===Q.CODE&&l!=="tabletButtons")){if(l==="tabletButtons"&&u===Q.CODE){let g;if(c!==null?g=i[c]:t<0&&i.length>0?g=i[0]:g=0,(o||a==="buttons"||g===240)&&h>=0&&h<i.length){const b=String(i[h]),m=d.values??{},k=d.statusOverrides;let w;if(b in m&&(w=m[b].button,k)){const C=parseInt(b,10),z=k.find(_=>_.scanCode===C&&_.statusByte===g);z&&(w=z.buttonNumber)}if(w){r.tabletButtons=w,r.button=w;const C=d.buttonCount??8;for(let z=1;z<=C;z++)r[`button${z}`]=z===w}else r.button=0,r.tabletButtons=0}continue}if(!(u===Q.BIT_FLAGS&&a!=="buttons"&&!o)&&!((o||a==="buttons")&&["x","y","pressure","tiltX","tiltY"].includes(l))){if(u==="range"){if(h<0||h>=i.length)continue;r[l]=Qe(i,h,d.min??0,d.max??0)}else if(u===Q.MULTI_BYTE_RANGE){const g=Array.isArray(h)?h:[h];g.every(v=>v>=0&&v<i.length)&&(r[l]=et(i,g,d.min??0,d.max??0))}else if(u===Q.BIPOLAR_RANGE){if(h<0||h>=i.length)continue;r[l]=tt(i,h,d.positiveMin??0,d.positiveMax??0,d.negativeMin??0,d.negativeMax??0)}else if(u===Q.BIT_FLAGS){if(h<0||h>=i.length)continue;const g=st(i,h,d.buttonCount??8);Object.assign(r,g)}}}}return r}class it{constructor(e,t,s){this.activeDevice=null,this.allConnectedDevices=[],this.onConnectCallback=e,this.onDisconnectCallback=t,this.digitizerUsagePage=(s==null?void 0:s.digitizerUsagePage)??13,this.excludedUsagePages=(s==null?void 0:s.excludedUsagePages)??[],this.autoConnect=(s==null?void 0:s.autoConnect)??!0,this.setupEventListeners()}setupEventListeners(){if(!navigator.hid){console.warn("[DeviceFinder] WebHID not supported");return}navigator.hid.addEventListener("connect",e=>{console.log("[DeviceFinder] Device connected:",e.device)}),navigator.hid.addEventListener("disconnect",e=>{console.log("[DeviceFinder] Device disconnected:",e.device),e.device===this.activeDevice&&(console.log("[DeviceFinder] Active device was disconnected"),this.activeDevice=null,this.allConnectedDevices=[],this.onDisconnectCallback&&this.onDisconnectCallback())})}isDeviceExcluded(e){return this.excludedUsagePages.length===0?!1:e.collections.some(t=>t.usagePage!==void 0&&this.excludedUsagePages.includes(t.usagePage))}async checkForExistingDevices(){try{if(!navigator.hid)return console.error("[DeviceFinder] WebHID not supported"),!1;const e=await navigator.hid.getDevices();if(e.length===0)return console.log("[DeviceFinder] No previously authorized devices"),!1;if(!this.autoConnect)return console.log("[DeviceFinder] Auto-connect disabled - user must click Connect button"),!1;console.log(`[DeviceFinder] Found ${e.length} previously authorized device interface(s)`),e.forEach((o,a)=>{const c=o.collections.map(l=>`usagePage=${l.usagePage}, usage=${l.usage}`).join("; ");console.log(`  Device ${a}: ${o.productName} (vendor=${o.vendorId}, product=${o.productId}) - [${c}]`)});const s=e.find(o=>o.collections.some(a=>a.usagePage===this.digitizerUsagePage))||e[0],i=e.filter(o=>o.vendorId===s.vendorId&&o.productId===s.productId);console.log(`[DeviceFinder] Same tablet devices: ${i.length}`),console.log(`[DeviceFinder] Auto-connecting to ${s.productName}`);const r=await this.openDeviceGroup(i,s);return r&&this.onConnectCallback?(this.onConnectCallback(r),!0):!1}catch(e){return console.error("[DeviceFinder] Error checking for existing devices:",e),!1}}async requestDevice(e){try{if(!navigator.hid)throw new Error("WebHID not supported in this browser");const t=await navigator.hid.requestDevice({filters:e||[]});if(t.length===0)return null;await this.disconnectAll();const i=t.find(c=>c.collections.some(l=>l.usagePage===this.digitizerUsagePage))||t[0];if(!navigator.hid)throw new Error("WebHID not supported");const r=await navigator.hid.getDevices();console.log(`[DeviceFinder] All authorized devices (${r.length}):`),r.forEach((c,l)=>{const d=c.collections.map(u=>`usagePage=${u.usagePage}, usage=${u.usage}`).join("; ");console.log(`  Device ${l}: ${c.productName} (vendor=${c.vendorId}, product=${c.productId}) - [${d}]`)});const o=r.filter(c=>c.vendorId===i.vendorId&&c.productId===i.productId);console.log(`[DeviceFinder] Same tablet devices (${o.length}):`),o.forEach((c,l)=>{const d=c.collections.map(u=>`usagePage=${u.usagePage}, usage=${u.usage}`).join("; ");console.log(`  Device ${l}: [${d}]`)});const a=await this.openDeviceGroup(o,i);return a&&this.onConnectCallback&&this.onConnectCallback(a),a}catch(t){return console.error("[DeviceFinder] Failed to connect HID device:",t),null}}async openDeviceGroup(e,t){try{let s=0;const i=[];for(const o of e)if(!this.isDeviceExcluded(o)){if(o===t){i.push(o);continue}try{o.opened||(await o.open(),s++),i.push(o)}catch(a){console.error("[DeviceFinder] Failed to open interface:",a)}}this.activeDevice=t,this.allConnectedDevices=i;const r={name:t.productName||"Unknown Device",vendor:t.vendorId,product:t.productId};return{primaryDevice:t,allDevices:i,deviceInfo:r}}catch(s){return console.error("[DeviceFinder] Error opening device group:",s),null}}async disconnect(){await this.disconnectAll(),this.onDisconnectCallback&&this.onDisconnectCallback()}async disconnectAll(){for(const e of this.allConnectedDevices)if(e.opened)try{await e.close(),console.log("[DeviceFinder] Closed device interface")}catch(t){console.error("[DeviceFinder] Error closing device:",t)}this.allConnectedDevices=[],this.activeDevice=null}getActiveDevice(){return this.activeDevice}getAllDevices(){return this.allConnectedDevices}isConnected(){return this.activeDevice!==null&&this.activeDevice.opened}}function rt(n){var o;const e=!!n.pressure,t=!!(n.tiltX||n.tiltY);let s=8192;if((o=n.pressure)!=null&&o.max){const a=n.pressure.max;s=Math.pow(2,Math.round(Math.log2(a+1)))}const i=n.x.max||65535,r=n.y.max||65535;return{hasButtons:!1,buttonCount:0,hasPressure:e,pressureLevels:s,hasTilt:t,resolution:{x:i,y:r}}}function ot(n){if(!n||n.length===0)return 13;const e=n.find(t=>t.usagePage===13&&t.usage===2);return e?e.usagePage:n[0].usagePage}function at(n){var e;if((e=n.status)!=null&&e.values){for(const[t,s]of Object.entries(n.status.values))if(s.state==="hover"&&!s.primaryButtonPressed&&!s.secondaryButtonPressed)return parseInt(t,10)}}function nt(n,e,t){if(t)return[];if(!n||n.length===0)return[];const s=e||13;return n.filter(i=>i!==s)}function ct(n,e,t,s){const i=rt(t),r=ot(n.collections),o=at(t);i.hasButtons=e.buttonCount>0,i.buttonCount=e.buttonCount;const a=nt(n.allInterfaces,r,i.hasButtons),c={reportId:n.detectedReportId||0,digitizerUsagePage:r,capabilities:i,byteCodeMappings:t};return o!==void 0&&(c.stylusModeStatusByte=o),a.length>0&&(c.excludedUsagePages=a),n.detectedButtonReportId!==void 0&&n.detectedButtonReportId!==n.detectedReportId&&(c.buttonInterfaceReportId=n.detectedButtonReportId),{name:e.name,manufacturer:e.manufacturer,model:e.model,description:e.description,vendorId:n.vendorId?`0x${n.vendorId.toString(16)}`:"0x0000",productId:n.productId?`0x${n.productId.toString(16)}`:"0x0000",deviceInfo:{vendor_id:n.vendorId||0,product_id:n.productId||0,product_string:n.productName||"",interfaces:n.allInterfaces||[]},modes:[c]}}class Ne{constructor(e){this.defaultConfig={maxX:65535,maxY:65535,maxPressure:8191,reportId:2,statusByte:160,sampleRate:200,pressureVariation:.2},this.PEN_AWAY_PACKETS=30,this.lastPacketState={x:0,y:0,pressure:0,tiltX:0,tiltY:0,status:192,button:0},this.config={...this.defaultConfig,...e}}getLastState(){const e=this.lastPacketState.status,t=e===164||e===165,s=e===162||e===163;return{x:this.lastPacketState.x/this.config.maxX,y:this.lastPacketState.y/this.config.maxY,pressure:this.lastPacketState.pressure/this.config.maxPressure,tiltX:this.lastPacketState.tiltX,tiltY:this.lastPacketState.tiltY,status:e,primaryButtonPressed:t,secondaryButtonPressed:s,button:this.lastPacketState.button,timestamp:Date.now()}}generatePacket(e,t,s,i=0,r=0,o){const a=Math.round(e/1*this.config.maxX),c=Math.round(t/1*this.config.maxY),l=Math.round(s/1*this.config.maxPressure),d=Math.round((i+1)/2*255),u=Math.round((r+1)/2*255);let f=o;f===void 0&&(f=l>0?161:160),this.lastPacketState={x:a,y:c,pressure:l,tiltX:i,tiltY:r,status:f,button:0};const h=new Uint8Array(9);return h[0]=f,h[1]=a&255,h[2]=a>>8&255,h[3]=c&255,h[4]=c>>8&255,h[5]=l&255,h[6]=l>>8&255,h[7]=d,h[8]=u,h}*generatePath(e,t){const s=Math.floor(t/1e3*this.config.sampleRate),i=Math.max(1,Math.floor(s/(e.length-1)));for(let r=0;r<e.length-1;r++){const o=e[r],a=e[r+1];for(let c=0;c<i;c++){const l=c/i,d=o.x+(a.x-o.x)*l,u=o.y+(a.y-o.y)*l,f=this.calculatePressure(l,r/e.length),h=this.addPressureVariation(f),g=a.x-o.x,v=a.y-o.y,b=Math.max(-1,Math.min(1,g*.3)),m=Math.max(-1,Math.min(1,v*.3));yield this.generatePacket(d,u,h,b,m)}}}*generateCircle(e,t,s,i){const r=Math.floor(i/1e3*this.config.sampleRate);for(let o=0;o<r;o++){const a=o/r,c=a*Math.PI*2,l=e+Math.cos(c)*s,d=t+Math.sin(c)*s,u=this.calculatePressure(a,0),f=Math.cos(c+Math.PI/2)*.3,h=Math.sin(c+Math.PI/2)*.3;yield this.generatePacket(l,d,u,f,h)}}*generateLine(e,t,s,i,r){const o=[{x:e,y:t},{x:s,y:i}];yield*this.generatePath(o,r)}*generateLineConstantPressure(e,t,s,i,r,o){const a=Math.floor(o/1e3*this.config.sampleRate);for(let c=0;c<a;c++){const l=c/a,d=e+(s-e)*l,u=t+(i-t)*l;yield this.generatePacket(d,u,r,0,0)}for(let c=0;c<this.PEN_AWAY_PACKETS;c++)yield this.generatePenAwayPacket()}*generateScribble(e,t,s,i,r){const o=[];for(let c=0;c<20;c++){const l=c/19,d=e+Math.sin(l*Math.PI*4)*s*.5+s*l,u=t+Math.cos(l*Math.PI*3)*i*.5+i*.5;o.push({x:d,y:u})}yield*this.generatePath(o,r)}*generateBezier(e,t,s,i,r){const o=[];for(let c=0;c<=30;c++){const l=c/30,d=this.bezierPoint(l,e,t,s,i);o.push(d)}yield*this.generatePath(o,r)}calculatePressure(e,t){let s;return e<.1?s=e/.1*.7:e>.9?s=(1-e)/.1*.7:s=.7+Math.sin(t*Math.PI*2)*.2,Math.max(0,Math.min(1,s))}addPressureVariation(e){const t=(Math.random()-.5)*this.config.pressureVariation;return Math.max(0,Math.min(1,e+t))}bezierPoint(e,t,s,i,r){const o=1-e,a=e*e,c=o*o,l=c*o,d=a*e,u=l*t.x+3*c*e*s.x+3*o*a*i.x+d*r.x,f=l*t.y+3*c*e*s.y+3*o*a*i.y+d*r.y;return{x:u,y:f}}generateHoverPacket(e,t){return this.generatePacket(e,t,0,0,0)}generatePenAwayPacket(){this.lastPacketState={x:0,y:0,pressure:0,tiltX:0,tiltY:0,status:192,button:0};const e=new Uint8Array(9);return e[0]=192,e}*generateHoverLine(e,t,s,i,r){const o=Math.floor(r/1e3*this.config.sampleRate);for(let a=0;a<o;a++){const c=a/o,l=e+(s-e)*c,d=t+(i-t)*c;yield this.generateHoverPacket(l,d)}for(let a=0;a<this.PEN_AWAY_PACKETS;a++)yield this.generatePenAwayPacket()}*generateTiltXLine(e,t,s,i,r){const o=Math.floor(r/1e3*this.config.sampleRate);for(let a=0;a<o;a++){const c=a/o,l=e+(s-e)*c,d=t+(i-t)*c,u=c*2-1;yield this.generatePacket(l,d,.7,u,0)}for(let a=0;a<this.PEN_AWAY_PACKETS;a++)yield this.generatePenAwayPacket()}*generateTiltYLine(e,t,s,i,r){const o=Math.floor(r/1e3*this.config.sampleRate);for(let a=0;a<o;a++){const c=a/o,l=e+(s-e)*c,d=t+(i-t)*c,u=c*2-1;yield this.generatePacket(l,d,.7,0,u)}for(let a=0;a<this.PEN_AWAY_PACKETS;a++)yield this.generatePenAwayPacket()}*generatePrimaryButtonLine(e,t,s,i,r){const o=Math.floor(r/1e3*this.config.sampleRate),a=Math.floor(o/2);for(let c=0;c<o;c++){const l=c/o,d=e+(s-e)*l,u=t+(i-t)*l;c<a?yield this.generatePacket(d,u,0,0,0,164):yield this.generatePacket(d,u,.7,0,0,165)}for(let c=0;c<this.PEN_AWAY_PACKETS;c++)yield this.generatePenAwayPacket()}*generateSecondaryButtonLine(e,t,s,i,r){const o=Math.floor(r/1e3*this.config.sampleRate),a=Math.floor(o/2);for(let c=0;c<o;c++){const l=c/o,d=e+(s-e)*l,u=t+(i-t)*l;c<a?yield this.generatePacket(d,u,0,0,0,162):yield this.generatePacket(d,u,.7,0,0,163)}for(let c=0;c<this.PEN_AWAY_PACKETS;c++)yield this.generatePenAwayPacket()}generateButtonPacket(e){this.lastPacketState={x:0,y:0,pressure:0,tiltX:0,tiltY:0,status:240,button:e};const t=new Uint8Array(11);return t[0]=240,t[1]=1<<e-1,t[2]=0,t[3]=0,t[4]=0,t[5]=0,t[6]=0,t[7]=0,t[8]=0,t[9]=0,t[10]=0,t}*generateTabletButtonSequence(e=8,t=2e3){const s=Math.floor(t/1e3*this.config.sampleRate/e);for(let r=1;r<=e;r++)for(let o=0;o<s;o++)yield this.generateButtonPacket(r);const i=new Uint8Array(11);i[0]=240;for(let r=0;r<10;r++)yield i}}class lt{constructor(e={}){this.isPlaying=!1,this.listeners=new Map,this.currentGenerator=null,this.playbackInterval=null,this.opened=!1,this.config=e,this.generator=new Ne(e),this.deviceName=e.deviceName||"Mock Graphics Tablet",this.vendorId=e.vendorId||0,this.productId=e.productId||1}async open(){this.opened=!0,console.log("[MockTablet] Device opened"),this.config.autoPlay&&this.playCircle()}async close(){this.opened=!1,this.stop(),console.log("[MockTablet] Device closed")}addEventListener(e,t){this.listeners.has(e)||this.listeners.set(e,new Set),this.listeners.get(e).add(t)}removeEventListener(e,t){const s=this.listeners.get(e);s&&s.delete(t)}emit(e,t){const s=this.listeners.get(e);if(s&&s.forEach(i=>i(t)),this.config.translateEvents){const i=this.listeners.get("tablet-event");if(i){let r;this.config.byteCodeMappings?r=ne(t,this.config.byteCodeMappings,-1):r=this.generator.getLastState();const o=JSON.stringify(r),a=new TextEncoder().encode(o);i.forEach(c=>c(a))}}}setTranslateEvents(e,t){this.config.translateEvents=e,t&&(this.config.byteCodeMappings=t)}play(e,t=5){this.stop(),this.currentGenerator=e,this.isPlaying=!0,this.playbackInterval=window.setInterval(()=>{if(!this.currentGenerator||!this.isPlaying){this.stop();return}const s=this.currentGenerator.next();if(s.done){this.stop();return}this.emit("inputreport",s.value)},t)}stop(){this.isPlaying=!1,this.playbackInterval!==null&&(clearInterval(this.playbackInterval),this.playbackInterval=null),this.currentGenerator=null}playCircle(e=.5,t=.5,s=.3,i=2e3){const r=this.generator.generateCircle(e,t,s,i);this.play(r)}playLine(e=.1,t=.1,s=.9,i=.9,r=1e3){const o=this.generator.generateLine(e,t,s,i,r);this.play(o)}playScribble(e=.1,t=.4,s=.8,i=.2,r=3e3){const o=this.generator.generateScribble(e,t,s,i,r);this.play(o)}playPath(e,t=2e3){const s=this.generator.generatePath(e,t);this.play(s)}playHorizontalDrag(e=.5,t=1500){const s=this.generator.generateLineConstantPressure(0,e,1,e,.5,t);this.play(s)}playVerticalDrag(e=.5,t=1500){const s=this.generator.generateLineConstantPressure(e,0,e,1,.5,t);this.play(s)}playHoverHorizontalDrag(e=.5,t=1500){const s=this.generator.generateHoverLine(0,e,1,e,t);this.play(s)}playHoverVerticalDrag(e=.5,t=1500){const s=this.generator.generateHoverLine(e,0,e,1,t);this.play(s)}playTiltXDrag(e=.5,t=1500){const s=this.generator.generateTiltXLine(0,e,1,e,t);this.play(s)}playTiltYDrag(e=.5,t=1500){const s=this.generator.generateTiltYLine(e,0,e,1,t);this.play(s)}playPrimaryButtonDrag(e=.5,t=1500){const s=this.generator.generatePrimaryButtonLine(0,e,1,e,t);this.play(s)}playSecondaryButtonDrag(e=.5,t=1500){const s=this.generator.generateSecondaryButtonLine(0,e,1,e,t);this.play(s)}playTabletButtons(e=8,t=2e3){const s=this.generator.generateTabletButtonSequence(e,t);this.play(s)}sendPacket(e,t,s,i=0,r=0){const o=this.generator.generatePacket(e,t,s,i,r);this.emit("inputreport",o)}sendHover(e,t){const s=this.generator.generateHoverPacket(e,t);this.emit("inputreport",s)}sendButton(e){const t=this.generator.generateButtonPacket(e);this.emit("inputreport",t)}get playing(){return this.isPlaying}}const Le={header:{title:"The Learning Tablet - Configuration Walkthrough",emoji:"🎨"},steps:{idle:{number:0,title:"Ready to Start",description:"Connect your device to begin the walkthrough.",instructions:"Click Start to begin the configuration process."},"step1-horizontal":{number:1,title:"Horizontal Movement (Contact)",description:"This will help us identify which bytes represent the X coordinate.",instructions:"Draw a horizontal line from left to right while pressing down on the tablet."},"step2-vertical":{number:2,title:"Vertical Movement (Contact)",description:"This will help us identify which bytes represent the Y coordinate.",instructions:"Draw a vertical line from top to bottom while pressing down on the tablet."},"step3-pressure":{number:3,title:"Pressure Detection",description:"This will help us identify which bytes represent pressure.",instructions:"Press down on the tablet and vary your pressure from light to heavy."},"step4-hover-movement":{number:4,title:"Hover Movement",description:"This helps identify X and Y coordinate bytes without pressure interference.",instructions:"Hover your pen above the tablet and move it around freely (both horizontally and vertically)."},"step5-tilt-x":{number:5,title:"Tilt X Detection",description:"This will help us identify which byte represents X tilt.",instructions:"Tilt your pen left and right while keeping it in contact with the tablet."},"step6-tilt-y":{number:6,title:"Tilt Y Detection",description:"This will help us identify which byte represents Y tilt.",instructions:"Tilt your pen forward and backward while keeping it in contact with the tablet."},"step7-primary-button":{number:7,title:"Primary Button Detection",description:"This will help us identify the status byte value for primary button.",instructions:"Press and hold the primary button on your pen while moving across the tablet."},"step8-secondary-button":{number:8,title:"Secondary Button Detection",description:"This will help us identify the status byte value for secondary button.",instructions:"Press and hold the secondary button on your pen while moving across the tablet."},"step9-tablet-buttons":{number:9,title:"Tablet Buttons Detection",description:"We'll detect how many buttons your tablet has and their byte values.",instructions:"Press different buttons on your tablet (not the pen buttons)."},"step10-metadata":{number:10,title:"Device Information",description:"Please provide additional information about your device to complete the configuration.",instructions:"Fill in the device name, manufacturer, model, and description."},complete:{number:11,title:"Configuration Complete",description:"Your device configuration has been generated.",instructions:"You can now save or use the generated configuration."}},ui:{buttons:{simulate:"Simulate this data",next:"Next Step"}}},dt=U`
  :host {
    display: block;
    min-height: 100vh;
  }

  .app {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    background: var(--spectrum-gray-100);
  }

  .nav-bar {
    padding: 16px 24px;
    background: var(--spectrum-gray-50);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid var(--spectrum-gray-300);
    position: sticky;
    top: 0;
    z-index: 100;
  }

  .back-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-accent-color-900);
    border-radius: 8px;
    color: var(--spectrum-accent-color-900);
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .back-button:hover {
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-gray-50);
  }

  .back-arrow {
    font-size: 1.2rem;
    transition: transform 0.2s ease;
  }

  .back-button:hover .back-arrow {
    transform: translateX(-3px);
  }

  .page-content {
    flex: 1;
  }

  /* Walkthrough page styling */
  .page-content hid-data-reader {
    max-width: 1000px;
    margin: 0 auto;
    padding: 30px;
  }

  /* Dashboard page styling */
  .page-content hid-dashboard {
    max-width: 1400px;
    margin: 0 auto;
    padding: 30px;
  }
`,pt=U`
  :host {
    display: block;
    width: 100%;
    box-sizing: border-box;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  .dashboard {
    display: flex;
    flex-direction: column;
    gap: 24px;
    max-width: 100%;
    overflow: hidden;
  }

  .dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
  }

  .header-controls {
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
  }

  /* Connection Bar */
  .connection-bar {
    display: flex;
    gap: 24px;
    padding: 16px 20px;
    background: var(--spectrum-gray-100);
    border-radius: 12px;
    border: 1px solid var(--spectrum-gray-200);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    flex-wrap: wrap;
  }

  .connection-section {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .connection-label {
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--spectrum-gray-700);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .connection-group {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  .websocket-controls-inline {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .mock-controls {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .data-mode-toggle {
    display: flex;
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 6px;
    overflow: hidden;
  }

  .mode-btn {
    padding: 6px 10px;
    border: none;
    background: var(--spectrum-gray-75);
    color: var(--spectrum-gray-700);
    font-size: 0.7rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    cursor: pointer;
    transition: all 0.15s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .mode-btn:first-child {
    border-right: 1px solid var(--spectrum-gray-300);
  }

  .mode-btn:hover:not(.active) {
    background: var(--spectrum-gray-100);
  }

  .mode-btn.active {
    background: var(--spectrum-informative-color-900);
    color: var(--spectrum-white);
  }

  .header-info {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .dashboard-header h1 {
    margin: 0;
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--spectrum-gray-900);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .config-name {
    font-size: 0.875rem;
    color: var(--spectrum-gray-600);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .connection-status {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .status-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 500;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .status-badge.disconnected {
    background: var(--spectrum-negative-background-color-default);
    color: var(--spectrum-negative-color-1000);
    border: 1px solid var(--spectrum-negative-color-900);
  }

  .status-badge.connected {
    background: var(--spectrum-positive-background-color-default);
    color: var(--spectrum-positive-color-1000);
    border: 1px solid var(--spectrum-positive-color-900);
  }

  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .status-badge.disconnected .status-dot {
    background: var(--spectrum-negative-color-1000);
  }

  .status-badge.connected .status-dot {
    background: var(--spectrum-positive-color-900);
    animation: pulse 2s infinite;
  }

  .status-badge.warning {
    background: var(--spectrum-notice-background-color-default);
    color: var(--spectrum-notice-color-900);
  }

  .status-badge.warning .status-dot {
    background: var(--spectrum-notice-color-900);
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  .connect-button {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    background: linear-gradient(135deg, var(--spectrum-informative-color-900) 0%, var(--spectrum-informative-color-1000) 100%);
    color: var(--spectrum-white);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .connect-button:hover:not(:disabled) {
    transform: translateY(-1px);
    
  }

  .connect-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background: var(--spectrum-gray-400);
  }

  .disconnect-button {
    padding: 10px 20px;
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 8px;
    background: var(--spectrum-gray-50);
    color: var(--spectrum-gray-800);
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .disconnect-button:hover {
    background: var(--spectrum-gray-100);
    border-color: var(--spectrum-gray-400);
  }



  .visualizers-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 16px;
    max-width: 100%;
    overflow: hidden;
  }

  @media (max-width: 900px) {
    .visualizers-grid {
      grid-template-columns: 1fr 1fr;
    }
    .visualizer-card.events-panel {
      grid-column: span 2;
    }
    .visualizer-card.bytes-panel {
      grid-column: span 2;
    }
  }

  @media (max-width: 600px) {
    .visualizers-grid {
      grid-template-columns: 1fr;
    }
    .visualizer-card.events-panel,
    .visualizer-card.bytes-panel {
      grid-column: span 1;
    }
  }

  /* Events panel - same height as visualizers */
  .visualizer-card.events-panel {
    min-height: auto;
    padding: 12px;
  }

  /* Bytes panel - full width row */
  .visualizer-card.bytes-panel {
    grid-column: 1 / -1;
  }

  .visualizer-card {
    background: var(--spectrum-gray-100);
    border-radius: 12px;
    padding: 12px;
    border: 1px solid var(--spectrum-gray-200);
    min-width: 0;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  }

  .visualizer-card:hover {
    border-color: var(--spectrum-gray-300);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }

  /* Compact panels (25% width) with constrained visualizer */
  .visualizer-card.compact {
    padding: 12px;
    display: flex;
    flex-direction: column;
  }

  /* Visualizer wrapper for constraining size */
  .visualizer-wrapper {
    flex: 1;
    max-height: 280px;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: flex-start;
  }

  .visualizer-wrapper tablet-visualizer {
    transform: scale(0.95);
    transform-origin: top center;
  }

  /* Translated badge for data panels */
  .translated-badge {
    display: inline-block;
    font-size: 0.6rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 2px 6px;
    margin-left: 8px;
    background: var(--spectrum-notice-background-color-default);
    color: var(--spectrum-notice-content-color-default);
    border-radius: 4px;
    vertical-align: middle;
  }


  .data-values {
    display: flex;
    justify-content: space-around;
    gap: 8px;
    margin-top: auto;
    padding: 8px 0;
    border-top: 1px solid var(--spectrum-gray-200);
  }

  .data-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    flex: 1;
    min-width: 0;
  }

  .data-label {
    font-size: 0.6rem;
    color: var(--spectrum-gray-600);
    text-transform: uppercase;
    letter-spacing: 0.03em;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .data-value {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--spectrum-positive-color-900);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .data-value.zero {
    color: var(--spectrum-gray-800);
  }

  .data-item.button-indicator {
    background: var(--spectrum-gray-200);
    border-radius: 6px;
    padding: 4px 8px;
    transition: all 0.15s ease;
  }

  .data-item.button-indicator.pressed {
    background: var(--spectrum-positive-color-900);
  }

  .data-item.button-indicator.pressed .data-label,
  .data-item.button-indicator.pressed .data-value {
    color: var(--spectrum-gray-50);
  }

  .empty-state {
    text-align: center;
    padding: 60px 40px;
    max-width: 1000px;
    margin: 0 auto;
  }

  .empty-state-icon {
    font-size: 4rem;
    margin-bottom: 20px;
  }

  .empty-state h2 {
    color: var(--spectrum-gray-900);
    margin: 0 0 12px 0;
    font-size: 2rem;
  }

  .empty-state > p {
    margin: 0 0 40px 0;
    font-size: 1rem;
    color: var(--spectrum-gray-600);
  }

  .config-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 24px;
    margin-top: 40px;
  }

  .config-option-card {
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-gray-200);
    border-radius: 12px;
    padding: 32px 24px;
    text-align: center;
    transition: all 0.3s ease;
  }

  .config-option-card:hover {
    border-color: var(--spectrum-accent-color-900);
    
    transform: translateY(-2px);
  }

  .option-icon {
    font-size: 3rem;
    margin-bottom: 16px;
  }

  .config-option-card h3 {
    margin: 0 0 8px 0;
    color: var(--spectrum-gray-900);
    font-size: 1.25rem;
  }

  .config-option-card p {
    margin: 0 0 20px 0;
    color: var(--spectrum-gray-600);
    font-size: 0.875rem;
    line-height: 1.5;
  }

  .option-button {
    padding: 12px 24px;
    border: 2px solid var(--spectrum-gray-300);
    border-radius: 8px;
    background: var(--spectrum-gray-50);
    color: var(--spectrum-gray-800);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .option-button:hover {
    background: var(--spectrum-gray-75);
    border-color: var(--spectrum-gray-400);
  }

  .option-button.primary {
    background: linear-gradient(135deg, var(--spectrum-accent-color-900) 0%, var(--spectrum-accent-color-1100) 100%);
    color: var(--spectrum-white);
    border-color: var(--spectrum-accent-color-900);
  }

  .option-button.primary:hover {
    transform: translateY(-2px);
    
  }

  /* Add more visualizer placeholder styles */
  .coming-soon {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 200px;
    color: var(--spectrum-gray-800);
    text-align: center;
  }

  .coming-soon-icon {
    font-size: 3rem;
    margin-bottom: 12px;
    opacity: 0.5;
  }

  .coming-soon-text {
    font-size: 0.875rem;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  /* Diagrams row layout matching tablet-visualizer */
  .diagrams-row {
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
  }

  .diagrams-row > * {
    flex: 1;
    min-width: 280px;
  }

  /* Data Mode Toggle */
  .data-mode-toggle {
    display: flex;
    align-items: center;
  }

  .mode-button {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    border: 2px solid var(--spectrum-informative-color-900);
    border-radius: 8px;
    background: var(--spectrum-gray-50);
    color: var(--spectrum-informative-color-900);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .mode-button:hover:not(:disabled) {
    background: var(--spectrum-informative-background-color-default);
    transform: translateY(-1px);
  }

  .mode-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .mode-button .button-icon {
    font-size: 1.1rem;
  }

  /* Config Dropdown */
  .config-dropdown {
    position: relative;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .config-menu-button {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 8px;
    background: var(--spectrum-gray-50);
    color: var(--spectrum-gray-800);
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .config-menu-button:hover {
    background: var(--spectrum-gray-75);
    border-color: var(--spectrum-gray-400);
  }

  /* Simulation Dropdown */
  .simulation-dropdown {
    position: relative;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .load-config-button {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    border: 2px solid var(--spectrum-accent-color-900);
    border-radius: 8px;
    background: linear-gradient(135deg, var(--spectrum-accent-color-900) 0%, var(--spectrum-accent-color-1100) 100%);
    color: var(--spectrum-white);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .load-config-button:hover {
    transform: translateY(-2px);
    
  }

  .simulation-button {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 8px;
    background: var(--spectrum-gray-50);
    color: var(--spectrum-gray-800);
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .simulation-button:hover {
    background: var(--spectrum-gray-75);
    border-color: var(--spectrum-gray-400);
  }

  .simulation-button.active {
    background: linear-gradient(135deg, var(--spectrum-positive-color-900) 0%, var(--spectrum-positive-color-1000) 100%);
    color: var(--spectrum-white);
    border-color: var(--spectrum-positive-color-1000);
  }

  .button-icon {
    font-size: 1rem;
  }

  .dropdown-arrow {
    font-size: 0.625rem;
    opacity: 0.7;
  }

  .simulation-label {
    max-width: 120px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .spinner {
    width: 12px;
    height: 12px;
    border: 2px solid var(--spectrum-gray-300);
    border-top-color: var(--spectrum-white);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  .dropdown-menu {
    position: absolute;
    top: calc(100% + 8px);
    left: 0;
    min-width: 200px;
    background: var(--spectrum-gray-50);
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 12px;
    
    z-index: 100;
    overflow: hidden;
    animation: slideDown 0.15s ease-out;
  }

  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .dropdown-header {
    padding: 12px 16px 8px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--spectrum-gray-600);
    border-bottom: 1px solid var(--spectrum-gray-100);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .dropdown-item {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    padding: 10px 16px;
    border: none;
    background: none;
    color: var(--spectrum-gray-800);
    font-size: 0.875rem;
    cursor: pointer;
    transition: all 0.15s ease;
    text-align: left;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .dropdown-item:hover {
    background: var(--spectrum-gray-75);
    color: var(--spectrum-informative-color-1000);
  }

  .dropdown-item.active {
    background: var(--spectrum-informative-background-color-default);
    color: var(--spectrum-informative-color-1000);
    font-weight: 600;
  }

  .dropdown-item:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .dropdown-divider {
    height: 1px;
    background: var(--spectrum-gray-200);
    margin: 8px 0;
  }

  .item-icon {
    font-size: 1rem;
    width: 24px;
    text-align: center;
  }

  .item-label {
    flex: 1;
  }

  .check-mark {
    color: var(--spectrum-informative-color-1000);
    font-weight: bold;
    margin-left: auto;
  }

  .stop-button {
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    background: linear-gradient(135deg, var(--spectrum-negative-color-900) 0%, var(--spectrum-negative-color-1000) 100%);
    color: var(--spectrum-white);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .stop-button:hover {
    transform: translateY(-1px);
    
  }

  /* WebSocket Connection Styles */
  .connect-options {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .websocket-dropdown {
    position: relative;
  }

  .websocket-url-input {
    width: 180px;
  }
`,ut=U`
  :host {
    display: block;
  }

  .bytes-container {
    padding: 16px;
    background: transparent;
    color: var(--spectrum-gray-800);
  }

  .device-info-header {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 16px;
    align-items: center;
    margin-bottom: 12px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--spectrum-gray-300);
    font-size: 13px;
  }

  .info-item {
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .info-label {
    opacity: 0.8;
    font-weight: 500;
  }

  .info-value {
    font-weight: 600;
    background: var(--spectrum-gray-200);
    color: var(--spectrum-gray-900);
    padding: 2px 8px;
    border-radius: 4px;
  }

  .info-badge {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .info-badge.digitizer {
    background: var(--spectrum-positive-background-color-default);
    color: var(--spectrum-positive-color-200);
    border: 1px solid var(--spectrum-positive-color-900);
  }

  .info-badge.digitizer.mock {
    background: var(--spectrum-notice-background-color-default);
    color: var(--spectrum-orange-200);
    border: 1px solid var(--spectrum-notice-color-900);
  }

  .bytes-grid {
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    gap: 8px;
    overflow-x: auto;
    overflow-y: visible;
    padding: 15px 0 0 0;
  }
`,ht=U`
  :host {
    display: block;
    overflow: visible;
  }

  .byte-cell {
    position: relative;
    flex: 0 0 auto;
    min-width: 60px;
    height: 85px;
    padding: 10px 5px 6px 5px;
    background: var(--spectrum-gray-50);
    border-radius: 6px;
    text-align: center;
    transition: all 0.2s ease;
    box-sizing: border-box;
  }

  .byte-cell.best-guess {
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-notice-color-800);
    
    transform: scale(1.05);
  }

  .byte-cell.identified {
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-accent-color-900);
    
  }

  .byte-cell.empty-placeholder {
    background: var(--spectrum-gray-200);
    border: 2px dashed var(--spectrum-gray-400);
  }

  .byte-cell.empty-placeholder .byte-label,
  .byte-cell.empty-placeholder .byte-value,
  .byte-cell.empty-placeholder .byte-hex,
  .byte-cell.empty-placeholder .byte-meta {
    color: var(--spectrum-gray-500);
  }

  .byte-type-label {
    position: absolute;
    top: -10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 2px 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
    white-space: nowrap;
    
  }

  .byte-cell.best-guess .byte-type-label {
    background: var(--spectrum-notice-color-800);
    color: var(--spectrum-gray-900);
  }

  .byte-label {
    font-size: 9px;
    font-weight: 600;
    color: var(--spectrum-gray-700);
    text-transform: uppercase;
    margin-bottom: 3px;
  }

  .byte-cell.best-guess .byte-label {
    color: var(--spectrum-accent-color-900);
    font-weight: 700;
  }

  .byte-value {
    font-size: 18px;
    font-weight: 900;
    color: var(--spectrum-gray-900);
    font-family: 'Courier New', monospace;
    margin-bottom: 2px;
    line-height: 1;
  }

  .byte-cell.best-guess .byte-value {
    color: var(--spectrum-accent-color-900);
    font-size: 20px;
  }

  .byte-hex {
    font-size: 10px;
    color: var(--spectrum-gray-600);
    font-family: 'Courier New', monospace;
    margin-bottom: 4px;
  }

  .byte-cell.best-guess .byte-hex {
    color: var(--spectrum-accent-color-900);
    font-weight: 600;
  }

  .byte-meta {
    font-size: 8px;
    color: var(--spectrum-gray-600);
    font-family: 'Courier New', monospace;
    line-height: 1.2;
    white-space: nowrap;
  }

  .byte-cell.best-guess .byte-meta {
    color: var(--spectrum-gray-700);
    font-weight: 600;
  }
`;var q=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let H=class extends Y{constructor(){super(...arguments),this.byteIndex=0,this.isBestGuess=!1,this.isIdentified=!1,this.isEmpty=!1}render(){const e=["byte-cell",this.isBestGuess?"best-guess":"",this.isIdentified?"identified":"",this.isEmpty?"empty-placeholder":""].filter(Boolean).join(" ");return p`
      <div class="${e}">
        ${this.label&&!this.isEmpty?p`<div class="byte-type-label">${this.label}</div>`:""}
        <div class="byte-label">Byte ${this.byteIndex+1}</div>
        <div class="byte-value">${this.value!==void 0?this.value:"-"}</div>
        <div class="byte-hex">
          ${this.value!==void 0?`0x${this.value.toString(16).toUpperCase().padStart(2,"0")}`:"0x--"}
        </div>
        ${this.variance!==void 0?p`
          <div class="byte-meta">
            <div class="meta-line">R: ${this.min}-${this.max}</div>
            <div class="meta-line">V: ${this.variance.toFixed(1)}</div>
          </div>
        `:p`
          <div class="byte-meta">
            <div class="meta-line">-</div>
          </div>
        `}
      </div>
    `}};H.styles=ht;q([y({type:Number})],H.prototype,"byteIndex",void 0);q([y({type:Number})],H.prototype,"value",void 0);q([y({type:Number})],H.prototype,"min",void 0);q([y({type:Number})],H.prototype,"max",void 0);q([y({type:Number})],H.prototype,"variance",void 0);q([y({type:Boolean})],H.prototype,"isBestGuess",void 0);q([y({type:Boolean})],H.prototype,"isIdentified",void 0);q([y({type:String})],H.prototype,"label",void 0);q([y({type:Boolean})],H.prototype,"isEmpty",void 0);H=q([j("byte-display-block")],H);var fe=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let se=class extends Y{constructor(){super(...arguments),this.bytes=[],this.isEmpty=!1,this.placeholderCount=9}render(){const e=this.deviceInfo?p`
      <div class="device-info-header">
        ${this.deviceInfo.deviceNumber!==void 0?p`
          <span class="info-item">
            <span class="info-label">Device:</span>
            <span class="info-value">${this.deviceInfo.isMock?"Simulated":this.deviceInfo.deviceNumber}</span>
          </span>
        `:""}
        ${this.deviceInfo.packetCount!==void 0?p`
          <span class="info-item">
            <span class="info-label">Packets:</span>
            <span class="info-value">${this.deviceInfo.packetCount}</span>
          </span>
        `:""}
        ${this.deviceInfo.digitizerUsagePage!==void 0?p`
          <span class="info-item">
            <span class="info-label">Digitizer Usage Page:</span>
            <span class="info-value">${this.deviceInfo.digitizerUsagePage}</span>
          </span>
        `:""}
        ${this.deviceInfo.digitizerUsagePage===13?p`
          <span class="info-badge digitizer ${this.deviceInfo.isMock?"mock":""}">
            ${this.deviceInfo.isMock?"Simulated Pen":"Digitizer - Pen"}
          </span>
        `:""}
      </div>
    `:"";return this.isEmpty?p`
        <div class="bytes-container">
          ${e}
          <div class="bytes-grid">
            ${Array.from({length:this.placeholderCount}).map((t,s)=>p`
              <byte-display-block
                .byteIndex=${s}
                .isEmpty=${!0}>
              </byte-display-block>
            `)}
          </div>
        </div>
      `:p`
      <div class="bytes-container">
        ${e}
        <div class="bytes-grid">
          ${this.bytes.map(t=>p`
            <byte-display-block
              .byteIndex=${t.byteIndex}
              .value=${t.value}
              .min=${t.min}
              .max=${t.max}
              .variance=${t.variance}
              .isBestGuess=${t.isBestGuess||!1}
              .isIdentified=${t.isIdentified||!1}
              .label=${t.label}>
            </byte-display-block>
          `)}
        </div>
      </div>
    `}};se.styles=ut;fe([y({type:Array})],se.prototype,"bytes",void 0);fe([y({type:Boolean})],se.prototype,"isEmpty",void 0);fe([y({type:Number})],se.prototype,"placeholderCount",void 0);fe([y({type:Object})],se.prototype,"deviceInfo",void 0);se=fe([j("bytes-display")],se);const gt=U`
  :host {
    display: block;
    height: 100%;
  }

  .events-container {
    display: flex;
    flex-direction: column;
    height: 100%;
    gap: 10px;
  }

  .events-container.empty {
    justify-content: center;
    align-items: center;
  }

  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--spectrum-gray-500);
    text-align: center;
  }

  .empty-icon {
    font-size: 2rem;
    margin-bottom: 8px;
    opacity: 0.5;
  }

  .empty-state p {
    margin: 0;
    font-size: 0.85rem;
  }

  .event-header {
    display: flex;
    align-items: baseline;
    gap: 6px;
  }

  .event-count {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--spectrum-gray-900);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .event-label {
    font-size: 0.75rem;
    color: var(--spectrum-gray-600);
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .header-badges {
    display: flex;
    gap: 6px;
    margin-left: auto;
  }

  .source-badge {
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .source-badge.mock {
    background: var(--spectrum-gray-300);
    color: var(--spectrum-gray-800);
  }

  .source-badge.translated {
    background: var(--spectrum-notice-background-color-default);
    color: var(--spectrum-notice-content-color-default);
  }

  .event-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 6px 8px;
  }

  .event-field {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .field-label {
    font-size: 0.65rem;
    color: var(--spectrum-gray-600);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 500;
  }

  .field-value {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--spectrum-gray-900);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .button-status {
    display: flex;
    gap: 8px;
    padding-top: 8px;
    border-top: 1px solid var(--spectrum-gray-200);
  }

  .button-indicator {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 6px;
    border-radius: 6px;
    background: var(--spectrum-gray-200);
    transition: all 0.15s ease;
  }

  .button-indicator.active {
    background: var(--spectrum-positive-color-900);
  }

  .button-indicator.active .button-label {
    color: var(--spectrum-gray-50);
  }

  .button-label {
    font-size: 0.7rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--spectrum-gray-700);
  }
`;var ke=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let ce=class extends Y{constructor(){super(...arguments),this.events=[],this.isEmpty=!1}_formatValue(e,t=3){return e===void 0?"—":e.toFixed(t)}_getPressedTabletButton(e){return e.button1?1:e.button2?2:e.button3?3:e.button4?4:e.button5?5:e.button6?6:e.button7?7:e.button8?8:null}render(){var t,s,i;if(this.isEmpty||this.events.length===0)return p`
        <div class="events-container empty">
          <div class="empty-state">
            <div class="empty-icon">—</div>
            <p>No events yet</p>
          </div>
        </div>
      `;const e=this.events[this.events.length-1];return p`
      <div class="events-container">
        <div class="event-header">
          <span class="event-count">${((t=this.deviceInfo)==null?void 0:t.packetCount)??this.events.length}</span>
          <span class="event-label">events</span>
          <div class="header-badges">
            ${(s=this.deviceInfo)!=null&&s.isMock?p`<span class="source-badge mock">mock</span>`:""}
            ${(i=this.deviceInfo)!=null&&i.isTranslated?p`<span class="source-badge translated">translated</span>`:""}
          </div>
        </div>
        
        <div class="event-grid">
          <div class="event-field">
            <span class="field-label">X</span>
            <span class="field-value">${this._formatValue(e.x)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Y</span>
            <span class="field-value">${this._formatValue(e.y)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Pressure</span>
            <span class="field-value">${this._formatValue(e.pressure)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Tilt X</span>
            <span class="field-value">${this._formatValue(e.tiltX)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Tilt Y</span>
            <span class="field-value">${this._formatValue(e.tiltY)}</span>
          </div>
        </div>

        <div class="button-status">
          <div class="button-indicator ${e.primaryButtonPressed?"active":""}">
            <span class="button-label">Primary</span>
          </div>
          <div class="button-indicator ${e.secondaryButtonPressed?"active":""}">
            <span class="button-label">Secondary</span>
          </div>
          <div class="button-indicator tablet-btn ${this._getPressedTabletButton(e)?"active":""}">
            <span class="button-label">Tablet ${this._getPressedTabletButton(e)??"—"}</span>
          </div>
        </div>
      </div>
    `}};ce.styles=gt;ke([y({type:Array})],ce.prototype,"events",void 0);ke([y({type:Boolean})],ce.prototype,"isEmpty",void 0);ke([y({type:Object})],ce.prototype,"deviceInfo",void 0);ce=ke([j("events-display")],ce);const ft=({width:n=24,height:e=24,hidden:t=!1,title:s="More"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <circle cx="10" cy="10.02114" r="1.5" fill="currentColor" />
    <path
      d="m10,8.5c-.82843,0-1.5.67157-1.5,1.5s.67157,1.5,1.5,1.5,1.5-.67157,1.5-1.5-.67157-1.5-1.5-1.5Z"
      fill="currentColor"
    />
    <circle cx="4" cy="10.02114" r="1.5" fill="currentColor" />
    <circle cx="4" cy="10" r="1.5" fill="currentColor" />
    <circle cx="16" cy="10.02114" r="1.5" fill="currentColor" />
    <circle cx="16" cy="10" r="1.5" fill="currentColor" />
  </svg>`,mt=({width:n=24,height:e=24,hidden:t=!1,title:s="More"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 36 36"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <circle cx="17.8" cy="18.2" r="3.4" />
    <circle cx="29.5" cy="18.2" r="3.4" />
    <circle cx="6.1" cy="18.2" r="3.4" />
  </svg>`;class vt extends W{render(){return G(p),this.spectrumVersion===2?ft({hidden:!this.label,title:this.label}):mt({hidden:!this.label,title:this.label})}}O("sp-icon-more",vt);const bt=U`
    :host{display:inline-flex}:host([quiet]){min-width:0}:host>sp-menu{display:none}::slotted([slot=icon]),.icon{flex-shrink:0}#popover{max-width:none}:host([dir=ltr]) ::slotted([slot=icon]),:host([dir=ltr]) .icon{margin-left:calc(-1*(var(--spectrum-actionbutton-textonly-padding-left-adjusted) - var(--spectrum-actionbutton-padding-left-adjusted)))}:host([dir=rtl]) ::slotted([slot=icon]),:host([dir=rtl]) .icon{margin-right:calc(-1*(var(--spectrum-actionbutton-textonly-padding-left-adjusted) - var(--spectrum-actionbutton-padding-left-adjusted)))}:host([dir]) slot[icon-only]::slotted([slot=icon]),:host([dir]) slot[icon-only] .icon{margin-inline:calc((var(--custom-actionbutton-edge-to-text,var(--spectrum-actionbutton-edge-to-text)) - var(--custom-actionbutton-edge-to-visual-only,var(--spectrum-actionbutton-edge-to-visual-only)))*-1)}sp-overlay:not(:defined){display:none}
`;var yt=Object.defineProperty,xt=Object.getOwnPropertyDescriptor,Pe=(n,e,t,s)=>{for(var i=s>1?void 0:s?xt(e,t):e,r=n.length-1,o;r>=0;r--)(o=n[r])&&(i=(s?o(e,t,i):o(i))||i);return s&&i&&yt(e,t,i),i};class we extends Ue(Oe(He,"label"),'[slot="label-only"]'){constructor(){super(...arguments),this.selects=void 0,this.listRole="menu",this.itemRole="menuitem",this.handleSlottableRequest=e=>{this.dispatchEvent(new Ke(e.name,e.data))}}static get styles(){return[bt]}get hasLabel(){return this.slotHasContent}get labelOnly(){return this.slotContentIsPresent}get buttonContent(){return[p`
                ${this.labelOnly?p``:p`
                          <slot
                              name="icon"
                              slot="icon"
                              ?icon-only=${!this.hasLabel}
                              ?hidden=${this.labelOnly}
                          >
                              <sp-icon-more
                                  class="icon"
                                  size=${this.size}
                              ></sp-icon-more>
                          </slot>
                      `}
                <slot name="label" ?hidden=${!this.hasLabel}></slot>
                <slot name="label-only"></slot>
            `]}render(){return this.tooltipEl&&(this.tooltipEl.disabled=this.open),p`
            <sp-action-button
                aria-describedby=${je}
                ?quiet=${this.quiet}
                ?selected=${this.open}
                static-color=${De(this.staticColor)}
                aria-haspopup="true"
                aria-controls=${De(this.open?"menu":void 0)}
                aria-expanded=${this.open?"true":"false"}
                aria-label=${De(this.label||void 0)}
                id="button"
                class="button"
                size=${this.size}
                @blur=${this.handleButtonBlur}
                @focus=${this.handleButtonFocus}
                @keydown=${{handleEvent:this.handleEnterKeydown,capture:!0}}
                ?disabled=${this.disabled}
            >
                ${this.buttonContent}
            </sp-action-button>
            <slot
                name="tooltip"
                @slotchange=${this.handleTooltipSlotchange}
            ></slot>
            ${this.renderMenu} ${this.renderDescriptionSlot}
        `}update(e){e.has("invalid")&&(this.invalid=!1),super.update(e)}hasAccessibleLabel(){return!!this.label||!!this.getAttribute("aria-label")||!!this.getAttribute("aria-labelledby")||!!this.appliedLabel||this.hasLabel||this.labelOnly}warnNoLabel(){window.__swc.warn(this,`<${this.localName}> needs one of the following to be accessible:`,"https://opensource.adobe.com/spectrum-web-components/components/action-menu/#accessibility",{type:"accessibility",issues:[`an <sp-field-label> element with a \`for\` attribute referencing the \`id\` of the \`<${this.localName}>\`, or`,'value supplied to the "label" attribute, which will be displayed visually as placeholder text','text content supplied in a <span> with slot="label", or, text content supplied in a <span> with slot="label-only"',"which will also be displayed visually as placeholder text."]})}}Pe([y({type:String})],we.prototype,"selects",2),Pe([y({reflect:!0,attribute:"static-color"})],we.prototype,"staticColor",2),Pe([x()],we.prototype,"labelOnly",1);O("sp-action-menu",we);const wt=({width:n=24,height:e=24,hidden:t=!1,title:s="Settings"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M10.00391,12.58887c-.88818,0-1.75293-.45996-2.22803-1.2832h0c-.70801-1.22754-.28613-2.80078.93994-3.50879.59326-.34375,1.28516-.43359,1.94922-.25684.6626.17773,1.21631.60352,1.55908,1.19727.34326.59375.43408,1.28613.25684,1.94824-.17773.66309-.60254,1.2168-1.19678,1.55957-.40332.2334-.84473.34375-1.28027.34375ZM9.07471,10.55566c.29443.50879.94824.68359,1.45947.39062.24707-.14258.42383-.37305.49756-.64844s.03613-.56348-.10645-.81055c-.14307-.24707-.37305-.42383-.64893-.49805-.2749-.07324-.56299-.03516-.81055.10645-.51025.29492-.68555.94922-.39111,1.45996h0Z"
      fill="currentColor"
    />
    <path
      d="M6.90674,18.31836c-.33936,0-.68213-.08496-.99219-.26465l-.81982-.47266c-.89307-.51367-1.25-1.64941-.81104-2.58301l.58008-1.2334c-.26514-.36328-.48975-.75098-.67188-1.16113l-1.35693-.1123c-1.02881-.08496-1.83447-.95996-1.83447-1.99121l-.00098-.94629c0-1.0332.80518-1.90918,1.8335-1.99414l1.35449-.11426c.0918-.20898.19238-.40918.30176-.59961.10986-.19141.2334-.37891.36914-.56445l-.58057-1.22949c-.44092-.93262-.08643-2.06836.80713-2.58496l.82031-.47363c.89258-.5166,2.05371-.25879,2.64258.58984l.77734,1.11816c.44385-.0498.89209-.04785,1.34082,0l.77539-1.11914c.58887-.84961,1.75098-1.10938,2.64355-.59375l.81982.47266c.89404.51562,1.24951,1.65137.81055,2.58398l-.58008,1.23242c.26562.36426.49023.75195.67188,1.16113l1.35693.1123c1.02832.08496,1.83398.95996,1.83496,1.99121l.00049.94727c.00098,1.03125-.80371,1.90723-1.83203,1.99414l-1.35547.11426c-.09131.20898-.19189.4082-.30273.59961h0c-.10938.18945-.23242.37793-.36816.56348l.58057,1.22949c.44043.93164.08643,2.06738-.80664,2.58496l-.8208.47461c-.89355.51855-2.05371.25781-2.64258-.59082l-.77734-1.11816c-.4458.04883-.89404.04785-1.34082.00098l-.77637,1.12012c-.38379.55371-1.01172.85645-1.65039.85645ZM6.9043,3.22461c-.08496,0-.17041.02148-.24805.06641l-.8208.47461c-.22266.12891-.31152.41211-.20117.64551l.77881,1.65039c.12598.2666.08398.58203-.10742.80664-.2041.23926-.37305.47656-.5166.72559-.14111.24609-.26514.51855-.36816.80957-.09814.27832-.3501.47266-.64404.49707l-1.81885.15332c-.26172.02246-.4585.23633-.4585.49902l.00098.94629c0,.25781.20117.47656.4585.49805l1.81934.15039c.29395.02441.54639.21875.64502.49707.19873.56055.49707,1.07617.88672,1.53223.19189.22363.23438.54004.10889.80664l-.77783,1.65234c-.10938.2334-.021.51758.20264.64551l.82031.47363c.22412.12988.51416.06348.66016-.14746l1.04102-1.50195c.16748-.24219.45898-.36914.75244-.30957.58838.10742,1.18457.1084,1.77002-.00098.28955-.05469.58496.06641.75342.30957l1.04199,1.49902c.14648.20996.43848.27637.66064.14746l.82031-.47363c.22607-.13086.31348-.40918.20117-.64648l-.77881-1.65039c-.12598-.2666-.08398-.58203.10742-.80664.2041-.24023.37305-.47656.51562-.72461l.00049-.00098c.14258-.24707.26318-.51172.36865-.80957.09863-.27832.35059-.47266.64453-.49707l1.81885-.15234c.25635-.02246.45752-.24121.45752-.49902l-.00049-.94727c0-.26172-.19727-.47559-.45898-.49805l-1.81885-.15039c-.29395-.02441-.54639-.21875-.64502-.49707-.19775-.55957-.49658-1.0752-.88721-1.53223-.19141-.22461-.23389-.54004-.1084-.80664l.77734-1.65234c.10986-.2334.021-.51758-.20264-.64648l-.81982-.47266c-.22461-.12695-.51416-.06152-.66113.14941l-1.03955,1.5c-.16797.24316-.45898.36816-.75293.31055-.59131-.10938-1.1875-.10938-1.77002,0-.29199.05176-.58545-.06738-.75342-.30957l-1.04199-1.49902c-.09619-.1377-.25293-.21387-.41211-.21387Z"
      fill="currentColor"
    />
  </svg>`,kt=({width:n=24,height:e=24,hidden:t=!1,title:s="Settings"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M32.9 15.793h-3.111a11.953 11.953 0 0 0-1.842-4.507l2.205-2.206a1.1 1.1 0 0 0 0-1.56l-1.673-1.672a1.1 1.1 0 0 0-1.56 0l-2.205 2.205a11.925 11.925 0 0 0-4.507-1.841V3.1A1.1 1.1 0 0 0 19.1 2h-2.2a1.1 1.1 0 0 0-1.1 1.1v3.112a11.925 11.925 0 0 0-4.507 1.841l-2.2-2.205a1.1 1.1 0 0 0-1.56 0L5.848 7.52a1.1 1.1 0 0 0 0 1.56l2.205 2.206a11.953 11.953 0 0 0-1.842 4.507H3.1A1.1 1.1 0 0 0 2 16.9v2.2a1.1 1.1 0 0 0 1.1 1.1h3.111a11.934 11.934 0 0 0 1.842 4.507l-2.205 2.212a1.1 1.1 0 0 0 0 1.56l1.673 1.673a1.1 1.1 0 0 0 1.56 0l2.205-2.205a11.925 11.925 0 0 0 4.507 1.841V32.9A1.1 1.1 0 0 0 16.9 34h2.2a1.1 1.1 0 0 0 1.1-1.1v-3.112a11.925 11.925 0 0 0 4.507-1.841l2.205 2.205a1.1 1.1 0 0 0 1.56 0l1.673-1.673a1.1 1.1 0 0 0 0-1.56l-2.205-2.205a11.934 11.934 0 0 0 1.842-4.507H32.9A1.1 1.1 0 0 0 34 19.1v-2.2a1.1 1.1 0 0 0-1.1-1.107ZM22.414 18A4.414 4.414 0 1 1 18 13.586 4.414 4.414 0 0 1 22.414 18Z"
    />
  </svg>`;class Ct extends W{render(){return G(p),this.spectrumVersion===2?wt({hidden:!this.label,title:this.label}):kt({hidden:!this.label,title:this.label})}}O("sp-icon-settings",Ct);const Dt=({width:n=24,height:e=24,hidden:t=!1,title:s="Document"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path d="M20 11V2H7a1 1 0 0 0-1 1v30a1 1 0 0 0 1 1h22a1 1 0 0 0 1-1V12h-9a1 1 0 0 1-1-1Z" />
    <path d="M22 2h.086a1 1 0 0 1 .707.293l6.914 6.914a1 1 0 0 1 .293.707V10h-8Z" />
  </svg>`,St=({width:n=24,height:e=24,hidden:t=!1,title:s="File"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="m16.34131,5.28027l-3.62207-3.62109c-.4248-.4248-.98975-.65918-1.59033-.65918h-5.87891c-1.24072,0-2.25,1.00977-2.25,2.25v12.5c0,1.24023,1.00928,2.25,2.25,2.25h9.5c1.24072,0,2.25-1.00977,2.25-2.25V6.87109c0-.5918-.23975-1.17188-.65869-1.59082Zm-1.06104,1.06055c.04565.04565.07385.10376.10602.15918h-3.13629c-.41357,0-.75-.33691-.75-.75v-3.13599c.05518.03223.11316.06018.15869.10571l3.62158,3.62109Zm-.53027,10.15918H5.25c-.41357,0-.75-.33691-.75-.75V3.25c0-.41309.33643-.75.75-.75h4.75v3.25c0,1.24023,1.00928,2.25,2.25,2.25h3.25v7.75c0,.41309-.33643.75-.75.75Z"
      fill="currentColor"
    />
  </svg>`;class It extends W{render(){return G(p),this.spectrumVersion===1?Dt({hidden:!this.label,title:this.label}):St({hidden:!this.label,title:this.label})}}O("sp-icon-document",It);const Bt=({width:n=24,height:e=24,hidden:t=!1,title:s="Magic Wand"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="m15.0498,7.2002c0-.60156-.23438-1.16699-.6582-1.59082-.84863-.84961-2.33301-.85156-3.18262,0l-1.82129,1.82129c-.02148.02148-.04199.04492-.06055.06836-.02441.01855-.04688.03906-.06934.06152L1.65918,15.15918c-.4248.4248-.65918.99023-.65918,1.59082s.23438,1.16602.65918,1.59082.99023.65918,1.59082.65918,1.16602-.23438,1.59082-.65918l9.5498-9.5498c.4248-.4248.65918-.99023.65918-1.59082ZM3.78027,17.28027c-.2832.2832-.77734.2832-1.06055,0-.1416-.1416-.21973-.33008-.21973-.53027s.07812-.38867.21973-.53027l7.2002-7.2002,1.06543,1.05566-7.20508,7.20508ZM13.33008,7.73047l-1.28418,1.28418-1.06543-1.05566,1.28906-1.28906c.2832-.2832.77734-.28418,1.06055.00098.1416.14062.21973.3291.21973.5293s-.07812.38867-.21973.53027Z"
      fill="currentColor"
    />
    <path
      d="m18.70605,10.83154l-1.26123-.49854-.20312-1.34204c-.06519-.42798-.75806-.50513-.91577-.10425l-.49878,1.26221-1.34204.20166c-.21289.03198-.37891.20361-.40332.41797-.02441.2146.0979.41821.29907.49805l1.26221.49976.2019,1.34106c.03174.21289.20337.37891.41797.40332.21436.02441.41797-.0979.49805-.29907l.49927-1.26099,1.34131-.20312c.21411-.03271.37891-.20361.40332-.41797s-.09863-.41919-.29883-.49805Z"
      fill="currentColor"
    />
    <path
      d="m14.33618,3.64233l1.26221.49976.2019,1.34094c.03174.21301.20361.37903.41797.40344.2146.02441.41821-.0979.49805-.29907l.49951-1.26111,1.34131-.203c.21387-.03259.37891-.20361.40332-.41797s-.09863-.41919-.29907-.49805l-1.26123-.49854-.20288-1.34204c-.06519-.4281-.7583-.50513-.91602-.10437l-.49854,1.26221-1.34204.2019c-.21313.03186-.37915.20349-.40356.41797s.0979.41809.29907.49792Z"
      fill="currentColor"
    />
    <path
      d="m5.7793,4.69019l1.02417.4054.16382,1.08826c.02588.17273.16528.3075.33936.32727.17383.0199.33911-.07935.40405-.24268l.40527-1.02332,1.08813-.16479c.17383-.02637.30762-.16504.32764-.33911.01978-.17407-.08008-.34009-.24268-.40405l-1.02344-.40454-.16479-1.08911c-.05298-.34741-.61523-.40991-.74316-.08472l-.40454,1.02429-1.08911.16382c-.17285.02576-.30762.16516-.32739.33923-.01978.17395.07935.33911.24268.40405Z"
      fill="currentColor"
    />
  </svg>`,$t=({width:n=24,height:e=24,hidden:t=!1,title:s="Magic Wand"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <rect
      height="4"
      rx="1"
      ry="1"
      transform="rotate(-45 12.249 21.751)"
      width="30.118"
      x="-2.811"
      y="19.752"
    />
    <path
      d="m31.506 13.559.078 2.156a1.756 1.756 0 0 0 .9 1.47l1.882 1.054-2.156.078a1.756 1.756 0 0 0-1.47.9L29.684 21.1l-.078-2.156a1.756 1.756 0 0 0-.9-1.47l-1.882-1.054 2.156-.078a1.759 1.759 0 0 0 1.47-.9ZM29.732.1l.108 2.99a2.437 2.437 0 0 0 1.245 2.038L33.7 6.589l-2.99.108a2.434 2.434 0 0 0-2.039 1.245l-1.462 2.61-.109-2.99a2.44 2.44 0 0 0-1.245-2.039l-2.614-1.462 2.99-.108a2.439 2.439 0 0 0 2.039-1.245ZM12.7 1.68l.139 3.851a3.138 3.138 0 0 0 1.6 2.625L17.8 10.04l-3.851.139a3.139 3.139 0 0 0-2.626 1.6l-1.88 3.365-.143-3.851a3.139 3.139 0 0 0-1.6-2.626L4.339 6.784l3.851-.139a3.141 3.141 0 0 0 2.626-1.6Z"
    />
  </svg>`;class Pt extends W{render(){return G(p),this.spectrumVersion===2?Bt({hidden:!this.label,title:this.label}):$t({hidden:!this.label,title:this.label})}}O("sp-icon-magic-wand",Pt);const Mt=({width:n=24,height:e=24,hidden:t=!1,title:s="Stop"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <rect height="28" rx="1" ry="1" width="24" x="6" y="4" />
  </svg>`;class zt extends W{render(){return G(p),this.spectrumVersion===1?Mt({hidden:!this.label,title:this.label}):Ye({hidden:!this.label,title:this.label})}}O("sp-icon-stop",zt);const Rt=({width:n=24,height:e=24,hidden:t=!1,title:s="Play"}={})=>M`<svg
    data-name="ICONS"
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M4.74902,18.00391c-.39795,0-.79541-.10742-1.15332-.32129-.68604-.41016-1.0957-1.13281-1.0957-1.93164V4.24902c0-.79883.40967-1.52148,1.0957-1.93164.68555-.40918,1.51514-.42969,2.21924-.0498l10.70117,5.75098c.73047.39258,1.18408,1.15234,1.18408,1.98145s-.45361,1.58887-1.18408,1.98145l-10.70117,5.75098c-.33643.18164-.70166.27148-1.06592.27148ZM4.75244,3.49609c-.17822,0-.31836.06836-.38721.10938-.10986.06543-.36523.25977-.36523.64355v11.50195c0,.38379.25537.57812.36523.64355s.40137.19824.73975.01758l10.70068-5.75098c.35596-.19238.39453-.52637.39453-.66113s-.03857-.46875-.39453-.66113L5.10498,3.58789c-.12646-.06738-.24609-.0918-.35254-.0918Z"
      fill="currentColor"
    />
  </svg>`,_t=({width:n=24,height:e=24,hidden:t=!1,title:s="Play"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M9.46 4H7a1 1 0 0 0-1 1v26a1 1 0 0 0 1 1h2.46a2 2 0 0 0 1.007-.272l22.064-12.866a1 1 0 0 0 0-1.724L10.467 4.272A2 2 0 0 0 9.46 4Z"
    />
  </svg>`;class Et extends W{render(){return G(p),this.spectrumVersion===2?Rt({hidden:!this.label,title:this.label}):_t({hidden:!this.label,title:this.label})}}O("sp-icon-play",Et);const Tt=({width:n=24,height:e=24,hidden:t=!1,title:s="Data"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M18,4.75c0-2.13379-4.02441-3.25-8-3.25S2,2.61621,2,4.75c0,.06714.01538.13037.02325.19556-.00629.03906-.02325.07422-.02325.11499v9.93945c0,2.06152,4.14697,3,8,3s8-.93848,8-3V5.06055c0-.04077-.01697-.07593-.02325-.11499.00787-.06519.02325-.12842.02325-.19556ZM16.50024,9.99451c-.0918.41516-2.22833,1.50549-6.50024,1.50549-4.27295,0-6.40967-1.09082-6.5-1.5v-3.27551c1.52985.84216,4.02393,1.27551,6.5,1.27551s4.97015-.43335,6.50006-1.27563l.00018,3.27014ZM10,3c4.28857,0,6.5,1.22656,6.5,1.75s-2.21143,1.75-6.5,1.75-6.5-1.22656-6.5-1.75,2.21143-1.75,6.5-1.75ZM10,16.5c-4.27295,0-6.40967-1.09082-6.5-1.5v-3.15356c1.55219.78394,4.08337,1.15356,6.5,1.15356,2.41681,0,4.94818-.36963,6.50031-1.15369l.00018,3.14783c-.09082.41504-2.22754,1.50586-6.50049,1.50586Z"
      fill="currentColor"
    />
  </svg>`,At=({width:n=24,height:e=24,hidden:t=!1,title:s="Data"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <ellipse cx="18" cy="7" rx="16" ry="5" />
    <path
      d="M18 24.275c-4.936 0-14.212-1.169-16-4V29c0 2.761 7.163 5 16 5s16-2.239 16-5v-8.73c-2.447 3.095-11.064 4.005-16 4.005Z"
    />
    <path
      d="M18 14.275c-4.936 0-14.212-1.169-16-4.005V17c0 2.761 7.163 5 16 5s16-2.239 16-5v-6.73c-2.447 3.095-11.064 4.005-16 4.005Z"
    />
  </svg>`;class Ft extends W{render(){return G(p),this.spectrumVersion===2?Tt({hidden:!this.label,title:this.label}):At({hidden:!this.label,title:this.label})}}O("sp-icon-data",Ft);var I=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};const Nt={status:{byteIndex:[0],type:"code",values:{192:{state:"none"},160:{state:"hover"},161:{state:"contact"},162:{state:"secondary-hover",secondaryButtonPressed:!0},163:{state:"secondary-contact",secondaryButtonPressed:!0},164:{state:"primary-hover",primaryButtonPressed:!0},165:{state:"primary-contact",primaryButtonPressed:!0},240:{state:"buttons"}}},x:{byteIndex:[1,2],type:"multi-byte-range",min:0,max:65535},y:{byteIndex:[3,4],type:"multi-byte-range",min:0,max:65535},pressure:{byteIndex:[5,6],type:"multi-byte-range",min:0,max:8191},tiltX:{byteIndex:[7],type:"bipolar-range",positiveMin:128,positiveMax:255,negativeMin:0,negativeMax:127},tiltY:{byteIndex:[8],type:"bipolar-range",positiveMin:128,positiveMax:255,negativeMin:0,negativeMax:127},tabletButtons:{byteIndex:[1],type:"bit-flags",buttonCount:8}};let S=class extends Y{constructor(){super(...arguments),this.mode="full",this.appTitle="BlankSlate Event Viewer",this.config=null,this.themeColor="light",this.hidConnected=!1,this.hidDeviceName="",this.websocketConnected=!1,this.websocketUrl="ws://localhost:8765",this.websocketServerInfo="",this.websocketDataMode="translated",this.isSimulating=!1,this.currentSimulation="",this.simulationDataMode="translated",this.tabletData={x:0,y:0,pressure:0,tiltX:0,tiltY:0,tiltXY:0,primaryButtonPressed:!1,secondaryButtonPressed:!1},this.pressedButtons=new Set,this.lastPressedButton=null,this.rawBytes=[],this.tabletEvents=[],this.packetCount=0,this.activeSource="none",this.isRawBytesTranslated=!1,this.isEventsTranslated=!1,this.hidDevice=null,this.mockDevice=null,this.websocket=null,this.currentReportId=null,this.pressedKeys=new Set,this.keyboardListenerBound=this._handleKeyDown.bind(this),this.keyupListenerBound=this._handleKeyUp.bind(this),this.cachedKeyboardButtonsConfig=null,this.cachedConvertedKeyboardMappings=null,this.mockDataOptions=[{id:"circle",label:"Draw Circle",action:e=>e.playCircle()},{id:"line",label:"Draw Line",action:e=>e.playLine()},{id:"scribble",label:"Scribble",action:e=>e.playScribble()},{id:"horizontal",label:"Horizontal Drag",action:e=>e.playHorizontalDrag()},{id:"vertical",label:"Vertical Drag",action:e=>e.playVerticalDrag()},{id:"hover-h",label:"Hover Horizontal",action:e=>e.playHoverHorizontalDrag()},{id:"hover-v",label:"Hover Vertical",action:e=>e.playHoverVerticalDrag()},{id:"tilt-x",label:"Tilt X Sweep",action:e=>e.playTiltXDrag()},{id:"tilt-y",label:"Tilt Y Sweep",action:e=>e.playTiltYDrag()},{id:"primary-btn",label:"Primary Button",action:e=>e.playPrimaryButtonDrag()},{id:"secondary-btn",label:"Secondary Button",action:e=>e.playSecondaryButtonDrag()},{id:"tablet-btns",label:"Tablet Buttons",action:e=>e.playTabletButtons(8)}]}connectedCallback(){super.connectedCallback(),this._initMockDevice(),window.addEventListener("keydown",this.keyboardListenerBound,{capture:!0}),window.addEventListener("keyup",this.keyupListenerBound,{capture:!0})}disconnectedCallback(){super.disconnectedCallback(),this._disconnectHid(),this._disconnectWebSocket(),this._stopSimulation(),window.removeEventListener("keydown",this.keyboardListenerBound,{capture:!0}),window.removeEventListener("keyup",this.keyupListenerBound,{capture:!0})}_cacheKeyboardButtonsConfig(){var e,t,s,i;if(this.cachedKeyboardButtonsConfig=null,this.cachedConvertedKeyboardMappings=null,!!((e=this.config)!=null&&e.modes))for(const r of this.config.modes){const o=(t=r.byteCodeMappings)==null?void 0:t.keyboardButtons;if((s=o==null?void 0:o.buttons)!=null&&s.length){this.cachedKeyboardButtonsConfig=o,this.cachedConvertedKeyboardMappings=Ze(o),console.log("[HIDDashboard] Cached keyboardButtons config:",{buttonCount:o.buttons.length,convertedMappings:((i=this.cachedConvertedKeyboardMappings)==null?void 0:i.buttons.length)??0});break}}}async _loadSampleConfig(){try{const e=await fetch("/configs/sample.json");if(!e.ok)throw new Error("Failed to fetch sample configuration");const t=await e.text(),s=Se.fromJSON(t);this.config=s,this._cacheKeyboardButtonsConfig(),this.dispatchEvent(new CustomEvent("config-loaded",{detail:{config:s},bubbles:!0,composed:!0})),this.mockDevice=null,this._initMockDevice()}catch(e){console.error("Failed to load sample config:",e)}}_handleLoadLocalConfig(){const e=document.createElement("input");e.type="file",e.accept=".json",e.onchange=async t=>{var i;const s=(i=t.target.files)==null?void 0:i[0];if(s)try{const r=await s.text(),o=Se.fromJSON(r);this.config=o,this._cacheKeyboardButtonsConfig(),this.dispatchEvent(new CustomEvent("config-loaded",{detail:{config:o},bubbles:!0,composed:!0}))}catch(r){console.error("Failed to load config:",r),alert("Failed to load configuration file. Please check the file format.")}},e.click()}_handleGoToGenerator(){this.dispatchEvent(new CustomEvent("go-to-generator",{bubbles:!0,composed:!0}))}_handleThemeToggle(){this.dispatchEvent(new CustomEvent("theme-toggle",{bubbles:!0,composed:!0}))}_initMockDevice(){var i,r,o,a;if(this.mockDevice)return;const e=(i=this.config)==null?void 0:i.getByteCodeMappings(),t=((r=e==null?void 0:e.x)==null?void 0:r.max)??65535,s=((o=e==null?void 0:e.y)==null?void 0:o.max)??65535;this.mockDevice=new lt({maxX:t,maxY:s,deviceName:"Mock "+(((a=this.config)==null?void 0:a.name)||"Tablet"),translateEvents:this.simulationDataMode==="translated",byteCodeMappings:e}),this.mockDevice.addEventListener("inputreport",c=>{this._processMockData(c)}),this.mockDevice.addEventListener("tablet-event",c=>{this._processTranslatedData(c,"mock")})}_processMockData(e){var i;if(this.activeSource="mock",this.isRawBytesTranslated=!1,this._updateRawBytes(e,"mock"),this.simulationDataMode==="translated")return;this.isEventsTranslated=!0;const t=((i=this.config)==null?void 0:i.getByteCodeMappings())??Nt,s=ne(e,t,-1);this._handleTabletData(s,"mock",!0)}_processTranslatedData(e,t){const s=new TextDecoder().decode(e),i=JSON.parse(s);this.isEventsTranslated=!1,t==="websocket"&&(this.isRawBytesTranslated=!0,this._synthesizeRawBytes(i)),this._handleTabletData(i,t,!1)}_updateRawBytes(e,t){this.packetCount++,this.activeSource=t,this.rawBytes=Array.from(e).map((s,i)=>{const r={byteIndex:i,value:s};if(this.config){const o=this.config.getByteCodeMappings();if(o){for(const[a,c]of Object.entries(o))if(c&&"byteIndex"in c&&c.byteIndex.includes(i)){r.label=a,r.isIdentified=!0;break}}}return r})}_synthesizeRawBytes(e){const t=Math.round((e.x??0)*65535),s=Math.round((e.y??0)*65535),i=Math.round((e.pressure??0)*8191),r=Math.round(((e.tiltX??0)+1)*127.5),o=Math.round(((e.tiltY??0)+1)*127.5),a=new Uint8Array([2,(e.primaryButtonPressed?1:0)|(e.secondaryButtonPressed?2:0),t&255,t>>8&255,s&255,s>>8&255,i&255,i>>8&255,r&255,o&255,e.button??0,0]);this.rawBytes=Array.from(a).map((c,l)=>{const d=["reportId","buttons","xLow","xHigh","yLow","yHigh","pressLow","pressHigh","tiltX","tiltY","tabletBtn","pad"];return{byteIndex:l,value:c,label:d[l]||void 0,isIdentified:l<d.length}})}_runSimulation(e){if(this._initMockDevice(),!this.mockDevice)return;this._stopSimulation(),this.isSimulating=!0,this.currentSimulation=e.label,this.activeSource="mock",e.action(this.mockDevice);const t=setInterval(()=>{this.mockDevice&&!this.mockDevice.playing&&(this.isSimulating=!1,this.currentSimulation="",clearInterval(t))},100)}_stopSimulation(){this.mockDevice&&this.mockDevice.stop(),this.isSimulating=!1,this.currentSimulation="",this.activeSource==="mock"&&(this.rawBytes=[],this.packetCount=0)}_setSimulationDataMode(e){this.simulationDataMode!==e&&(this.simulationDataMode=e,this.mockDevice&&(this._stopSimulation(),this.mockDevice=null,this._initMockDevice()))}async _handleConnectHid(){var e,t;if(!this.config){console.error("No config loaded");return}try{if((await navigator.hid.requestDevice({filters:[{vendorId:this.config.deviceInfo.vendor_id,productId:this.config.deviceInfo.product_id}]})).length===0)return;const r=(await navigator.hid.getDevices()).filter(g=>g.vendorId===this.config.deviceInfo.vendor_id&&g.productId===this.config.deviceInfo.product_id),o=((t=(e=this.config.modes)==null?void 0:e[0])==null?void 0:t.digitizerUsagePage)??13,a=r.find(g=>g.collections.some(v=>v.usagePage&&v.usagePage>=65280)),c=r.find(g=>g.collections.some(v=>v.usagePage===o)),l=r.find(g=>g.collections.some(v=>v.usagePage===13)),d=a||c||l||r[0],u=a&&l&&a!==l?l:null,f=r[0],h=f&&f!==d&&f!==u?f:null;if(!d){console.error("No suitable device interface found");return}if(this.hidDevice=d,this.hidDeviceName=d.productName||this.config.name,this.hidConnected=!0,!d.opened)try{await d.open()}catch(g){console.error("Failed to open device:",g),this.hidConnected=!1;return}if(d.addEventListener("error",g=>{console.error("HID Device Error:",g)}),d.addEventListener("inputreport",g=>{var z,_;const v=g.data,b=new Uint8Array(v.buffer,v.byteOffset,v.byteLength),m=g.reportId;if(this.currentReportId=m,this.isRawBytesTranslated=!1,this._updateRawBytes(b,"webhid"),(m===3||m===4||m===5)&&this.cachedKeyboardButtonsConfig){const E=$e(b,this.cachedKeyboardButtonsConfig,m);E&&Object.keys(E).length>0&&this._handleTabletData(E,"webhid",!0);return}let k=this.config.getByteCodeMappings(m),w=(z=this.config.modes)==null?void 0:z.find(E=>E.reportId===m);if(!k)if(w=(_=this.config.modes)==null?void 0:_.find(E=>E.buttonInterfaceReportId===m),w)k=w.byteCodeMappings;else return;const C=ne(b,k,-1,{buttonInterfaceReportId:w==null?void 0:w.buttonInterfaceReportId});this._handleTabletData(C,"webhid",!0)}),u)try{u.opened||await u.open(),u.addEventListener("inputreport",g=>{const v=g.data,b=new Uint8Array(v.buffer,v.byteOffset,v.byteLength),m=g.reportId;if(this.isRawBytesTranslated=!1,this._updateRawBytes(b,"webhid"),(m===3||m===4||m===5)&&this.cachedKeyboardButtonsConfig){const C=$e(b,this.cachedKeyboardButtonsConfig,m);C&&Object.keys(C).length>0&&this._handleTabletData(C,"webhid",!0);return}const k=this.config.getByteCodeMappings(m);if(!k)return;const w=ne(b,k,-1);this._handleTabletData(w,"webhid",!0)})}catch{}if(h)try{h.opened||await h.open(),h.addEventListener("inputreport",g=>{const v=g.data,b=new Uint8Array(v.buffer,v.byteOffset,v.byteLength),m=g.reportId;if(this.isRawBytesTranslated=!1,this._updateRawBytes(b,"webhid"),(m===3||m===4||m===5)&&this.cachedKeyboardButtonsConfig){const C=$e(b,this.cachedKeyboardButtonsConfig,m);C&&Object.keys(C).length>0&&this._handleTabletData(C,"webhid",!0);return}const k=this.config.getByteCodeMappings(m);if(!k)return;const w=ne(b,k,-1);this._handleTabletData(w,"webhid",!0)})}catch{}}catch(s){console.error("Failed to connect:",s),this.hidConnected=!1}}_handleTabletData(e,t,s=!1){this.activeSource=t;const i=typeof e.x=="number"?e.x:0,r=typeof e.y=="number"?e.y:0,o=typeof e.pressure=="number"?e.pressure:0,a=typeof e.tiltX=="number"?e.tiltX:0,c=typeof e.tiltY=="number"?e.tiltY:0,l=Math.sqrt(a*a+c*c)*Math.sign(a*c||1);this.tabletData={x:i,y:r,pressure:o,tiltX:a,tiltY:c,tiltXY:Math.min(1,Math.max(-1,l)),primaryButtonPressed:e.primaryButtonPressed??!1,secondaryButtonPressed:e.secondaryButtonPressed??!1},e.button!==void 0&&(e.button>0?(this.pressedButtons=new Set([e.button]),this.lastPressedButton=e.button):this.pressedButtons=new Set),this.isEventsTranslated=s;const d=e.button,u={timestamp:Date.now(),x:i,y:r,pressure:o,tiltX:a,tiltY:c,tiltXY:this.tabletData.tiltXY,primaryButtonPressed:e.primaryButtonPressed,secondaryButtonPressed:e.secondaryButtonPressed,button1:typeof e.button1=="boolean"?e.button1:d===1,button2:typeof e.button2=="boolean"?e.button2:d===2,button3:typeof e.button3=="boolean"?e.button3:d===3,button4:typeof e.button4=="boolean"?e.button4:d===4,button5:typeof e.button5=="boolean"?e.button5:d===5,button6:typeof e.button6=="boolean"?e.button6:d===6,button7:typeof e.button7=="boolean"?e.button7:d===7,button8:typeof e.button8=="boolean"?e.button8:d===8,state:e.state};this.tabletEvents=[...this.tabletEvents,u],this.tabletEvents.length>50&&(this.tabletEvents=this.tabletEvents.slice(-50))}_disconnectHid(){this.hidDevice&&(this.hidDevice.close(),this.hidDevice=null),this.hidConnected=!1,this.hidDeviceName="",this.activeSource==="webhid"&&this._resetTabletData()}_handleKeyDown(e){var t;e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||((this.cachedConvertedKeyboardMappings||(t=this.config)!=null&&t.keyboardMappings)&&(e.preventDefault(),e.stopPropagation()),this.pressedKeys.add(e.code),this._checkButtonMapping())}_handleKeyUp(e){var t;e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||((this.cachedConvertedKeyboardMappings||(t=this.config)!=null&&t.keyboardMappings)&&(e.preventDefault(),e.stopPropagation()),this.pressedKeys.delete(e.code),this.pressedKeys.size===0&&(this.pressedButtons=new Set))}_checkButtonMapping(){if(!this.config)return;let e=this.config.keyboardMappings;if(this.currentReportId!==null){const t=this.config.getModeByReportId(this.currentReportId);t!=null&&t.keyboardMappings&&(e=t.keyboardMappings)}else if(this.config.modes){for(const t of this.config.modes)if(t.keyboardMappings){e=t.keyboardMappings;break}}if(!e&&this.cachedConvertedKeyboardMappings&&(e=this.cachedConvertedKeyboardMappings),!!e)for(const t of e.buttons){const s=t.keys;if(s.length===this.pressedKeys.size&&s.every(i=>this.pressedKeys.has(i))){this.pressedButtons=new Set([t.button]),this.lastPressedButton=t.button;const i={timestamp:Date.now(),x:this.tabletData.x,y:this.tabletData.y,pressure:this.tabletData.pressure,tiltX:this.tabletData.tiltX,tiltY:this.tabletData.tiltY,tiltXY:this.tabletData.tiltXY,primaryButtonPressed:this.tabletData.primaryButtonPressed,secondaryButtonPressed:this.tabletData.secondaryButtonPressed,button1:t.button===1,button2:t.button===2,button3:t.button===3,button4:t.button===4,button5:t.button===5,button6:t.button===6,button7:t.button===7,button8:t.button===8,state:"buttons"};this.tabletEvents=[...this.tabletEvents,i],this.tabletEvents.length>50&&(this.tabletEvents=this.tabletEvents.slice(-50));break}}}_handleWebSocketUrlChange(e){const t=e.target;this.websocketUrl=t.value}_connectWebSocket(){if(!(this.websocketConnected||!this.websocketUrl))try{this.websocket=new WebSocket(this.websocketUrl),this.websocket.binaryType="arraybuffer",this.websocket.onopen=()=>{this.websocketConnected=!0},this.websocket.onmessage=e=>{if(typeof e.data=="string")try{const t=JSON.parse(e.data);this._handleWebSocketMessage(t)}catch{}else if(e.data instanceof Blob)e.data.arrayBuffer().then(t=>{const s=new Uint8Array(t);this._handleWebSocketRawBytes(s)});else if(e.data instanceof ArrayBuffer){const t=new Uint8Array(e.data);this._handleWebSocketRawBytes(t)}},this.websocket.onclose=()=>{this.websocketConnected=!1,this.websocketServerInfo="",this.websocket=null},this.websocket.onerror=()=>{this.websocketConnected=!1,this.websocket=null}}catch{}}_disconnectWebSocket(){this.websocket&&(this.websocket.close(),this.websocket=null),this.websocketConnected=!1,this.websocketServerInfo="",this.activeSource==="websocket"&&this._resetTabletData()}_handleWebSocketMessage(e){var t;if(e.type==="connected"){this.websocketServerInfo=((t=e.config)==null?void 0:t.name)||"WebSocket Server",e.dataFormat&&(this.websocketDataMode=e.dataFormat,e.dataFormat==="raw"&&e.fullConfig&&(this.config=new Se(e.fullConfig),this._cacheKeyboardButtonsConfig()));return}if(e.type==="tablet-data"){if(this.packetCount++,this.activeSource="websocket",this.isEventsTranslated=!1,this.isRawBytesTranslated=!0,this._synthesizeRawBytes(e),this.tabletData={x:e.x??0,y:e.y??0,pressure:e.pressure??0,tiltX:e.tiltX??0,tiltY:e.tiltY??0,tiltXY:e.tiltXY??0,primaryButtonPressed:e.primaryButtonPressed??!1,secondaryButtonPressed:e.secondaryButtonPressed??!1},e.tabletButtons!==void 0&&e.tabletButtons>0)this.pressedButtons=new Set([e.tabletButtons]),this.lastPressedButton=e.tabletButtons;else{const i=new Set;for(let r=1;r<=8;r++){const o=`button${r}`;e[o]&&(i.add(r),this.lastPressedButton=r)}this.pressedButtons=i}const s={timestamp:e.timestamp??Date.now(),x:e.x,y:e.y,pressure:e.pressure,tiltX:e.tiltX,tiltY:e.tiltY,tiltXY:e.tiltXY,primaryButtonPressed:e.primaryButtonPressed,secondaryButtonPressed:e.secondaryButtonPressed,button1:e.button1,button2:e.button2,button3:e.button3,button4:e.button4,button5:e.button5,button6:e.button6,button7:e.button7,button8:e.button8,state:e.state};this.tabletEvents=[...this.tabletEvents,s],this.tabletEvents.length>50&&(this.tabletEvents=this.tabletEvents.slice(-50))}}_handleWebSocketRawBytes(e){if(this.websocketDataMode!=="raw"&&(this.websocketDataMode="raw"),this.isRawBytesTranslated=!1,this.isEventsTranslated=!0,this._updateRawBytes(e,"websocket"),this.config){const t=this.config.getByteCodeMappings(),s=ne(e,t,-1);this._handleTabletData(s,"websocket",!0)}}_resetTabletData(){this.tabletData={x:0,y:0,pressure:0,tiltX:0,tiltY:0,tiltXY:0,primaryButtonPressed:!1,secondaryButtonPressed:!1},this.pressedButtons=new Set,this.rawBytes=[],this.packetCount=0}_formatValue(e,t=2){return e.toFixed(t)}render(){var a,c,l,d;const e=((a=this.config)==null?void 0:a.name)||(this.mode==="websocket"?"WebSocket Mode":"No Config Loaded"),t=this.hidConnected||this.websocketConnected||this.isSimulating,s=this.mode!=="websocket",i=this.mode==="full"||this.mode==="webhid",r=this.mode==="full"||this.mode==="websocket",o=this.mode!=="websocket";return p`
      <div class="dashboard">
        <div class="dashboard-header">
          <div class="header-info">
            <h1>${this.appTitle}</h1>
            <span class="config-name">${e}</span>
          </div>

          <div class="header-controls">
            <!-- Config Menu (hidden in websocket mode) -->
            ${s?p`
              <sp-action-menu
                label="Config menu"
                data-spectrum-pattern="action-menu"
                placement="bottom-start"
                @change=${u=>{const h=u.target.selectedItem;if(h){const g=h.value;g==="load-file"?this._handleLoadLocalConfig():g==="load-sample"?this._loadSampleConfig():g==="generate"&&this._handleGoToGenerator()}}}>
                <sp-icon-settings slot="icon"></sp-icon-settings>
                <span slot="label">Config</span>
                <sp-menu data-spectrum-pattern="menu" style="min-width: 200px;">
                  <sp-menu-item value="load-file" data-spectrum-pattern="menu-item">
                    <sp-icon-folder-open slot="icon"></sp-icon-folder-open>
                    Load from File
                  </sp-menu-item>
                  <sp-menu-item value="load-sample" data-spectrum-pattern="menu-item">
                    <sp-icon-document slot="icon"></sp-icon-document>
                    Load Sample Config
                  </sp-menu-item>
                  <sp-menu-item value="generate" data-spectrum-pattern="menu-item">
                    <sp-icon-magic-wand slot="icon"></sp-icon-magic-wand>
                    Generate New Config
                  </sp-menu-item>
                </sp-menu>
              </sp-action-menu>
            `:""}

            <!-- Theme Switcher -->
            <sp-action-button
              quiet
              @click=${this._handleThemeToggle}
              aria-label=${this.themeColor==="light"?"Switch to dark mode":"Switch to light mode"}>
              ${this.themeColor==="light"?p`<sp-icon-moon slot="icon"></sp-icon-moon>`:p`<sp-icon-light slot="icon"></sp-icon-light>`}
            </sp-action-button>
          </div>
        </div>

        <!-- Connection Controls Bar -->
        <div class="connection-bar">
          <!-- WebHID Connection (hidden in websocket mode) -->
          ${i?p`
            <div class="connection-section">
              <div class="connection-label">WebHID</div>
              ${this.hidConnected?p`
                <div class="connection-group">
                  <div class="status-badge connected">
                    <span class="status-dot"></span>
                    ${this.hidDeviceName}
                  </div>
                  <sp-button
                    variant="negative"
                    size="s"
                    data-spectrum-pattern="button-negative"
                    @click=${this._disconnectHid}>
                    Disconnect
                  </sp-button>
                </div>
              `:p`
                <sp-button
                  variant="accent"
                  size="s"
                  data-spectrum-pattern=${this.config?"button-accent":"button-disabled"}
                  @click=${this._handleConnectHid}
                  ?disabled=${!this.config}
                  title=${this.config?"Connect to tablet via WebHID":"Load a config first"}>
                  <sp-icon-link slot="icon"></sp-icon-link>
                  Connect WebHID
                </sp-button>
              `}
            </div>
          `:""}

          <!-- WebSocket Connection (hidden in webhid mode) -->
          ${r?p`
            <div class="connection-section">
              <div class="connection-label">WebSocket</div>
              ${this.websocketConnected?p`
                <div class="connection-group">
                  <div class="status-badge connected">
                    <span class="status-dot"></span>
                    ${this.websocketServerInfo||this.websocketUrl}
                  </div>
                  <sp-button
                    variant="negative"
                    size="s"
                    data-spectrum-pattern="button-negative"
                    @click=${this._disconnectWebSocket}>
                    Disconnect
                  </sp-button>
                </div>
              `:p`
                <div class="websocket-controls-inline">
                  <sp-textfield
                    class="websocket-url-input"
                    data-spectrum-pattern="textfield"
                    size="s"
                    .value=${this.websocketUrl}
                    @input=${this._handleWebSocketUrlChange}
                    @keydown=${u=>{u.key==="Enter"&&this._connectWebSocket()}}
                    placeholder="ws://localhost:8765">
                  </sp-textfield>
                  <sp-button
                    variant="secondary"
                    size="s"
                    data-spectrum-pattern="button-secondary"
                    @click=${this._connectWebSocket}>
                    <sp-icon-data slot="icon"></sp-icon-data>
                    Connect
                  </sp-button>
                </div>
              `}
            </div>
          `:""}

          <!-- Mock Data (hidden in websocket mode) -->
          ${o?p`
            <div class="connection-section">
              <div class="connection-label">Mock Data</div>
              <div class="mock-controls">
                <div class="data-mode-toggle" data-spectrum-pattern="button-group">
                  <button
                    class="mode-btn ${this.simulationDataMode==="raw"?"active":""}"
                    data-spectrum-pattern="toggle-button"
                    @click=${()=>this._setSimulationDataMode("raw")}
                    title="Simulate raw byte input">
                    Raw
                  </button>
                  <button
                    class="mode-btn ${this.simulationDataMode==="translated"?"active":""}"
                    data-spectrum-pattern="toggle-button"
                    @click=${()=>this._setSimulationDataMode("translated")}
                    title="Simulate translated event input">
                    Events
                  </button>
                </div>
                ${this.isSimulating?p`
                  <sp-button
                    variant="negative"
                    size="s"
                    data-spectrum-pattern="button-negative"
                    @click=${this._stopSimulation}>
                    <sp-icon-stop slot="icon"></sp-icon-stop>
                    Stop ${this.currentSimulation}
                  </sp-button>
                `:p`
                  <sp-action-menu
                    label="Simulate menu"
                    data-spectrum-pattern="action-menu"
                    placement="bottom-start"
                    size="s"
                    @change=${u=>{const h=u.target.selectedItem;if(h){const g=h.value,v=this.mockDataOptions.find(b=>b.label===g);v&&this._runSimulation(v)}}}>
                    <sp-icon-play slot="icon"></sp-icon-play>
                    <span slot="label">Simulate</span>
                    <sp-menu data-spectrum-pattern="menu" style="min-width: 200px;">
                      ${this.mockDataOptions.map(u=>p`
                        <sp-menu-item value="${u.label}" data-spectrum-pattern="menu-item">
                          ${u.label}
                        </sp-menu-item>
                      `)}
                    </sp-menu>
                  </sp-action-menu>
                `}
              </div>
            </div>
          `:""}
        </div>

        <div class="visualizers-grid">
          <!-- Coordinates Panel -->
          <div class="visualizer-card compact">
            <div class="visualizer-wrapper">
              <tablet-visualizer
                mode="tablet"
                .socketMode=${t}
                .tabletConnected=${t}
                .externalTabletData=${this.tabletData}
                .externalPressedButtons=${this.pressedButtons}
                .stringCount=${0}>
              </tablet-visualizer>
            </div>

            <div class="data-values compact">
              <div class="data-item">
                <span class="data-label">X</span>
                <span class="data-value ${this.tabletData.x===0?"zero":""}">
                  ${this._formatValue(this.tabletData.x)}
                </span>
              </div>
              <div class="data-item button-indicator ${this.pressedButtons.size>0?"pressed":""}">
                <span class="data-label">Btn</span>
                <span class="data-value">${this.lastPressedButton!==null?this.lastPressedButton:"–"}</span>
              </div>
              <div class="data-item">
                <span class="data-label">Y</span>
                <span class="data-value ${this.tabletData.y===0?"zero":""}">
                  ${this._formatValue(this.tabletData.y)}
                </span>
              </div>
            </div>
          </div>

          <!-- Pressure & Tilt Panel -->
          <div class="visualizer-card compact">
            <div class="visualizer-wrapper">
              <tablet-visualizer
                mode="tilt"
                .socketMode=${t}
                .tabletConnected=${t}
                .externalTabletData=${this.tabletData}
                .externalPressedButtons=${this.pressedButtons}
                .stringCount=${0}>
              </tablet-visualizer>
            </div>

            <div class="data-values compact">
              <div class="data-item">
                <span class="data-label">Pressure</span>
                <span class="data-value ${this.tabletData.pressure===0?"zero":""}">
                  ${this._formatValue(this.tabletData.pressure)}
                </span>
              </div>
              <div class="data-item">
                <span class="data-label">Tilt X</span>
                <span class="data-value ${this.tabletData.tiltX===0?"zero":""}">
                  ${this._formatValue(this.tabletData.tiltX)}
                </span>
              </div>
              <div class="data-item">
                <span class="data-label">Tilt Y</span>
                <span class="data-value ${this.tabletData.tiltY===0?"zero":""}">
                  ${this._formatValue(this.tabletData.tiltY)}
                </span>
              </div>
            </div>
          </div>

          <!-- Event Stream Panel (completes top row) -->
          <div class="visualizer-card events-panel">
            <events-display
              .events=${this.tabletEvents}
              .isEmpty=${this.tabletEvents.length===0}
              .deviceInfo=${{packetCount:this.packetCount,isMock:this.activeSource==="mock",isTranslated:this.isEventsTranslated}}>
            </events-display>
          </div>

          <!-- Raw Bytes Panel (full width row) -->
          <div class="visualizer-card bytes-panel">
            <bytes-display
              .bytes=${this.rawBytes}
              .isEmpty=${this.rawBytes.length===0}
              .placeholderCount=${10}
              .deviceInfo=${{isMock:this.activeSource==="mock",packetCount:this.packetCount,digitizerUsagePage:(d=(l=(c=this.config)==null?void 0:c.modes)==null?void 0:l[0])==null?void 0:d.digitizerUsagePage}}>
            </bytes-display>
          </div>
        </div>
      </div>
    `}};S.styles=pt;I([y({type:String})],S.prototype,"mode",void 0);I([y({type:String,attribute:"app-title"})],S.prototype,"appTitle",void 0);I([y({type:Object})],S.prototype,"config",void 0);I([y({type:String})],S.prototype,"themeColor",void 0);I([x()],S.prototype,"hidConnected",void 0);I([x()],S.prototype,"hidDeviceName",void 0);I([x()],S.prototype,"websocketConnected",void 0);I([x()],S.prototype,"websocketUrl",void 0);I([x()],S.prototype,"websocketServerInfo",void 0);I([x()],S.prototype,"websocketDataMode",void 0);I([x()],S.prototype,"isSimulating",void 0);I([x()],S.prototype,"currentSimulation",void 0);I([x()],S.prototype,"simulationDataMode",void 0);I([x()],S.prototype,"tabletData",void 0);I([x()],S.prototype,"pressedButtons",void 0);I([x()],S.prototype,"lastPressedButton",void 0);I([x()],S.prototype,"rawBytes",void 0);I([x()],S.prototype,"tabletEvents",void 0);I([x()],S.prototype,"packetCount",void 0);I([x()],S.prototype,"activeSource",void 0);I([x()],S.prototype,"isRawBytesTranslated",void 0);I([x()],S.prototype,"isEventsTranslated",void 0);I([x()],S.prototype,"currentReportId",void 0);S=I([j("hid-dashboard")],S);const Lt=U`
  :host {
    display: block;
    color: var(--spectrum-gray-900);
  }

  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 16px;
    margin-bottom: 20px;
    border-bottom: 1px solid var(--spectrum-gray-200);
  }

  .header-info h1 {
    margin: 0;
    font-size: 24px;
    font-weight: 700;
    color: var(--spectrum-gray-900);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
  }

  .header-controls {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .status-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 600;
  }

  .status-badge.connected {
    background: var(--spectrum-positive-background-color-default);
    color: var(--spectrum-positive-color-1000);
    border: 2px solid var(--spectrum-positive-color-900);
  }

  .status-icon {
    font-size: 16px;
  }

  .status-detail {
    font-size: 12px;
    opacity: 0.8;
  }

  .status-detail.warning {
    color: var(--spectrum-notice-color-1000);
  }

  .button.connect {
    background: var(--spectrum-positive-color-900);
    padding: 10px 20px;
  }

  .button.connect:hover:not(:disabled) {
    background: var(--spectrum-positive-color-1000);
  }

  .button.disconnect {
    background: var(--spectrum-negative-color-900) !important;
    color: var(--spectrum-white);
    padding: 8px 16px;
    border: none;
  }

  .button.disconnect:hover:not(:disabled) {
    background: var(--spectrum-negative-color-1000) !important;
  }

  .content {
    display: grid;
    gap: 20px;
  }

  .section {
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    padding: 20px;
    border: 1px solid var(--spectrum-gray-300);
  }

  .section h3 {
    margin: 0 0 15px 0;
    color: var(--spectrum-accent-color-900);
    font-size: 18px;
  }

  .section-header-with-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    gap: 20px;
  }

  .section-header-with-actions h3 {
    margin: 0;
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .gesture-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 15px;
  }

  .button {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .button:hover:not(:disabled) {
    background: var(--spectrum-accent-color-1000);
    transform: translateY(-1px);
    
  }

  .button:active:not(:disabled) {
    transform: translateY(0);
  }

  .button:disabled {
    background: var(--spectrum-gray-300);
    cursor: not-allowed;
    opacity: 0.6;
  }

  .button.stop {
    background: var(--spectrum-negative-color-900);
  }

  .button.stop:hover:not(:disabled) {
    background: var(--spectrum-negative-color-1000);
    
  }

  .button.clear {
    background: var(--spectrum-notice-color-900);
  }

  .button.clear:hover:not(:disabled) {
    background: var(--spectrum-notice-color-1000);
    
  }

  .button.primary {
    background: var(--spectrum-positive-color-900);
    font-size: 16px;
    padding: 12px 24px;
  }

  .button.primary:hover:not(:disabled) {
    background: var(--spectrum-positive-color-1000);
    
  }

  .button.hover {
    background: var(--spectrum-accent-color-1000);
  }

  .button.hover:hover:not(:disabled) {
    background: var(--spectrum-accent-color-1100);
    
  }

  .status-indicator {
    margin: 0;
    padding: 10px 15px;
    background: var(--spectrum-informative-background-color-default);
    border: 2px solid var(--spectrum-informative-color-900);
    border-radius: 6px;
    font-weight: 500;
    color: var(--spectrum-informative-color-1000);
  }

  .byte-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    padding: 10px;
    background: var(--spectrum-white);
    border-radius: 4px;
    font-size: 13px;
    color: var(--spectrum-gray-700);
  }

  .byte-display {
    background: var(--spectrum-gray-100);
    border-radius: 6px;
    padding: 20px;
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Courier New', monospace;
    font-size: 14px;
  }

  .empty-message {
    color: var(--spectrum-gray-500);
    text-align: center;
    padding: 20px;
    margin: 0;
  }

  .byte-packet {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 15px;
    background: var(--spectrum-gray-200);
    border-radius: 6px;
    border: 2px solid var(--spectrum-accent-color-900);
    width: 100%;
  }

  .packet-label {
    color: var(--spectrum-gray-500);
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 1px;
  }

  .packet-bytes {
    color: var(--spectrum-positive-color-900);
    font-weight: 500;
    font-size: 16px;
    word-break: break-all;
    line-height: 1.6;
  }

  /* Walkthrough styles */
  .walkthrough {
    border-left: 4px solid var(--spectrum-gray-400);
    background: var(--spectrum-gray-75);
  }

  .walkthrough.active {
    border-left-color: var(--spectrum-informative-color-900);
    background: var(--spectrum-gray-75);
    border: 1px solid var(--spectrum-gray-200);
    border-left: 4px solid var(--spectrum-informative-color-900);
  }

  .walkthrough.complete {
    border-left-color: var(--spectrum-gray-600);
    background: var(--spectrum-gray-100);
  }

  .walkthrough h3 {
    margin-top: 0;
    color: var(--spectrum-gray-900);
  }

  .walkthrough p {
    margin: 10px 0;
    line-height: 1.6;
  }

  .info-message {
    padding: 12px 16px;
    background: var(--spectrum-informative-background-color-default);
    border-left: 4px solid var(--spectrum-informative-color-900);
    border-radius: 4px;
    color: var(--spectrum-informative-color-1000);
    font-size: 14px;
    margin: 15px 0;
  }

  /* Device List Minimal */
  .device-list-minimal {
    margin-bottom: 20px;
    padding: 15px;
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    border: 1px solid var(--spectrum-gray-300);
  }

  .device-list-header {
    margin-bottom: 10px;
  }

  .device-count {
    font-size: 13px;
    color: var(--spectrum-gray-700);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .device-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .device-chip {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: var(--spectrum-white);
    border: 2px solid var(--spectrum-gray-300);
    border-radius: 20px;
    font-size: 13px;
    transition: all 0.2s ease;
  }

  .device-chip.active {
    border-color: var(--spectrum-positive-color-900);
    background: var(--spectrum-positive-background-color-default);
  }

  .device-chip.inactive {
    opacity: 0.6;
  }

  .chip-icon {
    font-size: 12px;
    line-height: 1;
  }

  .chip-label {
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .chip-badge {
    padding: 2px 6px;
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
  }

  .chip-badge.mock-badge {
    background: var(--spectrum-notice-color-900);
    color: var(--spectrum-white);
  }

  .chip-count {
    padding: 2px 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 10px;
    font-weight: 700;
  }

  /* Device Details */
  .device-details {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid var(--spectrum-gray-300);
  }

  .device-detail-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 0;
    font-size: 13px;
  }

  .detail-label {
    font-weight: 600;
    color: var(--spectrum-gray-900);
    min-width: 80px;
  }

  .detail-value {
    color: var(--spectrum-gray-700);
    padding: 2px 8px;
    background: transparent;
    border-radius: 4px;
    font-size: 12px;
  }

  .detail-badge {
    padding: 3px 8px;
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
  }

  .detail-badge.mock-badge {
    background: var(--spectrum-notice-color-900);
    color: var(--spectrum-white);
  }

  /* Active Streams Section */
  .active-streams-section {
    margin-top: 15px;
  }

  .active-streams-section h4 {
    margin: 0 0 10px 0;
    color: var(--spectrum-accent-color-900);
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  /* Device Streams */
  .device-streams-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .device-stream-panel {
    border: 2px solid var(--spectrum-gray-300);
    border-radius: 8px;
    background: var(--spectrum-white);
    transition: all 0.3s ease;
    overflow: hidden;
  }

  .device-stream-panel.active {
    border-color: var(--spectrum-positive-color-900);
    
  }

  .device-stream-panel.inactive {
    opacity: 0.6;
  }

  .stream-header {
    padding: 15px;
    background: var(--spectrum-gray-75);
    border-bottom: 1px solid var(--spectrum-gray-300);
  }

  .device-stream-panel.active .stream-header {
    background: var(--spectrum-positive-background-color-default);
  }

  .stream-title-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
  }

  .stream-title {
    font-weight: 600;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .active-badge {
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
  }

  .stream-count {
    font-size: 14px;
    color: var(--spectrum-gray-700);
    font-weight: 500;
  }

  .stream-metadata {
    display: flex;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
  }

  .metadata-item {
    display: flex;
    gap: 6px;
    font-size: 13px;
  }

  .metadata-label {
    color: var(--spectrum-gray-700);
    font-weight: 500;
  }

  .metadata-value {
    color: var(--spectrum-gray-900);
    font-weight: 600;
    font-family: 'Courier New', monospace;
  }

  .metadata-badge {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
  }

  .metadata-badge.digitizer {
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
  }

  .stream-byte-display {
    padding: 15px;
    background: var(--spectrum-white);
    min-height: 60px;
  }

  /* Accumulated Results */
  .accumulated-results {
    margin-top: 20px;
    padding: 20px;
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    border: 2px solid var(--spectrum-gray-300);
  }

  .accumulated-results h3 {
    margin: 0 0 15px 0;
    color: var(--spectrum-accent-color-900);
    font-size: 18px;
  }

  .result-item {
    margin-bottom: 20px;
    padding: 15px;
    background: var(--spectrum-white);
    border-radius: 6px;
    border-left: 4px solid var(--spectrum-accent-color-900);
  }

  .result-item:last-child {
    margin-bottom: 0;
  }

  .result-item h4 {
    margin: 0 0 5px 0;
    color: var(--spectrum-gray-900);
    font-size: 16px;
  }

  .result-description {
    margin: 0 0 15px 0;
    color: var(--spectrum-gray-700);
    font-size: 13px;
  }

  .byte-results {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }

  .byte-result-card {
    flex: 0 0 auto;
    min-width: 180px;
    padding: 12px;
    background: var(--spectrum-gray-100);
    border-radius: 6px;
    border: 1px solid var(--spectrum-gray-300);
  }

  .byte-index {
    font-weight: 700;
    color: var(--spectrum-accent-color-900);
    font-size: 14px;
    margin-bottom: 8px;
  }

  .byte-range,
  .byte-variance {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 4px;
    font-size: 13px;
  }

  .range-label,
  .variance-label {
    color: var(--spectrum-gray-700);
    font-weight: 500;
  }

  .range-value,
  .variance-value {
    color: var(--spectrum-gray-900);
    font-weight: 600;
    font-family: 'Courier New', monospace;
  }

  .status-values {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .status-value-card {
    padding: 10px;
    background: var(--spectrum-gray-100);
    border-radius: 6px;
    border: 1px solid var(--spectrum-gray-300);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .status-state {
    font-weight: 600;
    color: var(--spectrum-accent-color-900);
    text-transform: capitalize;
  }

  .status-value {
    font-family: 'Courier New', monospace;
    color: var(--spectrum-gray-900);
    font-weight: 600;
  }

  /* Live Analysis */
  .live-analysis {
    margin-top: 20px;
    padding: 20px;
    background: linear-gradient(135deg, var(--spectrum-accent-color-900) 0%, var(--spectrum-accent-color-1100) 100%);
    border-radius: 8px;
    color: var(--spectrum-white);
  }

  .live-analysis h4 {
    margin: 0 0 5px 0;
    color: var(--spectrum-white);
    font-size: 16px;
    font-weight: 700;
  }

  .analysis-subtitle {
    margin: 0 0 15px 0;
    color: var(--spectrum-white);
    font-size: 13px;
  }

  .analysis-subtitle.empty-state {
    padding: 46px 20px;
    text-align: center;
    font-size: 14px;
    margin: 0;
  }

  .live-bytes-grid {
    display: flex;
    flex-wrap: nowrap;
    gap: 8px;
    overflow-x: auto;
    padding: 0;
  }

  .live-byte-cell {
    position: relative;
    flex: 0 0 auto;
    min-width: 60px;
    height: 85px;
    padding: 10px 5px 6px 5px;
    background: var(--spectrum-gray-50);
    border-radius: 6px;
    text-align: center;
    transition: all 0.2s ease;
    box-sizing: border-box;
  }

  .live-byte-cell.best-guess {
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-notice-color-800);
    
    transform: scale(1.05);
  }

  .live-byte-cell.identified {
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-accent-color-900);
    
  }

  .live-byte-cell.empty-placeholder {
    background: var(--spectrum-gray-50);
    border: 2px dashed var(--spectrum-gray-300);
  }

  .live-byte-cell.empty-placeholder .byte-label,
  .live-byte-cell.empty-placeholder .byte-value,
  .live-byte-cell.empty-placeholder .byte-hex,
  .live-byte-cell.empty-placeholder .byte-meta {
    color: var(--spectrum-white);
  }

  .byte-type-label {
    position: absolute;
    top: -10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 2px 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
    white-space: nowrap;
    
  }

  .live-byte-cell.best-guess .byte-type-label {
    background: var(--spectrum-notice-color-800);
    color: var(--spectrum-gray-900);
  }

  .byte-label {
    font-size: 9px;
    font-weight: 600;
    color: var(--spectrum-gray-700);
    text-transform: uppercase;
    margin-bottom: 3px;
  }

  .live-byte-cell.best-guess .byte-label {
    color: var(--spectrum-accent-color-900);
    font-weight: 700;
  }

  .byte-value {
    font-size: 18px;
    font-weight: 900;
    color: var(--spectrum-gray-900);
    font-family: 'Courier New', monospace;
    margin-bottom: 2px;
    line-height: 1;
  }

  .live-byte-cell.best-guess .byte-value {
    color: var(--spectrum-accent-color-900);
    font-size: 20px;
  }

  .byte-hex {
    font-size: 10px;
    color: var(--spectrum-gray-600);
    font-family: 'Courier New', monospace;
    margin-bottom: 4px;
  }

  .live-byte-cell.best-guess .byte-hex {
    color: var(--spectrum-accent-color-900);
    font-weight: 600;
  }

  .byte-meta {
    font-size: 8px;
    color: var(--spectrum-gray-600);
    font-family: 'Courier New', monospace;
    line-height: 1.2;
    white-space: nowrap;
  }

  .live-byte-cell.best-guess .byte-meta {
    color: var(--spectrum-gray-700);
    font-weight: 600;
  }

  /* Button Group */
  .step-buttons {
    margin-top: 15px;
  }

  .capture-status {
    min-height: 44px;
    margin-bottom: 8px;
  }

  .packet-count {
    font-size: 14px;
    font-weight: 500;
    color: var(--spectrum-gray-800);
  }

  .filter-stats {
    font-size: 12px;
    color: var(--spectrum-gray-600);
  }

  .navigation-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 16px;
    align-items: center;
  }

  .bytes-detected-badge {
    display: inline-flex;
    align-items: center;
    padding: 4px 10px;
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
    margin-left: auto;
  }

  .button-group {
    display: flex;
    gap: 10px;
    margin-top: 10px;
  }

  .button.secondary {
    background: var(--spectrum-gray-700);
    color: var(--spectrum-white);
  }

  .button.secondary:hover {
    background: var(--spectrum-gray-800);
  }

  .stream-byte-display .empty-message {
    text-align: center;
    color: var(--spectrum-gray-600);
    font-size: 14px;
    font-style: italic;
    margin: 0;
    padding: 10px;
  }

  .stream-byte-display .byte-packet {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .stream-byte-display .packet-label {
    font-size: 11px;
    color: var(--spectrum-gray-700);
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.5px;
  }

  .stream-byte-display .packet-bytes {
    font-family: 'Courier New', monospace;
    font-size: 14px;
    color: var(--spectrum-informative-color-1000);
    word-break: break-all;
    line-height: 1.6;
    padding: 10px;
    background: var(--spectrum-gray-100);
    border-radius: 4px;
    border: 1px solid var(--spectrum-gray-300);
  }

  .walkthrough .button {
    margin: 15px 0;
    width: 100%;
    max-width: 300px;
    font-size: 16px;
    padding: 12px 24px;
  }

  .walkthrough-progress {
    display: flex;
    gap: 10px;
    margin: 20px 0;
  }

  .progress-step {
    flex: 1;
    padding: 10px;
    background: var(--spectrum-gray-300);
    border-radius: 6px;
    text-align: center;
    font-size: 13px;
    font-weight: 500;
    color: var(--spectrum-gray-700);
  }

  .progress-step.active {
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
  }

  .progress-step.complete {
    background: var(--spectrum-informative-color-900);
    color: var(--spectrum-gray-50);
  }

  /* Step header with title and progress bar */
  .step-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    gap: 15px;
  }

  .step-header h3 {
    margin: 0;
    flex: 1;
  }

  .icon-button {
    width: 32px;
    height: 32px;
    border: 2px solid var(--spectrum-accent-color-900);
    background: var(--spectrum-white);
    border-radius: 50%;
    cursor: pointer;
    font-size: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    padding: 0;
    flex-shrink: 0;
  }

  .icon-button:hover {
    background: var(--spectrum-accent-color-900);
    transform: scale(1.1);
    
  }

  .icon-button:active {
    transform: scale(0.95);
  }

  .icon-button:disabled {
    opacity: 0.3;
    cursor: not-allowed;
    pointer-events: none;
  }

  /* Step description with simulate button */
  .step-description {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 15px;
  }

  .step-description p {
    margin: 0;
    flex: 1;
  }

  .simulate-button {
    padding: 4px 10px;
    font-size: 12px;
    border: 1px solid var(--spectrum-accent-color-900);
    background: var(--spectrum-white);
    color: var(--spectrum-accent-color-900);
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s ease;
    white-space: nowrap;
    flex-shrink: 0;
  }

  .simulate-button:hover:not(:disabled) {
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
  }

  .simulate-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .button-group {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 8px;
  }

  /* Byte analysis styles */
  .byte-analysis {
    margin: 20px 0;
    display: grid;
    gap: 20px;
  }

  .analysis-section h4 {
    margin: 0 0 10px 0;
    color: var(--spectrum-accent-color-900);
    font-size: 16px;
  }

  .byte-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .byte-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px;
    background: var(--spectrum-white);
    border-radius: 6px;
    border-left: 3px solid var(--spectrum-accent-color-900);
    font-family: 'Courier New', monospace;
    font-size: 13px;
  }

  .byte-item.pressure {
    border-left-color: var(--spectrum-accent-color-1000);
  }

  .byte-item.pressure .byte-index {
    color: var(--spectrum-accent-color-1000);
  }

  .byte-index {
    font-weight: 600;
    color: var(--spectrum-accent-color-900);
    min-width: 80px;
  }

  .byte-range {
    color: var(--spectrum-positive-color-900);
    flex: 1;
  }

  .byte-variance {
    color: var(--spectrum-gray-700);
    font-size: 12px;
  }

  .no-data {
    color: var(--spectrum-gray-600);
    font-style: italic;
    margin: 10px 0;
  }

  /* Config display styles */
  .config-section {
    margin: 20px 0;
    padding: 0;
    background: transparent;
    border: none;
  }

  .config-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding: 15px 20px;
    background: linear-gradient(135deg, var(--spectrum-accent-color-900) 0%, var(--spectrum-accent-color-1100) 100%);
    border-radius: 8px;
    color: var(--spectrum-white);
  }

  .config-header h4 {
    margin: 0;
    color: var(--spectrum-white);
    font-size: 20px;
  }

  .config-actions {
    display: flex;
    gap: 10px;
  }

  .config-actions-only {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin: 20px 0;
  }

  .button.small {
    padding: 8px 16px;
    font-size: 13px;
    background: var(--spectrum-gray-50);
    backdrop-filter: blur(10px);
  }

  .button.small:hover:not(:disabled) {
    background: var(--spectrum-gray-50);
    transform: translateY(-1px);
  }

  .config-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
  }

  .config-card {
    background: var(--spectrum-white);
    border-radius: 12px;
    padding: 0;
    
    border: 1px solid var(--spectrum-gray-300);
    transition: all 0.2s ease;
    overflow: hidden;
  }

  .config-card:hover {
    
    transform: translateY(-2px);
  }

  .config-card.status-card {
    grid-column: 1 / -1;
  }

  .card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px 20px;
    background: linear-gradient(135deg, var(--spectrum-gray-100) 0%, var(--spectrum-gray-400) 100%);
    border-bottom: 2px solid var(--spectrum-gray-300);
  }

  .card-icon {
    font-size: 24px;
  }

  .card-header h5 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .card-body {
    padding: 20px;
  }

  .config-detail {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid var(--spectrum-gray-200);
  }

  .config-detail:last-child {
    border-bottom: none;
  }

  .detail-label {
    font-size: 13px;
    color: var(--spectrum-gray-700);
    font-weight: 500;
  }

  .detail-value {
    font-size: 14px;
    color: var(--spectrum-gray-900);
    font-weight: 600;
    font-family: 'Courier New', monospace;
  }

  .detail-value.highlight {
    color: var(--spectrum-positive-color-900);
    font-size: 16px;
  }

  .badge {
    padding: 4px 12px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .status-values {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 15px;
  }

  .status-value-item {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    padding: 12px;
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    border-left: 3px solid var(--spectrum-accent-color-900);
  }

  .status-byte {
    font-family: 'Courier New', monospace;
    font-weight: 600;
    color: var(--spectrum-accent-color-900);
    font-size: 13px;
    min-width: 120px;
  }

  .status-state {
    padding: 4px 10px;
    background: var(--spectrum-informative-background-color-default);
    color: var(--spectrum-informative-color-1000);
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    text-transform: capitalize;
  }

  .status-flag {
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .status-flag.primary {
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
  }

  .status-flag.secondary {
    background: var(--spectrum-notice-color-900);
    color: var(--spectrum-white);
  }

  /* Config Panel */
  .config-panel {
    margin: 20px 0;
    border: 2px solid var(--spectrum-accent-color-900);
    border-radius: 8px;
    overflow: hidden;
  }

  .config-panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    background: linear-gradient(135deg, var(--spectrum-accent-color-900) 0%, var(--spectrum-accent-color-1100) 100%);
    color: var(--spectrum-white);
    cursor: pointer;
    user-select: none;
    transition: background 0.2s ease;
  }

  .config-panel-header:hover {
    background: linear-gradient(135deg, var(--spectrum-accent-color-1000) 0%, var(--spectrum-accent-color-1100) 100%);
  }

  .config-panel-header h4 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
  }

  .collapse-icon {
    font-size: 12px;
    transition: transform 0.2s ease;
  }

  /* Message badges/tags */
  .message {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 0.02em;
    width: fit-content;
    margin-bottom: 8px;
  }

  .message.info {
    background: var(--spectrum-gray-200);
    color: var(--spectrum-gray-700);
    border: 1px solid var(--spectrum-gray-300);
  }

  .message.success {
    background: var(--spectrum-positive-background-color-default);
    color: var(--spectrum-positive-color-1000);
    border: 1px solid var(--spectrum-positive-color-400);
  }

  .message.error {
    background: var(--spectrum-negative-background-color-default);
    color: var(--spectrum-negative-color-1000);
    border: 1px solid var(--spectrum-negative-color-400);
  }

  .message.warning {
    background: var(--spectrum-notice-background-color-default);
    color: var(--spectrum-notice-color-1000);
    border: 1px solid var(--spectrum-notice-color-400);
  }
`,Ut={idle:null,"step1-horizontal":"horizontal","step2-vertical":"vertical","step3-pressure":"pressure","step4-hover-movement":"circle","step5-tilt-x":"tilt-x","step6-tilt-y":"tilt-y","step7-primary-button":"primary-button","step8-secondary-button":"secondary-button","step9-tablet-buttons":"tablet-buttons","step10-metadata":null,complete:null};function Ot(){const n={};for(const[e,t]of Object.entries(Ut)){const s=Le.steps[e]||{number:0,title:e,description:"",instructions:""};n[e]={id:e,number:s.number,title:s.title,description:s.description,instructions:s.instructions,gesture:t}}return n}const Te=Ot();function Ht(n){const e=["idle","step1-horizontal","step2-vertical","step3-pressure","step4-hover-movement","step5-tilt-x","step6-tilt-y","step7-primary-button","step8-secondary-button","step9-tablet-buttons","step10-metadata","complete"],t=e.indexOf(n);return t===-1||t>=e.length-1?"complete":e[t+1]}function Kt(n){const e=["idle","step1-horizontal","step2-vertical","step3-pressure","step4-hover-movement","step5-tilt-x","step6-tilt-y","step7-primary-button","step8-secondary-button","step9-tablet-buttons","step10-metadata","complete"],t=e.indexOf(n);return t<=0?"idle":e[t-1]}class jt{constructor(e={}){this.eventHandlers=new Set,this.captureBuffer=[],this.captureBufferWithReportId=[],this.statusByteValues=new Map,this.allPackets=[],this.lastPacket=null,this.duplicateCount=0,this.idlePacketCount=0,this.buttonMappings=[],this.detectedReportId=void 0,this.candidateReportIds=new Set,this.reportIdLocked=!1,this.detectedButtonReportId=void 0,this.buttonReportIdCandidates=new Set,this.options={minPacketsPerStep:e.minPacketsPerStep??50,minVarianceThreshold:e.minVarianceThreshold??50,autoAdvance:e.autoAdvance??!1,skipDuplicates:e.skipDuplicates??!0,filterIdlePackets:e.filterIdlePackets??!0,packetIncludesReportId:e.packetIncludesReportId??!0},this.state=this.createInitialState()}createInitialState(){return{currentStep:"idle",isCapturing:!1,stepData:new Map,deviceInfo:null,userMetadata:null,generatedConfig:null,completeConfig:null}}on(e){return this.eventHandlers.add(e),()=>this.eventHandlers.delete(e)}emit(e){this.eventHandlers.forEach(t=>{try{t(e)}catch(s){console.error("Error in walkthrough event handler:",s)}})}getState(){return{...this.state}}getCurrentStepInfo(){return Te[this.state.currentStep]}getCapturedPacketCount(){return this.captureBuffer.length}getCapturedPackets(){return[...this.captureBuffer]}getCapturedPacketsWithReportId(){return[...this.captureBufferWithReportId]}setDeviceInfo(e){this.state.deviceInfo=e}getDeviceInfo(){return this.state.deviceInfo}start(){this.state.currentStep="step1-horizontal",this.emit({type:"step-changed",step:this.state.currentStep})}reset(){this.state=this.createInitialState(),this.captureBuffer=[],this.statusByteValues.clear(),this.allPackets=[],this.detectedReportId=void 0,this.candidateReportIds.clear(),this.reportIdLocked=!1,this.detectedButtonReportId=void 0,this.buttonReportIdCandidates.clear(),this.emit({type:"step-changed",step:"idle"})}resetCurrentStep(){this.captureBuffer=[],this.state.stepData.delete(this.state.currentStep),this.state.isCapturing=!1}startCapture(){this.state.currentStep==="step10-metadata"||this.state.currentStep==="complete"||(this.captureBuffer=[],this.captureBufferWithReportId=[],this.lastPacket=null,this.duplicateCount=0,this.idlePacketCount=0,this.state.isCapturing=!0,this.emit({type:"capture-started",step:this.state.currentStep}))}stopCapture(){if(!this.state.isCapturing)return;this.state.isCapturing=!1;const e=this.captureBuffer.length;this.emit({type:"capture-stopped",step:this.state.currentStep,packetCount:e}),e>0&&this.processStepData()}processPacket(e,t){if(!this.state.isCapturing)return;const s=this.state.currentStep==="step9-tablet-buttons",i=this.options.packetIncludesReportId?1:0,r=this.options.packetIncludesReportId?2:1,o=e.length>r&&e.slice(r).some(c=>c!==0);if(t!==void 0&&(o&&this.candidateReportIds.add(t),s&&o&&(this.buttonReportIdCandidates.add(t),this.detectedButtonReportId===void 0&&(this.detectedButtonReportId=t)),this.candidateReportIds.size>0&&!this.reportIdLocked&&(this.detectedReportId=[...this.candidateReportIds][0],this.reportIdLocked=!0),!s&&this.reportIdLocked&&t!==this.detectedReportId))return;if(this.options.skipDuplicates&&this.lastPacket&&this.arePacketsEqual(e,this.lastPacket)){this.duplicateCount++;return}if(this.options.filterIdlePackets&&e.length>i&&!s){const c=e[i];if(!o){this.idlePacketCount++,this.trackStatusByte(c);return}}const a=new Uint8Array(e);if(this.captureBuffer.push(a),this.captureBufferWithReportId.push({packet:a,reportId:t}),this.allPackets.push(a),this.lastPacket=a,this.emit({type:"packet-received",packet:e,count:this.captureBuffer.length}),e.length>i){const c=e[i];this.trackStatusByte(c)}}arePacketsEqual(e,t){if(e.length!==t.length)return!1;for(let s=0;s<e.length;s++)if(e[s]!==t[s])return!1;return!0}getFilterStats(){return{duplicates:this.duplicateCount,idle:this.idlePacketCount,captured:this.captureBuffer.length}}trackStatusByte(e){const t={160:{state:"hover"},161:{state:"contact"},162:{state:"hover",secondaryButtonPressed:!0},163:{state:"contact",secondaryButtonPressed:!0},164:{state:"hover",primaryButtonPressed:!0},165:{state:"contact",primaryButtonPressed:!0}},s={192:{state:"hover"},193:{state:"contact"},194:{state:"hover",secondaryButtonPressed:!0},195:{state:"contact",secondaryButtonPressed:!0},196:{state:"hover",primaryButtonPressed:!0},197:{state:"contact",primaryButtonPressed:!0}},i={0:{state:"none"},240:{state:"buttons"}},r=this.statusByteValues.has(160)||e in t;if(e in t){this.statusByteValues.set(e,t[e]);const o=this.statusByteValues.get(192);o&&o.state==="hover"&&this.statusByteValues.set(192,{state:"none"});return}if(e===192){r?this.statusByteValues.set(e,{state:"none"}):this.statusByteValues.set(e,{state:"hover"});return}if(e in s){this.statusByteValues.set(e,s[e]);return}if(e in i){this.statusByteValues.set(e,i[e]);return}e>=1&&e<=6&&this.statusByteValues.set(e,{state:"buttons"})}processStepData(){const e=this.state.currentStep,t=[...this.captureBuffer],s=pe(t),i=this.detectBytesForStep(e,s),r={packets:t,detectedBytes:i,statusValues:new Map(this.statusByteValues)};this.state.stepData.set(e,r),this.emit({type:"bytes-detected",step:e,bytes:i})}storeButtonStepData(e){if(e.length===0)return;const s=pe(e).filter(r=>r.variance>0),i={packets:e,detectedBytes:s,statusValues:new Map(this.statusByteValues)};this.state.stepData.set("step9-tablet-buttons",i),this.emit({type:"bytes-detected",step:"step9-tablet-buttons",bytes:s})}getKnownByteIndices(){const e=new Set;this.options.packetIncludesReportId?(e.add(0),e.add(1)):e.add(0);const t=["step1-horizontal","step2-vertical","step3-pressure","step4-hover-movement","step5-tilt-x","step6-tilt-y"];for(const s of t){const i=this.state.stepData.get(s);i!=null&&i.detectedBytes&&i.detectedBytes.forEach(r=>e.add(r.byteIndex))}return e}detectBytesForStep(e,t){var c,l;const s=this.options.minVarianceThreshold,i=this.getKnownByteIndices(),r=this.options.packetIncludesReportId?1:0,o=this.options.packetIncludesReportId?0:-1;let a=t;switch(e!=="step1-horizontal"?a=t.filter(d=>!i.has(d.byteIndex)):a=t.filter(d=>d.byteIndex!==o&&d.byteIndex!==r),e){case"step1-horizontal":return de(a,2,s);case"step2-vertical":return de(a,2,s);case"step3-pressure":return de(a,2,s);case"step4-hover-movement":const d=((c=this.state.stepData.get("step1-horizontal"))==null?void 0:c.detectedBytes)??[],u=((l=this.state.stepData.get("step2-vertical"))==null?void 0:l.detectedBytes)??[];return[...d,...u];case"step5-tilt-x":return de(a,1,s);case"step6-tilt-y":{const f=this.state.stepData.get("step5-tilt-x"),h=new Set((f==null?void 0:f.detectedBytes.map(v=>v.byteIndex))??[]),g=a.filter(v=>!h.has(v.byteIndex));return de(g,1,s)}case"step9-tablet-buttons":{const f=new Set([160,161,192,162,163,164,165]),h=this.captureBuffer.filter(b=>{const m=b[r];return m===240||!f.has(m)});if(h.length>0){const b=h[0][r];this.statusByteValues.has(b)||this.statusByteValues.set(b,{state:"buttons"});const k=pe(h).filter(w=>!(w.byteIndex===r||w.byteIndex===o||w.variance===0));if(k.length>0)return k.slice(0,1)}return pe(this.captureBuffer).filter(b=>!(b.byteIndex===r||b.byteIndex===o||b.variance===0||i.has(b.byteIndex))).slice(0,1)}default:return[]}}nextStep(){const e=Ht(this.state.currentStep);this.state.currentStep=e,this.captureBuffer=[],this.emit({type:"step-changed",step:e})}previousStep(){const e=Kt(this.state.currentStep);this.state.currentStep=e,this.captureBuffer=[],this.emit({type:"step-changed",step:e})}goToStep(e){this.state.currentStep=e,this.captureBuffer=[],this.emit({type:"step-changed",step:e})}generateConfig(){const e=this.state.stepData.get("step1-horizontal"),t=this.state.stepData.get("step2-vertical"),s=this.state.stepData.get("step3-pressure"),i=this.state.stepData.get("step5-tilt-x"),r=this.state.stepData.get("step6-tilt-y"),o=this.state.stepData.get("step9-tablet-buttons"),a=Xe((e==null?void 0:e.detectedBytes)??[],(t==null?void 0:t.detectedBytes)??[],(s==null?void 0:s.detectedBytes)??[],(i==null?void 0:i.detectedBytes)??[],(r==null?void 0:r.detectedBytes)??[],this.statusByteValues,this.allPackets,(o==null?void 0:o.detectedBytes)??[],(i==null?void 0:i.packets)??[],(r==null?void 0:r.packets)??[],this.buttonMappings,this.options.packetIncludesReportId);this.state.generatedConfig=a,this.emit({type:"config-generated",config:a})}getStepBytes(e){var t;return((t=this.state.stepData.get(e))==null?void 0:t.detectedBytes)??[]}getStepData(e){return this.state.stepData.get(e)}getStatusByteValues(){return new Map(this.statusByteValues)}getDetectedReportId(){return this.detectedReportId}getDetectedButtonReportId(){return this.detectedButtonReportId}submitMetadata(e){if(this.state.userMetadata=e,this.generateConfig(),this.state.generatedConfig&&this.state.deviceInfo){const t={vendorId:this.state.deviceInfo.vendorId,productId:this.state.deviceInfo.productId,productName:this.state.deviceInfo.productName,collections:this.state.deviceInfo.collections,allInterfaces:this.state.deviceInfo.allInterfaces,detectedReportId:this.detectedReportId,detectedButtonReportId:this.detectedButtonReportId,dataSourceUsagePage:this.state.deviceInfo.dataSourceUsagePage},s={name:e.name,manufacturer:e.manufacturer,model:e.model,description:e.description,buttonCount:e.buttonCount};this.state.completeConfig=ct(t,s,this.state.generatedConfig,this.buttonMappings),this.state.currentStep="complete",this.emit({type:"step-changed",step:"complete"}),this.emit({type:"walkthrough-complete",config:this.state.completeConfig})}else this.emit({type:"error",message:"Cannot generate config: missing device info or byte mappings"})}getCompleteConfig(){return this.state.completeConfig}getByteCodeMappings(){return this.state.generatedConfig}hasEnoughData(){return this.captureBuffer.length>=this.options.minPacketsPerStep}getCurrentGesture(){return Te[this.state.currentStep].gesture}setButtonMappings(e){this.buttonMappings=e}getButtonMappings(){return[...this.buttonMappings]}exportState(){return{currentStep:this.state.currentStep,deviceInfo:this.state.deviceInfo,userMetadata:this.state.userMetadata,generatedConfig:this.state.generatedConfig,completeConfig:this.state.completeConfig,buttonMappings:this.buttonMappings,stepDataSummary:Array.from(this.state.stepData.entries()).map(([e,t])=>({step:e,packetCount:t.packets.length,detectedBytes:t.detectedBytes}))}}}class Yt{constructor(e,t,s={}){this.reader=null,this.isMockMode=!1,this.buttonCount=0,this.detectedButtons=[],this.buttonRawPackets=[],this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!1},this.view=e,this.readerFactory=t,this.options={minPacketsPerStep:s.minPacketsPerStep??50,minVarianceThreshold:s.minVarianceThreshold??30,autoAdvance:s.autoAdvance??!1,skipDuplicates:s.skipDuplicates??!0,filterIdlePackets:s.filterIdlePackets??!0,packetIncludesReportId:s.packetIncludesReportId??!0,autoPlayMockGestures:s.autoPlayMockGestures??!0,gesturePlayDuration:s.gesturePlayDuration??2e3,buttonConfirmations:s.buttonConfirmations??3},this.engine=new jt({minPacketsPerStep:this.options.minPacketsPerStep,minVarianceThreshold:this.options.minVarianceThreshold,autoAdvance:this.options.autoAdvance,skipDuplicates:this.options.skipDuplicates,filterIdlePackets:this.options.filterIdlePackets,packetIncludesReportId:this.options.packetIncludesReportId}),this.setupEngineEvents()}setupEngineEvents(){this.engine.on(e=>{switch(e.type){case"packet-received":this.captureStatus.packetCount=e.count,this.view.onCaptureProgress(this.captureStatus);break;case"bytes-detected":this.view.onBytesDetected(e.bytes);break;case"error":this.view.showError(e.message);break}})}getEngine(){return this.engine}getCurrentStepInfo(){return this.engine.getCurrentStepInfo()}getCurrentStep(){return this.engine.getState().currentStep}isCapturing(){return this.captureStatus.isCapturing}getCaptureStatus(){return{...this.captureStatus}}getDetectedButtons(){return[...this.detectedButtons]}async run(e){this.view.showHeader();let t;if(e?(t="mock",this.view.showInfo("Using mock data mode")):t=await this.view.promptDataSource(),t==="exit")return;if(!await this.initializeReader(t)){this.view.showError("Failed to initialize device reader");return}await this.runSteps(),await this.cleanup()}async initializeReader(e){if(e==="mock")return this.isMockMode=!0,this.reader=this.readerFactory.createMockReader(),this.engine.setDeviceInfo({vendorId:0,productId:0,productName:"Mock Tablet",collections:[{usagePage:13,usage:2}],allInterfaces:[13],detectedReportId:2}),this.view.showSuccess("Mock device initialized"),!0;{if(this.reader=await this.readerFactory.createDeviceReader(),!this.reader)return!1;const t=this.readerFactory.getDeviceInfo();return t&&this.engine.setDeviceInfo({vendorId:t.vendorId,productId:t.productId,productName:t.productName,collections:t.collections||[],allInterfaces:t.allInterfaces||[],dataSourceUsagePage:t.dataSourceUsagePage}),this.view.showSuccess("Device ready"),!0}}async runSteps(){for(this.engine.start();;){const e=this.getCurrentStep();if(e==="complete"){await this.handleCompletion();break}if(e==="step10-metadata"){await this.handleMetadataStep();continue}if(e==="step9-tablet-buttons"){await this.handleButtonDetectionStep();continue}await this.handleGestureStep()}}async handleGestureStep(){const e=this.getCurrentStepInfo();this.view.showStepInfo(e),await this.runCapture(e.gesture);const t=await this.view.promptNavigation();this.handleNavigation(t)}async handleButtonDetectionStep(){const e=this.getCurrentStepInfo();this.view.showStepInfo(e),this.buttonCount=await this.view.promptButtonCount(),this.buttonCount>0&&await this.runButtonDetection();const t=await this.view.promptNavigation();this.handleNavigation(t)}async handleMetadataStep(){const e=this.getCurrentStepInfo();this.view.showStepInfo(e);const t=await this.view.promptMetadata({buttonCount:this.buttonCount});this.engine.setButtonMappings(this.detectedButtons),this.engine.submitMetadata({name:t.name,manufacturer:t.manufacturer,model:t.model,description:t.description||"",buttonCount:t.buttonCount??this.buttonCount})}async handleCompletion(){const e=this.engine.getCompleteConfig();if(this.view.showCompletion(e),e){const{save:t,filename:s}=await this.view.promptSaveConfig(e);t&&s&&this.view.showSuccess(`Configuration saved to: ${s}`)}}async runCapture(e){if(!this.reader)return;this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!0},this.view.onCaptureStart(),this.reader.startReading((s,i)=>{this.engine.processPacket(s,i)}),this.engine.startCapture(),this.isMockMode&&e&&"playGestureForStep"in this.reader?(await this.reader.playGestureForStep(e,this.options.gesturePlayDuration),await new Promise(i=>setTimeout(i,500))):await this.view.waitForGestureComplete(),this.engine.stopCapture(),this.reader.stopReading();const t=this.engine.getFilterStats();this.captureStatus={packetCount:t.captured,duplicatesFiltered:t.duplicates,idleFiltered:t.idle,isCapturing:!1},this.view.onCaptureComplete(this.captureStatus)}async runButtonDetection(){this.detectedButtons=[],this.buttonRawPackets=[],this.view.showButtonDetectionStart(this.buttonCount);for(let e=1;e<=this.buttonCount;e++){const t=await this.detectSingleButton(e);t?(this.detectedButtons.push(t),this.view.showButtonDetected(t)):this.view.showButtonSkipped(e)}this.buttonRawPackets.length>0&&this.engine.storeButtonStepData(this.buttonRawPackets),this.view.showButtonDetectionSummary(this.detectedButtons,this.buttonCount)}async detectSingleButton(e){return this.reader?(this.view.showButtonDetectionPrompt(e),new Promise(t=>{let s=null,i=!1;const r=[],o=this.options.buttonConfirmations,a=l=>{i||(i=!0,this.reader.stopReading(),t(l))};this.view.waitForGestureComplete().then(()=>{s||a(null)});const c=(l,d,u)=>{if(!i){if(this.buttonRawPackets.push(new Uint8Array(l)),u==="keyboard"){const f=this.options.packetIncludesReportId?l[0]:d;if(f===3){const h=this.options.packetIncludesReportId?1:0,g=this.options.packetIncludesReportId?2:1,v=l.length>h?l[h]:0,b=l.length>g?l[g]:0;if(b===0)return;const m=v<<8|b;r.push({status:f,scanCode:m,interfaceType:"keyboard",modifier:v,keycode:b})}else if(f===4){const h=this.options.packetIncludesReportId?1:0,g=l.length>h?l[h]:0;if(g===0)return;r.push({status:f,scanCode:g,interfaceType:"keyboard",consumerCode:g})}else if(f===5){const h=this.options.packetIncludesReportId?6:5,g=l.length>h?l[h]>127?l[h]-256:l[h]:0;if(g===0)return;const v=g>0?1:-1;r.push({status:f,scanCode:v,interfaceType:"keyboard",scrollDelta:g})}else return}else{const f=this.options.packetIncludesReportId?1:0,h=this.options.packetIncludesReportId?2:1,g=l.length>f?l[f]:0,v=l.length>h?l[h]:0;if(v===0||g>=160&&g<=165||g===192||!new Set([0,1,3,6,240]).has(g))return;r.push({status:g,scanCode:v,interfaceType:"digitizer"})}if(r.length>=o){const f=new Map;for(const v of r){const b=`${v.interfaceType||"digitizer"}-${v.status}-${v.scanCode}`,m=f.get(b);m?m.count++:f.set(b,{count:1,packet:v})}let h=null,g=0;for(const[v,b]of f)b.count>g&&(g=b.count,h=b.packet);g>=o&&h&&(s={buttonNumber:e,statusByte:h.status,scanCode:h.scanCode,interfaceType:h.interfaceType,modifier:h.modifier,keycode:h.keycode,consumerCode:h.consumerCode,scrollDelta:h.scrollDelta},a(s))}}};this.reader.startReading(c)})):null}handleNavigation(e){switch(e){case"next":return this.engine.nextStep(),!0;case"retry":return this.engine.resetCurrentStep(),this.detectedButtons=[],!0;case"previous":return this.engine.previousStep(),!0;case"cancel":return!1}}nextStep(){this.engine.nextStep()}previousStep(){this.engine.previousStep()}resetStep(){this.engine.resetCurrentStep()}startCapture(){this.reader&&(this.captureStatus.isCapturing=!0,this.captureStatus.packetCount=0,this.reader.startReading((e,t)=>{this.engine.processPacket(e,t)}),this.engine.startCapture(),this.view.onCaptureStart())}stopCapture(){if(!this.reader)return;this.engine.stopCapture(),this.reader.stopReading();const e=this.engine.getFilterStats();this.captureStatus={packetCount:e.captured,duplicatesFiltered:e.duplicates,idleFiltered:e.idle,isCapturing:!1},this.view.onCaptureComplete(this.captureStatus)}setReader(e){this.reader=e}setDeviceInfo(e){this.engine.setDeviceInfo({vendorId:e.vendorId,productId:e.productId,productName:e.productName,collections:e.collections||[],allInterfaces:e.allInterfaces||[],dataSourceUsagePage:e.dataSourceUsagePage})}processPacket(e,t){this.engine.processPacket(e,t)}getGeneratedConfig(){return this.engine.getByteCodeMappings()}getCompleteConfig(){return this.engine.getCompleteConfig()}async cleanup(){if(this.reader){try{this.reader.stopReading(),await this.reader.close()}catch{}this.reader=null}}}class Wt{constructor(e={}){this._isOpen=!1,this.dataCallback=null,this.currentGenerator=null,this.playbackTimer=null,this.isPlaying=!1,this.config={vendorId:e.vendorId??0,productId:e.productId??1,productName:e.productName??"Mock Graphics Tablet",reportId:e.reportId??2,packetInterval:e.packetInterval??5,...e},this._deviceInfo={vendorId:this.config.vendorId,productId:this.config.productId,productName:this.config.productName,manufacturer:"Mock Device",usagePage:13,usage:2,collections:[{usagePage:13,usage:2}]},this.generator=new Ne({maxX:e.maxX??65535,maxY:e.maxY??65535,reportId:this.config.reportId,sampleRate:e.sampleRate??200,pressureVariation:e.pressureVariation??.2})}get isOpen(){return this._isOpen}get deviceInfo(){return this._deviceInfo}async open(){this._isOpen=!0}async close(){this.stopReading(),this._isOpen=!1}startReading(e,t){this.dataCallback=e}stopReading(){this.stop(),this.dataCallback=null}play(e){return new Promise(t=>{this.stop(),this.currentGenerator=e,this.isPlaying=!0,this.playbackTimer=setInterval(()=>{if(!this.currentGenerator||!this.isPlaying){this.stop(),t();return}const s=this.currentGenerator.next();if(s.done){this.stop(),t();return}this.dataCallback&&this.dataCallback(s.value,this.config.reportId)},this.config.packetInterval)})}stop(){this.isPlaying=!1,this.playbackTimer!==null&&(clearInterval(this.playbackTimer),this.playbackTimer=null),this.currentGenerator=null}get playing(){return this.isPlaying}playHorizontalDrag(e=.5,t=1500){return this.play(this.generator.generateLineConstantPressure(0,e,1,e,.5,t))}playVerticalDrag(e=.5,t=1500){return this.play(this.generator.generateLineConstantPressure(e,0,e,1,.5,t))}playPressureSweep(e=1500){return this.play(this.generator.generateLineConstantPressure(.5,.5,.5,.5,.5,e))}playCircle(e=.5,t=.5,s=.3,i=2e3){return this.play(this.generator.generateCircle(e,t,s,i))}playHoverCircle(e=.5,t=.5,s=2e3){const i=this.generator.generateHoverLine(e-.3,t,e+.3,t,s);return this.play(i)}playTiltXSweep(e=1500){return this.play(this.generator.generateTiltXLine(0,.5,1,.5,e))}playTiltYSweep(e=1500){return this.play(this.generator.generateTiltYLine(.5,0,.5,1,e))}playPrimaryButton(e=1500){return this.play(this.generator.generatePrimaryButtonLine(0,.5,1,.5,e))}playSecondaryButton(e=1500){return this.play(this.generator.generateSecondaryButtonLine(0,.5,1,.5,e))}playTabletButtons(e=8,t=2e3){return this.play(this.generator.generateTabletButtonSequence(e,t))}playHoverMovement(e=2e3){return this.play(this.generator.generateHoverLine(.2,.2,.8,.8,e))}async playGestureForStep(e,t=1500){switch(e){case"horizontal":return this.playHorizontalDrag(.5,t);case"vertical":return this.playVerticalDrag(.5,t);case"pressure":return this.playPressureSweep(t);case"circle":return this.playCircle(.5,.5,.3,t);case"hover":case"hover-movement":return this.playHoverMovement(t);case"tilt-x":return this.playTiltXSweep(t);case"tilt-y":return this.playTiltYSweep(t);case"primary-button":return this.playPrimaryButton(t);case"secondary-button":return this.playSecondaryButton(t);case"tablet-buttons":return this.playTabletButtons(8,t);default:console.warn(`Unknown gesture: ${e}`)}}}function Ae(n){return new Wt(n)}function Gt(n){var e,t;return{vendorId:n.vendorId,productId:n.productId,productName:n.productName||"Unknown Device",usagePage:(e=n.collections[0])==null?void 0:e.usagePage,usage:(t=n.collections[0])==null?void 0:t.usage,collections:n.collections.filter(s=>s.usagePage!==void 0&&s.usage!==void 0).map(s=>({usagePage:s.usagePage,usage:s.usage}))}}class Vt{constructor(e){this.dataCallback=null,this.inputReportHandler=null,this.device=e,this._deviceInfo=Gt(e)}get isOpen(){return this.device.opened}get deviceInfo(){return this._deviceInfo}get rawDevice(){return this.device}async open(){this.device.opened||await this.device.open()}async close(){this.stopReading(),this.device.opened&&await this.device.close()}startReading(e,t){this.dataCallback=e,this.reportIdFilter=t,this.inputReportHandler&&this.device.removeEventListener("inputreport",this.inputReportHandler),this.inputReportHandler=s=>{if(!this.dataCallback||this.reportIdFilter!==void 0&&s.reportId!==this.reportIdFilter)return;const i=s.data,r=new Uint8Array(i.buffer,i.byteOffset,i.byteLength);this.dataCallback(r,s.reportId)},this.device.addEventListener("inputreport",this.inputReportHandler)}stopReading(){this.inputReportHandler&&(this.device.removeEventListener("inputreport",this.inputReportHandler),this.inputReportHandler=null),this.dataCallback=null}}function qt(n){return new Vt(n)}const Xt=U`
  :host {
    display: block;
  }

  .hid-devices {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
  }

  .status-badge.connected {
    background: var(--spectrum-gray-200);
    color: var(--spectrum-gray-800);
    border: 1px solid var(--spectrum-gray-300);
  }

  .status-icon {
    font-size: 12px;
    color: var(--spectrum-positive-color-900);
  }

  .status-detail {
    font-size: 11px;
    color: var(--spectrum-gray-600);
  }

  .status-detail.warning {
    color: var(--spectrum-notice-color-900);
  }

  .button {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .button:hover:not(:disabled) {
    background: var(--spectrum-accent-color-1000);
    transform: translateY(-1px);
    
  }

  .button:active:not(:disabled) {
    transform: translateY(0);
  }

  .button:disabled {
    background: var(--spectrum-gray-300);
    cursor: not-allowed;
    opacity: 0.6;
  }

  .button.small {
    padding: 8px 16px;
    font-size: 13px;
  }

  .button.disconnect {
    background: var(--spectrum-negative-color-900) !important;
    color: var(--spectrum-white);
    padding: 8px 16px;
    border: none;
  }

  .button.disconnect:hover:not(:disabled) {
    background: var(--spectrum-negative-color-1000) !important;
  }
`,Zt=U`
  :host {
    display: block;
  }

  .device-list-minimal {
    padding: 15px;
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    border: 1px solid var(--spectrum-gray-300);
  }

  .device-list-header {
    margin-bottom: 10px;
  }

  .device-count {
    font-size: 13px;
    color: var(--spectrum-gray-700);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .device-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .device-chip {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-gray-300);
    border-radius: 20px;
    font-size: 13px;
    transition: all 0.2s ease;
  }

  .device-chip.active {
    border-color: var(--spectrum-positive-color-900);
    background: var(--spectrum-positive-background-color-default);
  }

  .device-chip.inactive {
    opacity: 0.6;
  }

  .chip-icon {
    font-size: 12px;
    line-height: 1;
  }

  .chip-label {
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .chip-badge {
    padding: 2px 6px;
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
  }

  .chip-badge.mock-badge {
    background: var(--spectrum-notice-color-900);
    color: var(--spectrum-white);
  }

  .chip-count {
    padding: 2px 6px;
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 10px;
    font-weight: 700;
  }

  .device-details {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid var(--spectrum-gray-300);
  }

  .device-detail-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 0;
    font-size: 13px;
  }

  .detail-label {
    font-weight: 600;
    color: var(--spectrum-gray-900);
    min-width: 80px;
  }

  .detail-value {
    color: var(--spectrum-gray-800);
    padding: 2px 8px;
    background: var(--spectrum-gray-200);
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 4px;
    font-size: 12px;
  }

  .detail-badge {
    padding: 3px 8px;
    background: var(--spectrum-positive-color-900);
    color: var(--spectrum-white);
    border-radius: 10px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
  }

  .detail-badge.mock-badge {
    background: var(--spectrum-notice-color-900);
    color: var(--spectrum-white);
  }
`;var ze=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let ue=class extends Y{constructor(){super(...arguments),this.streams=[],this.deviceDetails=new Map}render(){return p`
      <div class="device-list-minimal">
        <div class="device-list-header">
          <span class="device-count">${this.streams.length} interface${this.streams.length!==1?"s":""} detected</span>
        </div>
        <div class="device-chips">
          ${this.streams.map(e=>{const t=e.packetCount>0,s=e.index===-1,i=this.deviceDetails.get(e.index),r=(i==null?void 0:i.usagePage)===13&&(i==null?void 0:i.usage)===2,o=s?"Simulated":`Device ${e.index}`;return p`
              <div class="device-chip ${t?"active":"inactive"} ${s?"mock":""}">
                <span class="chip-icon">${t?"✅":"⚪"}</span>
                <span class="chip-label">${o}</span>
                ${r?p`<span class="chip-badge">Pen</span>`:""}
                ${s?p`<span class="chip-badge mock-badge">Mock</span>`:""}
                ${t?p`<span class="chip-count">${e.packetCount}</span>`:""}
              </div>
            `})}
        </div>

        <div class="device-details">
          ${this.streams.map(e=>{const t=e.index===-1,s=this.deviceDetails.get(e.index),i=(s==null?void 0:s.usagePage)===13&&(s==null?void 0:s.usage)===2,r=t?"Simulated":`Device ${e.index}`;return p`
              <div class="device-detail-row">
                <span class="detail-label">${r}:</span>
                ${t?p`
                  <span class="detail-value">Mock Data Generator</span>
                  <span class="detail-value">Usage Page: 13</span>
                  <span class="detail-value">Usage: 2</span>
                  <span class="detail-value">Packets: ${e.packetCount}</span>
                  <span class="detail-badge mock-badge">Simulated Pen</span>
                `:p`
                  <span class="detail-value">Usage Page: ${(s==null?void 0:s.usagePage)??"N/A"}</span>
                  <span class="detail-value">Usage: ${(s==null?void 0:s.usage)??"N/A"}</span>
                  <span class="detail-value">Packets: ${e.packetCount}</span>
                  ${i?p`<span class="detail-badge">Digitizer - Pen</span>`:""}
                `}
              </div>
            `})}
        </div>
      </div>
    `}};ue.styles=Zt;ze([y({type:Array})],ue.prototype,"streams",void 0);ze([y({type:Object})],ue.prototype,"deviceDetails",void 0);ue=ze([j("device-list-minimal")],ue);var X=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let K=class extends Y{constructor(){super(...arguments),this.streams=[],this.deviceDetails=new Map,this.bytes=[],this.bytesEmpty=!1,this.bytesPlaceholderCount=9,this.isConnected=!1,this.connectedDeviceName="",this.isDeviceOpened=!1}_handleDisconnect(){this.dispatchEvent(new CustomEvent("disconnect",{bubbles:!0,composed:!0}))}render(){return p`
      <div class="hid-devices">
        <div class="header-actions">
          ${this.isConnected?p`
            <div class="status-badge connected">
              <span class="status-icon">✓</span>
              <span>Connected: ${this.connectedDeviceName}</span>
              ${this.isDeviceOpened?p`<span class="status-detail">• Opened</span>`:p`<span class="status-detail warning">• Not Opened</span>`}
            </div>
            <sp-button
              size="s"
              variant="negative"
              data-spectrum-pattern="button-negative"
              @click="${this._handleDisconnect}">
              Disconnect
            </sp-button>
          `:""}
        </div>

        <device-list-minimal
          .streams=${this.streams}
          .deviceDetails=${this.deviceDetails}>
        </device-list-minimal>

        <bytes-display
          .bytes=${this.bytes}
          .isEmpty=${this.bytesEmpty}
          .placeholderCount=${this.bytesPlaceholderCount}
          .deviceInfo=${this.bytesDeviceInfo}>
        </bytes-display>
      </div>
    `}};K.styles=Xt;X([y({type:Array})],K.prototype,"streams",void 0);X([y({type:Object})],K.prototype,"deviceDetails",void 0);X([y({type:Array})],K.prototype,"bytes",void 0);X([y({type:Boolean})],K.prototype,"bytesEmpty",void 0);X([y({type:Number})],K.prototype,"bytesPlaceholderCount",void 0);X([y({type:Object})],K.prototype,"bytesDeviceInfo",void 0);X([y({type:Boolean})],K.prototype,"isConnected",void 0);X([y({type:String})],K.prototype,"connectedDeviceName",void 0);X([y({type:Boolean})],K.prototype,"isDeviceOpened",void 0);K=X([j("hid-devices")],K);const Jt=U`
  :host {
    display: block;
  }

  .config-container {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .config-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
  }

  .button {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .button.secondary {
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-gray-50);
  }

  .button.secondary:hover {
    background: var(--spectrum-accent-color-1000);
    transform: translateY(-1px);
    
  }

  .button.secondary:active {
    transform: translateY(0);
  }

  .config-display {
    background: var(--spectrum-gray-75);
    border: 1px solid var(--spectrum-gray-300);
    border-radius: 6px;
    padding: 20px;
    margin: 0;
    overflow-x: auto;
    font-family: 'Courier New', monospace;
    font-size: 13px;
    line-height: 1.6;
    color: var(--spectrum-gray-800);
  }

  .config-display code {
    font-family: inherit;
  }

  .no-config {
    padding: 20px;
    text-align: center;
    color: var(--spectrum-gray-600);
    font-style: italic;
  }
`,Qt=({width:n=24,height:e=24,hidden:t=!1,title:s="Copy"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="m11.75,18h-7.5c-1.24023,0-2.25-1.00977-2.25-2.25v-7.5c0-1.24023,1.00977-2.25,2.25-2.25.41406,0,.75.33594.75.75s-.33594.75-.75.75c-.41309,0-.75.33691-.75.75v7.5c0,.41309.33691.75.75.75h7.5c.41309,0,.75-.33691.75-.75,0-.41406.33594-.75.75-.75s.75.33594.75.75c0,1.24023-1.00977,2.25-2.25,2.25Z"
      fill="currentColor"
    />
    <path
      d="m6.75,5c-.41406,0-.75-.33594-.75-.75,0-1.24023,1.00977-2.25,2.25-2.25.41406,0,.75.33594.75.75s-.33594.75-.75.75c-.41309,0-.75.33691-.75.75,0,.41406-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m13,3.5h-2c-.41406,0-.75-.33594-.75-.75s.33594-.75.75-.75h2c.41406,0,.75.33594.75.75s-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m13,14h-2c-.41406,0-.75-.33594-.75-.75s.33594-.75.75-.75h2c.41406,0,.75.33594.75.75s-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m15.75,14c-.41406,0-.75-.33594-.75-.75s.33594-.75.75-.75c.41309,0,.75-.33691.75-.75,0-.41406.33594-.75.75-.75s.75.33594.75.75c0,1.24023-1.00977,2.25-2.25,2.25Z"
      fill="currentColor"
    />
    <path
      d="m17.25,5c-.41406,0-.75-.33594-.75-.75,0-.41309-.33691-.75-.75-.75-.41406,0-.75-.33594-.75-.75s.33594-.75.75-.75c1.24023,0,2.25,1.00977,2.25,2.25,0,.41406-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m17.25,9.75c-.41406,0-.75-.33594-.75-.75v-2c0-.41406.33594-.75.75-.75s.75.33594.75.75v2c0,.41406-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m6.75,9.75c-.41406,0-.75-.33594-.75-.75v-2c0-.41406.33594-.75.75-.75s.75.33594.75.75v2c0,.41406-.33594.75-.75.75Z"
      fill="currentColor"
    />
    <path
      d="m8.25,14c-1.24023,0-2.25-1.00977-2.25-2.25,0-.41406.33594-.75.75-.75s.75.33594.75.75c0,.41309.33691.75.75.75.41406,0,.75.33594.75.75s-.33594.75-.75.75Z"
      fill="currentColor"
    />
  </svg>`,es=({width:n=24,height:e=24,hidden:t=!1,title:s="Copy"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="22" />
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="18" />
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="14" />
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="10" />
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="6" />
    <rect height="2" rx=".5" ry=".5" width="2" x="32" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="28" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="24" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="20" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="16" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="2" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="6" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="10" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="14" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="18" />
    <rect height="2" rx=".5" ry=".5" width="2" x="12" y="22" />
    <rect height="2" rx=".5" ry=".5" width="2" x="16" y="22" />
    <rect height="2" rx=".5" ry=".5" width="2" x="20" y="22" />
    <rect height="2" rx=".5" ry=".5" width="2" x="24" y="22" />
    <rect height="2" rx=".5" ry=".5" width="2" x="28" y="22" />
    <path d="M10 12H3a1 1 0 0 0-1 1v20a1 1 0 0 0 1 1h20a1 1 0 0 0 1-1v-7H11a1 1 0 0 1-1-1Z" />
  </svg>`;class ts extends W{render(){return G(p),this.spectrumVersion===2?Qt({hidden:!this.label,title:this.label}):es({hidden:!this.label,title:this.label})}}O("sp-icon-copy",ts);const ss=({width:n=24,height:e=24,hidden:t=!1,title:s="Download"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="m13.53027,9.42676c-.29199-.29199-.7666-.29395-1.06055,0l-1.7168,1.71411V2.75c0-.41406-.33594-.75-.75-.75s-.75.33594-.75.75v8.39941l-1.72266-1.72266c-.29297-.29297-.76758-.29297-1.06055,0s-.29297.76758,0,1.06055l2.99805,2.99805c.14648.14648.33789.21973.53027.21973.19141,0,.38379-.07324.53027-.21973l3.00195-2.99805c.29297-.29199.29297-.76758,0-1.06055Z"
      fill="currentColor"
    />
    <path
      d="m15.75,18H4.25c-1.24023,0-2.25-1.00977-2.25-2.25v-2.02148c0-.41406.33594-.75.75-.75s.75.33594.75.75v2.02148c0,.41309.33691.75.75.75h11.5c.41309,0,.75-.33691.75-.75v-2.02148c0-.41406.33594-.75.75-.75s.75.33594.75.75v2.02148c0,1.24023-1.00977,2.25-2.25,2.25Z"
      fill="currentColor"
    />
  </svg>`,is=({width:n=24,height:e=24,hidden:t=!1,title:s="Save To"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M33 10h-6a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h3v16H6V14h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v22a1 1 0 0 0 1 1h30a1 1 0 0 0 1-1V11a1 1 0 0 0-1-1Z"
    />
    <path
      d="m10.2 17.331 7.445 7.525a.5.5 0 0 0 .7 0l7.455-7.525a.782.782 0 0 0 .2-.526.8.8 0 0 0-.8-.8H20V3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v13h-5.2a.8.8 0 0 0-.8.8.782.782 0 0 0 .2.531Z"
    />
  </svg>`;class rs extends W{render(){return G(p),this.spectrumVersion===2?ss({hidden:!this.label,title:this.label}):is({hidden:!this.label,title:this.label})}}O("sp-icon-download",rs);var Re=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let he=class extends Y{constructor(){super(...arguments),this.config=null,this.metadata=""}_getConfigWithMetadata(){if(!this.config)return"";let e="";return this.metadata&&(e+=this.metadata),e+=JSON.stringify(this.config,null,2),e}async _copyConfig(){if(!this.config)return;const e=this._getConfigWithMetadata();try{await navigator.clipboard.writeText(e),alert("Configuration copied to clipboard!")}catch(t){console.error("Failed to copy:",t),alert("Failed to copy to clipboard. Please try again.")}}_downloadConfig(){if(!this.config)return;const e=this._getConfigWithMetadata(),t=new Blob([e],{type:"application/json"}),s=URL.createObjectURL(t),i=document.createElement("a");i.href=s,i.download="device-byte-mappings.json",document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(s)}render(){if(!this.config)return p`<div class="no-config">No configuration available yet.</div>`;const e=this._getConfigWithMetadata();return p`
      <div class="config-container">
        <pre class="config-display"><code>${e}</code></pre>
        <div class="config-actions">
          <sp-button
            variant="secondary"
            data-spectrum-pattern="button-secondary"
            @click="${this._copyConfig}">
            <sp-icon-copy slot="icon"></sp-icon-copy>
            Copy JSON
          </sp-button>
          <sp-button
            variant="secondary"
            data-spectrum-pattern="button-secondary"
            @click="${this._downloadConfig}">
            <sp-icon-download slot="icon"></sp-icon-download>
            Download Config
          </sp-button>
        </div>
      </div>
    `}};he.styles=Jt;Re([y({type:Object})],he.prototype,"config",void 0);Re([y({type:String})],he.prototype,"metadata",void 0);he=Re([j("hid-json-config")],he);const os=U`
  :host {
    display: inline-flex;
    align-items: center;
  }

  .progress-container {
    display: flex;
    gap: 6px;
    align-items: center;
    padding: 6px 10px;
    background: var(--spectrum-gray-100);
    border-radius: 20px;
    border: 1px solid var(--spectrum-gray-200);
  }

  .progress-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--spectrum-gray-300);
    transition: all 0.2s ease;
  }

  .progress-dot.complete {
    background: var(--spectrum-gray-600);
  }

  .progress-dot.current {
    background: var(--spectrum-informative-color-900);
    box-shadow: 0 0 0 2px var(--spectrum-gray-100), 0 0 0 3px var(--spectrum-informative-color-900);
  }
`;var _e=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let ge=class extends Y{constructor(){super(...arguments),this.currentStep=0,this.totalSteps=10}render(){return p`
      <div class="progress-container">
        ${Array.from({length:this.totalSteps},(e,t)=>{const s=t<this.currentStep,i=t===this.currentStep;return p`
            <div class="progress-dot ${s?"complete":""} ${i?"current":""}"></div>
          `})}
      </div>
    `}};ge.styles=os;_e([y({type:Number})],ge.prototype,"currentStep",void 0);_e([y({type:Number})],ge.prototype,"totalSteps",void 0);ge=_e([j("hid-walkthrough-progress")],ge);const as=U`
            /*!
 * Copyright 2025 Adobe. All rights reserved. This file is licensed to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License./
 * 
 *  Override divider background color when used inside alert-dialog/
 * .divider {
 *     --spectrum-divider-background-color: var(--system-alert-dialog-divider-background-color);
 *     --spectrum-divider-background-color-static-white: var(--spectrum-alert-dialog-divider-background-color-static-white);
 *     --spectrum-divider-background-color-static-black: var(--spectrum-alert-dialog-divider-background-color-static-black);
 * }
 */
/*!
 * Copyright 2025 Adobe. All rights reserved. This file is licensed to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License./
 * 
 *  Override divider background color when used inside alert-dialog/
 * .divider {
 *     --spectrum-divider-background-color: var(--system-alert-dialog-divider-background-color);
 *     --spectrum-divider-background-color-static-white: var(--spectrum-alert-dialog-divider-background-color-static-white);
 *     --spectrum-divider-background-color-static-black: var(--spectrum-alert-dialog-divider-background-color-static-black);
 * }
 */
@media (forced-colors:active){:host{--highcontrast-helptext-content-color-default:CanvasText;--highcontrast-helptext-icon-color-default:CanvasText}:host,.text,.icon{forced-color-adjust:none}}:host{--spectrum-helptext-content-color-default:var(--spectrum-neutral-subdued-content-color-default);--spectrum-helptext-icon-color-default:var(--spectrum-neutral-subdued-content-color-default);color:var(--highcontrast-helptext-content-color-default,var(--mod-helptext-content-color-default,var(--spectrum-helptext-content-color-default)));font-size:var(--mod-helptext-font-size,var(--spectrum-helptext-font-size));min-block-size:var(--mod-helptext-min-height,var(--spectrum-helptext-min-height));display:flex}:host([size=s]){--spectrum-helptext-min-height:var(--spectrum-component-height-75);--spectrum-helptext-icon-size:var(--spectrum-workflow-icon-size-75);--spectrum-helptext-font-size:var(--spectrum-font-size-75);--spectrum-helptext-text-to-visual:var(--spectrum-text-to-visual-75);--spectrum-helptext-top-to-workflow-icon:var(--spectrum-help-text-top-to-workflow-icon-small);--spectrum-helptext-bottom-to-workflow-icon:var(--spectrum-helptext-top-to-workflow-icon)}:host,:host{--spectrum-helptext-min-height:var(--spectrum-component-height-75);--spectrum-helptext-icon-size:var(--spectrum-workflow-icon-size-100);--spectrum-helptext-font-size:var(--spectrum-font-size-75);--spectrum-helptext-text-to-visual:var(--spectrum-text-to-visual-75);--spectrum-helptext-top-to-workflow-icon:var(--spectrum-help-text-top-to-workflow-icon-medium);--spectrum-helptext-bottom-to-workflow-icon:var(--spectrum-helptext-top-to-workflow-icon)}:host([size=l]){--spectrum-helptext-min-height:var(--spectrum-component-height-100);--spectrum-helptext-icon-size:var(--spectrum-workflow-icon-size-200);--spectrum-helptext-font-size:var(--spectrum-font-size-100);--spectrum-helptext-text-to-visual:var(--spectrum-text-to-visual-100);--spectrum-helptext-top-to-workflow-icon:var(--spectrum-help-text-top-to-workflow-icon-large);--spectrum-helptext-bottom-to-workflow-icon:var(--spectrum-helptext-top-to-workflow-icon)}:host([size=xl]){--spectrum-helptext-min-height:var(--spectrum-component-height-200);--spectrum-helptext-icon-size:var(--spectrum-workflow-icon-size-300);--spectrum-helptext-font-size:var(--spectrum-font-size-200);--spectrum-helptext-text-to-visual:var(--spectrum-text-to-visual-200);--spectrum-helptext-top-to-workflow-icon:var(--spectrum-help-text-top-to-workflow-icon-extra-large);--spectrum-helptext-bottom-to-workflow-icon:var(--spectrum-helptext-top-to-workflow-icon)}:host([variant=neutral]){--spectrum-helptext-content-color-default:var(--spectrum-neutral-subdued-content-color-default);--spectrum-helptext-icon-color-default:var(--spectrum-neutral-subdued-content-color-default)}:host([variant=negative]){--spectrum-helptext-content-color-default:var(--spectrum-negative-color-900);--spectrum-helptext-icon-color-default:var(--spectrum-negative-color-900)}:host([disabled]){--spectrum-helptext-content-color-default:var(--spectrum-disabled-content-color);--spectrum-helptext-icon-color-default:var(--spectrum-disabled-content-color)}:host(:lang(ja)),:host(:lang(ko)),:host(:lang(zh)){--mod-helptext-line-height:var(--mod-helptext-line-height-cjk,var(--spectrum-cjk-line-height-100))}.icon{block-size:var(--mod-helptext-icon-size,var(--spectrum-helptext-icon-size));inline-size:var(--mod-helptext-icon-size,var(--spectrum-helptext-icon-size));flex-shrink:0;margin-inline-end:var(--mod-helptext-text-to-visual,var(--spectrum-helptext-text-to-visual));padding-block-start:var(--mod-helptext-top-to-workflow-icon,var(--spectrum-helptext-top-to-workflow-icon));padding-block-end:var(--mod-helptext-bottom-to-workflow-icon,var(--spectrum-helptext-bottom-to-workflow-icon))}.text{line-height:var(--mod-helptext-line-height,var(--spectrum-line-height-100));padding-block-start:var(--mod-helptext-top-to-text,var(--spectrum-helptext-top-to-text));padding-block-end:var(--mod-helptext-bottom-to-text,var(--spectrum-helptext-bottom-to-text))}:host([variant=neutral]) .text{color:var(--highcontrast-helptext-content-color-default,var(--mod-helptext-content-color-default,var(--spectrum-helptext-content-color-default)))}:host([variant=neutral]) .icon{color:var(--highcontrast-helptext-icon-color-default,var(--mod-helptext-icon-color-default,var(--spectrum-helptext-icon-color-default)))}:host([variant=negative]) .text{color:var(--highcontrast-helptext-content-color-default,var(--mod-helptext-content-color-default,var(--spectrum-helptext-content-color-default)))}:host([variant=negative]) .icon{color:var(--highcontrast-helptext-icon-color-default,var(--mod-helptext-icon-color-default,var(--spectrum-helptext-icon-color-default)))}:host([disabled]) .text{color:var(--highcontrast-helptext-content-color-default,var(--mod-helptext-content-color-default,var(--spectrum-helptext-content-color-default)))}:host([disabled]) .icon{color:var(--highcontrast-helptext-icon-color-default,var(--mod-helptext-icon-color-default,var(--spectrum-helptext-icon-color-default)))}
        `;var ns=Object.defineProperty,Fe=(n,e,t,s)=>{for(var i=void 0,r=n.length-1,o;r>=0;r--)(o=n[r])&&(i=o(e,t,i)||i);return i&&ns(e,t,i),i};class Me extends We(Ge,{noDefaultSize:!0}){constructor(){super(...arguments),this.icon=!1,this.variant="neutral"}static get styles(){return[as]}render(){return p`
            ${this.variant==="negative"&&this.icon?p`
                      <sp-icon-alert class="icon"></sp-icon-alert>
                  `:Ve}
            <div class="text"><slot></slot></div>
        `}}Fe([y({type:Boolean,reflect:!0})],Me.prototype,"icon"),Fe([y({reflect:!0})],Me.prototype,"variant");O("sp-help-text",Me);const cs=({width:n=24,height:e=24,hidden:t=!1,title:s="Refresh"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M18.20654,3.89746c-.40527-.09473-.80811.15039-.90527.55371l-.38043,1.57471c-1.39771-2.43188-4.00189-4.00439-6.92084-4.00439-3.68457,0-6.87549,2.5-7.75928,6.08008-.09961.40234.146.80859.54834.9082.40137.09961.80859-.14648.90771-.54883.71826-2.9082,3.31006-4.93945,6.30322-4.93945,2.51685,0,4.73499,1.44629,5.80896,3.63232l-2.10242-.5083c-.40332-.09375-.80762.15039-.90527.55371-.09717.40234.15039.80762.55273.90527l3.24524.78418c.12476.08862.27362.14258.43152.14258.05957,0,.12012-.00684.18018-.02148.04822-.01196.08582-.04102.12921-.06104.06952-.01855.14331-.01953.20575-.05811.16943-.10352.29102-.27051.33789-.46387l.87549-3.62402c.09717-.40234-.15039-.80762-.55273-.90527Z"
      fill="currentColor"
    />
    <path
      d="M17.21094,11.03223c-.39697-.09668-.80811.14648-.90771.54883-.71826,2.90918-3.31006,4.94043-6.30322,4.94043-2.51703,0-4.73523-1.44653-5.80914-3.63354l2.1026.50854c.40283.0918.80811-.15039.90527-.55371.09717-.40234-.15039-.80762-.55273-.90527l-3.25494-.78662c-.17102-.11816-.38531-.17139-.60199-.11865-.0152.00391-.026.01465-.04071.01929-.10321.01318-.20392.04419-.29425.09985-.16943.10352-.29102.27051-.33789.46387l-.87549,3.62402c-.09717.40234.15039.80762.55273.90527.05957.01367.11865.02051.17676.02051.33838,0,.64551-.23047.72852-.57422l.38043-1.57471c1.39764,2.43213,4.00189,4.00537,6.92084,4.00537,3.68457,0,6.87549-2.50098,7.75928-6.08105.09961-.40234-.146-.80859-.54834-.9082Z"
      fill="currentColor"
    />
  </svg>`,ls=({width:n=24,height:e=24,hidden:t=!1,title:s="Refresh"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 36 36"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M32.674 20H30.78a1.215 1.215 0 0 0-1.162.938 11.447 11.447 0 0 1-19.116 5.074l-.692-.693 3.955-3.955a.785.785 0 0 0 .235-.56.803.803 0 0 0-.754-.804H2.496a.5.5 0 0 0-.496.496v10.75a.803.803 0 0 0 .804.754.784.784 0 0 0 .56-.236l3.617-3.617.356.357a16.17 16.17 0 0 0 7.284 4.331A15.43 15.43 0 0 0 33.665 21.17a.996.996 0 0 0-.991-1.17ZM33.196 4a.784.784 0 0 0-.56.236l-3.617 3.617-.356-.357a16.17 16.17 0 0 0-7.284-4.331A15.43 15.43 0 0 0 2.335 14.83.996.996 0 0 0 3.326 16H5.22a1.216 1.216 0 0 0 1.162-.938 11.447 11.447 0 0 1 19.116-5.074l.692.693-3.955 3.955a.786.786 0 0 0-.235.56.804.804 0 0 0 .754.804h10.75a.5.5 0 0 0 .496-.496V4.754A.803.803 0 0 0 33.196 4Z"
    />
  </svg>`;class ds extends W{render(){return G(p),this.spectrumVersion===2?cs({hidden:!this.label,title:this.label}):ls({hidden:!this.label,title:this.label})}}O("sp-icon-refresh",ds);const ps=({width:n=24,height:e=24,hidden:t=!1,title:s="Save Floppy"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${n}"
    height="${e}"
    viewBox="0 0 20 20"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path
      d="M17.41406,4.10352l-1.51758-1.51758c-.37793-.37793-.87988-.58594-1.41406-.58594H4.25c-1.24072,0-2.25,1.00977-2.25,2.25v11.5c0,1.24023,1.00928,2.25,2.25,2.25h11.5c1.24072,0,2.25-1.00977,2.25-2.25V5.51758c0-.52637-.21338-1.04199-.58594-1.41406ZM7.75,3.5h4.5v3h-4.5v-3ZM13.25,16.5h-6.5v-4.5h6.5v4.5ZM16.5,15.75c0,.41309-.33643.75-.75.75h-1v-4.5c0-.82715-.67285-1.5-1.5-1.5h-6.5c-.82715,0-1.5.67285-1.5,1.5v4.5h-1c-.41357,0-.75-.33691-.75-.75V4.25c0-.41309.33643-.75.75-.75h2v3c0,.82715.67285,1.5,1.5,1.5h4.5c.82715,0,1.5-.67285,1.5-1.5v-3h.73242c.1333,0,.25879.05176.35352.14648l1.51758,1.51758c.09326.09277.14648.22168.14648.35352v10.23242Z"
      fill="currentColor"
    />
  </svg>`,us=({width:n=24,height:e=24,hidden:t=!1,title:s="Save Floppy"}={})=>M`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${e}"
    viewBox="0 0 36 36"
    width="${n}"
    aria-hidden=${t?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${s}"
  >
    <path d="M20 4h4v6h-4z" />
    <path
      d="M31.708 8.293s-4.015-4-4.146-4.114A.969.969 0 0 0 27 4h-1v8H14V4H5a1 1 0 0 0-1 1v26a1 1 0 0 0 1 1h26a1 1 0 0 0 1-1V9a1 1 0 0 0-.292-.707ZM26 30H10V16h16Z"
    />
  </svg>`;class hs extends W{render(){return G(p),this.spectrumVersion===2?ps({hidden:!this.label,title:this.label}):us({hidden:!this.label,title:this.label})}}O("sp-icon-save-floppy",hs);var ie=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};let Z=class extends Y{constructor(){super(...arguments),this.suggestedName="",this.suggestedManufacturer="",this.suggestedModel="",this.suggestedDescription="",this.suggestedButtonCount=0,this.formData={name:"",manufacturer:"",model:"",description:"",buttonCount:0}}connectedCallback(){super.connectedCallback(),this.suggestedName&&(this.formData.name=this.suggestedName),this.suggestedManufacturer&&(this.formData.manufacturer=this.suggestedManufacturer),this.suggestedModel&&(this.formData.model=this.suggestedModel),this.suggestedDescription&&(this.formData.description=this.suggestedDescription),this.suggestedButtonCount&&(this.formData.buttonCount=this.suggestedButtonCount)}_handleSubmit(e){e.preventDefault(),this.dispatchEvent(new CustomEvent("metadata-submit",{detail:this.formData,bubbles:!0,composed:!0}))}_handleCancel(){this.dispatchEvent(new CustomEvent("metadata-cancel",{bubbles:!0,composed:!0}))}render(){return p`
      <div class="form-container" data-spectrum-pattern="form">
        <div class="form-header">
          <h2>Device Configuration Details</h2>
          <p>Please provide additional information about your device to complete the configuration.</p>
        </div>

        <form @submit=${this._handleSubmit}>
          <div class="form-field">
            <sp-field-label for="name" required data-spectrum-pattern="field-label">Device Name</sp-field-label>
            <sp-textfield
              id="name"
              required
              data-spectrum-pattern="textfield"
              .value=${this.formData.name}
              @input=${e=>{this.formData.name=e.target.value}}
              placeholder="e.g., XP-Pen Deco 640">
            </sp-textfield>
          </div>

          <div class="form-field">
            <sp-field-label for="manufacturer" required data-spectrum-pattern="field-label">Manufacturer</sp-field-label>
            <sp-textfield
              id="manufacturer"
              required
              data-spectrum-pattern="textfield"
              .value=${this.formData.manufacturer}
              @input=${e=>{this.formData.manufacturer=e.target.value}}
              placeholder="e.g., XP-Pen">
            </sp-textfield>
          </div>

          <div class="form-field">
            <sp-field-label for="model" required data-spectrum-pattern="field-label">Model</sp-field-label>
            <sp-textfield
              id="model"
              required
              data-spectrum-pattern="textfield"
              .value=${this.formData.model}
              @input=${e=>{this.formData.model=e.target.value}}
              placeholder="e.g., Deco 640">
            </sp-textfield>
          </div>

          <div class="form-field">
            <sp-field-label for="description" required data-spectrum-pattern="field-label">Description</sp-field-label>
            <sp-textfield
              id="description"
              multiline
              required
              data-spectrum-pattern="textfield"
              .value=${this.formData.description}
              @input=${e=>{this.formData.description=e.target.value}}
              placeholder="e.g., XP-Pen Deco 640 graphics tablet with 8 express keys">
            </sp-textfield>
          </div>

          ${this.suggestedButtonCount>0?p`
            <!-- Button count already collected in step 9, show as read-only info -->
            <div class="form-field">
              <sp-field-label data-spectrum-pattern="field-label">Express Keys/Buttons</sp-field-label>
              <div class="readonly-value">${this.suggestedButtonCount} buttons detected in previous step</div>
            </div>
          `:p`
            <div class="form-field">
              <sp-field-label for="buttonCount" data-spectrum-pattern="field-label">Number of Express Keys/Buttons</sp-field-label>
              <sp-textfield
                type="number"
                id="buttonCount"
                data-spectrum-pattern="textfield"
                min="0"
                max="32"
                .value=${this.formData.buttonCount.toString()}
                @input=${e=>{this.formData.buttonCount=parseInt(e.target.value)||0}}>
              </sp-textfield>
              <sp-help-text data-spectrum-pattern="help-text">Enter 0 if your device has no express keys</sp-help-text>
            </div>
          `}

          <div class="form-actions">
            <sp-button
              type="button"
              variant="secondary"
              data-spectrum-pattern="button-secondary"
              @click=${this._handleCancel}>
              Cancel
            </sp-button>
            <sp-button
              type="submit"
              variant="accent"
              data-spectrum-pattern="button-accent">
              Generate Configuration
            </sp-button>
          </div>
        </form>
      </div>
    `}};Z.styles=U`
    :host {
      display: block;
      font-family: system-ui, -apple-system, sans-serif;
    }

    .form-container {
      background: #f5f5f5;
      border: 2px solid #ddd;
      border-radius: 8px;
      padding: 24px;
      max-width: 600px;
      margin: 0 auto;
    }

    .form-header {
      margin-bottom: 20px;
    }

    .form-header h2 {
      margin: 0 0 8px 0;
      color: #333;
      font-size: 1.5rem;
    }

    .form-header p {
      margin: 0;
      color: #666;
      font-size: 0.9rem;
    }

    .form-field {
      margin-bottom: 16px;
    }

    label {
      display: block;
      margin-bottom: 6px;
      color: #333;
      font-weight: 500;
      font-size: 0.9rem;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 0.95rem;
      font-family: inherit;
      box-sizing: border-box;
    }

    input:focus, textarea:focus {
      outline: none;
      border-color: #4CAF50;
      box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.1);
    }

    textarea {
      resize: vertical;
      min-height: 80px;
    }

    input[type="number"] {
      width: 120px;
    }

    .form-actions {
      display: flex;
      gap: 12px;
      margin-top: 24px;
      justify-content: flex-end;
    }

    button {
      padding: 10px 24px;
      border: none;
      border-radius: 4px;
      font-size: 0.95rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-primary {
      background: #4CAF50;
      color: white;
    }

    .btn-primary:hover {
      background: #45a049;
    }

    .btn-secondary {
      background: #ddd;
      color: #333;
    }

    .btn-secondary:hover {
      background: #ccc;
    }

    .hint {
      font-size: 0.85rem;
      color: #666;
      margin-top: 4px;
    }

    .readonly-value {
      padding: 10px;
      background: #e8f5e9;
      border: 1px solid #c8e6c9;
      border-radius: 4px;
      color: #2e7d32;
      font-size: 0.95rem;
    }
  `;ie([y({type:String})],Z.prototype,"suggestedName",void 0);ie([y({type:String})],Z.prototype,"suggestedManufacturer",void 0);ie([y({type:String})],Z.prototype,"suggestedModel",void 0);ie([y({type:String})],Z.prototype,"suggestedDescription",void 0);ie([y({type:Number})],Z.prototype,"suggestedButtonCount",void 0);ie([x()],Z.prototype,"formData",void 0);Z=ie([j("device-metadata-form")],Z);var N=function(n,e,t,s){var i=arguments.length,r=i<3?e:s===null?s=Object.getOwnPropertyDescriptor(e,t):s,o;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")r=Reflect.decorate(n,e,t,s);else for(var a=n.length-1;a>=0;a--)(o=n[a])&&(r=(i<3?o(r):i>3?o(e,t,r):o(e,t))||r);return i>3&&r&&Object.defineProperty(e,t,r),r};const xe=Le;let R=class extends Y{constructor(){super(),this.mockReader=null,this.webReaders=[],this.activeReader=null,this.isPlaying=!1,this.isMockMode=!0,this.walkthroughStep="idle",this.stepInfo=null,this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!1},this.detectedBytes=[],this.messages=[],this.detectedButtons=[],this.currentButtonPrompt=null,this.buttonCount=0,this.isRealDevice=!1,this.realDeviceName="",this.isConnecting=!1,this.completeConfig=null,this.isConfigPanelExpanded=!0,this.deviceDataStreams=new Map,this.currentActiveDeviceIndex=void 0,this.pendingDataSource=null,this.pendingNavigation=null,this.pendingButtonCount=null,this.pendingMetadata=null,this.pendingSaveConfig=null,this.pendingGestureComplete=null,this.capturedPackets=[],this.lastCapturedPackets=[],this.latestDisplayPacket=null,this.deviceMetadata={vendorId:0,productId:0,productName:""},this._keyHandler=null,this.controller=new Yt(this,this._createReaderFactory(),{autoPlayMockGestures:!0,gesturePlayDuration:2e3,buttonConfirmations:3,packetIncludesReportId:!1});const e=this.controller.getEngine();e.on(t=>{switch(t.type){case"packet-received":this.captureStatus.packetCount=t.count,this.captureStatus.isCapturing&&this.capturedPackets.push(new Uint8Array(t.packet)),this.requestUpdate();break;case"bytes-detected":this.detectedBytes=t.bytes,this.requestUpdate();break;case"step-changed":if(this.walkthroughStep=t.step,this.stepInfo=this.controller.getCurrentStepInfo(),t.step==="step9-tablet-buttons"){this.capturedPackets=[],this.detectedButtons=[],this.currentButtonPrompt=null,this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!1},this.pendingButtonCount=i=>{this.buttonCount=i,i>0&&this._startButtonDetection()},this.requestUpdate();break}t.step.startsWith("step")&&t.step!=="step10-metadata"?(this.capturedPackets=[],this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!0},e.startCapture()):this.captureStatus.isCapturing&&(e.stopCapture(),this.captureStatus.isCapturing=!1),this.requestUpdate();break;case"config-generated":break;case"walkthrough-complete":this.completeConfig=t.config,this.walkthroughStep="complete",this.isConfigPanelExpanded=!0,this.requestUpdate();break;case"error":this.showError(t.message);break}})}_createReaderFactory(){const e=this;return{createMockReader(){return e.isMockMode=!0,e.mockReader=Ae({productName:"Mock Graphics Tablet",vendorId:0,productId:0}),e.mockReader},async createDeviceReader(){return e.isMockMode=!1,e.webReaders.length>0&&e.webReaders[0].isOpen?e.webReaders[0]:null},getDeviceInfo(){return e.deviceMetadata.vendorId?e.deviceMetadata:null}}}connectedCallback(){super.connectedCallback(),this._setupMockReader(),this._setupDeviceFinder(),this._checkForRealDevice(),this._keyHandler=e=>{e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||(e.key==="Enter"&&!e.ctrlKey&&!e.metaKey&&this.captureStatus.packetCount>0&&!this.isPlaying&&this.stepInfo&&(e.preventDefault(),this._handleStepNext()),e.key==="9"&&!e.ctrlKey&&!e.metaKey&&(console.log("[DEBUG] Jumping to step 9"),this.controller.getEngine().goToStep("step9-tablet-buttons"),this.walkthroughStep="step9-tablet-buttons",this.stepInfo=this.controller.getCurrentStepInfo(),this.requestUpdate()))},window.addEventListener("keydown",this._keyHandler)}disconnectedCallback(){super.disconnectedCallback(),this.controller.cleanup(),this._disconnectRealDevice(),this._keyHandler&&window.removeEventListener("keydown",this._keyHandler)}showHeader(){}showStepInfo(e){this.stepInfo=e,this.walkthroughStep=e.id,this.detectedBytes=[],this.messages=[],this.capturedPackets=[],this.requestUpdate()}showCompletion(e){this.walkthroughStep="complete",this.completeConfig=e,this.isConfigPanelExpanded=!0,this.requestUpdate()}showError(e){this.messages=[...this.messages,{type:"error",text:e}],this.requestUpdate()}showSuccess(e){this.messages=[...this.messages,{type:"success",text:e}],this.requestUpdate()}showInfo(e){this.messages=[...this.messages,{type:"info",text:e}],this.requestUpdate()}onCaptureStart(){this.captureStatus={...this.captureStatus,isCapturing:!0,packetCount:0},this.capturedPackets=[],this.requestUpdate()}onCaptureProgress(e){this.captureStatus={...e},this.requestUpdate()}onCaptureComplete(e){this.captureStatus={...e,isCapturing:!1},this.lastCapturedPackets=[...this.capturedPackets],this.requestUpdate()}onBytesDetected(e){this.detectedBytes=e,this.requestUpdate()}async promptDataSource(){return new Promise(e=>{this.pendingDataSource=e,this.requestUpdate()})}async promptNavigation(){return new Promise(e=>{this.pendingNavigation=e,this.requestUpdate()})}async promptButtonCount(){return new Promise(e=>{this.pendingButtonCount=e,this.requestUpdate()})}async promptMetadata(e){return new Promise(t=>{this.pendingMetadata=t,this.requestUpdate()})}async promptSaveConfig(e){return new Promise(t=>{this.pendingSaveConfig=t,this.requestUpdate()})}showButtonDetectionStart(e){this.buttonCount=e,this.detectedButtons=[],this.showInfo(`We'll now detect each of your ${e} button(s).`),this.requestUpdate()}showButtonDetectionPrompt(e){this.currentButtonPrompt=e,this.requestUpdate()}showButtonDetected(e){this.detectedButtons=[...this.detectedButtons,e],this.currentButtonPrompt=null,this.requestUpdate()}showButtonSkipped(e){this.currentButtonPrompt=null,this.showInfo(`Button ${e} skipped`),this.requestUpdate()}showButtonDetectionSummary(e,t){this.detectedButtons=e,this.currentButtonPrompt=null,this.requestUpdate()}async waitForGestureComplete(){return new Promise(e=>{this.pendingGestureComplete=e})}handleDataSourceSelect(e){this.pendingDataSource&&(this.pendingDataSource(e),this.pendingDataSource=null)}handleButtonCountSubmit(e){this.pendingButtonCount&&(this.pendingButtonCount(e),this.pendingButtonCount=null)}handleMetadataSubmit(e){if(this.pendingMetadata){this.pendingMetadata(e.detail),this.pendingMetadata=null;return}const t=e.detail,s=this.controller.getEngine();s.submitMetadata({name:t.name,manufacturer:t.manufacturer,model:t.model,description:t.description??"",buttonCount:t.buttonCount??0}),this.completeConfig=s.getCompleteConfig()??null,this.walkthroughStep="complete",this.pendingSaveConfig=()=>{},this.requestUpdate()}handleMetadataCancel(){this._resetWalkthrough()}async _startButtonDetection(){const e=this.controller.getEngine(),t=3;this.detectedButtons=[];for(let s=1;s<=this.buttonCount;s++){this.currentButtonPrompt=s,this.capturedPackets=[],this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!0},e.startCapture(),this.requestUpdate();const i=await this._detectSingleButton(s,t);e.stopCapture(),this.captureStatus.isCapturing=!1,i&&(this.detectedButtons=[...this.detectedButtons,i]),this.currentButtonPrompt=null,this.requestUpdate()}e.setButtonMappings(this.detectedButtons.map(s=>{let i;if(s.code){const r=[];s.ctrlKey&&r.push("ControlLeft"),s.shiftKey&&r.push("ShiftLeft"),s.altKey&&r.push("AltLeft"),s.metaKey&&r.push("MetaLeft"),r.push(s.code),i=r.join("+")}return{buttonNumber:s.buttonNumber,statusByte:s.statusByte,scanCode:s.scanCode,key:s.key,code:i,ctrlKey:s.ctrlKey,shiftKey:s.shiftKey,altKey:s.altKey,metaKey:s.metaKey}})),this.showInfo(`Detected ${this.detectedButtons.length} of ${this.buttonCount} buttons`),this.requestUpdate()}async _detectSingleButton(e,t){const s=this.controller.getEngine();console.log(`[ButtonDetect] Starting button ${e}`);const i=[240,2,3];return new Promise(r=>{const o=new Map,a=new Map;let c=0,l=!1,d=0,u=null;const f=v=>{if(l||["Control","Shift","Alt","Meta"].includes(v.key))return;const b=`${v.code}-${v.key}-${v.ctrlKey}-${v.shiftKey}-${v.altKey}-${v.metaKey}`;console.log(`[ButtonDetect] Keyboard event: ${b}`);const m=a.get(b);m?(m.count++,(!u||m.count>u.count)&&(u={signature:b,event:v,count:m.count})):(a.set(b,{event:v,count:1}),u||(u={signature:b,event:v,count:1}))};window.addEventListener("keydown",f),this.pendingGestureComplete=()=>{console.log(`[ButtonDetect] Button ${e} skipped`),l=!0,clearInterval(g),window.removeEventListener("keydown",f),r(null)};const g=setInterval(()=>{if(l)return;const v=s.getCapturedPacketsWithReportId();if(d++,d%20===0){Array.from(o.entries()).map(([w,C])=>`${w.substring(0,20)}...(${C.count})`);const m=Array.from(a.entries()).map(([w,C])=>`${w}(${C.count})`);console.log(`[ButtonDetect] Button ${e}: ${v.length} HID packets, ${o.size} HID patterns, ${a.size} key patterns`),m.length>0&&console.log(`  Key patterns: [${m.join(", ")}]`);const k=new Set(v.map(w=>w.reportId));console.log(`  Report IDs seen: [${[...k].join(", ")}]`)}const b=v.slice(c);c=v.length;for(const{packet:m,reportId:k}of b){const w=Array.from(m).map(C=>C.toString(16).padStart(2,"0")).join(" ");console.log(`[ButtonDetect] New packet: reportId=${k}, len=${m.length}, bytes=[${w}]`)}for(const{packet:m,reportId:k}of b){if(m.length<1)continue;const w=m[0],C=m.length>1?m[1]:0;let z=!1,_="traditional";if(k===3&&m.length>=2)C!==0&&(z=!0,_="keyboard");else if(k===4&&m.length===2&&w!==0&&C===0)z=!0,_="consumer";else if(k===5&&m.length>=2)m[m.length-1]!==0&&(z=!0,_="scroll");else if(i.includes(w)){if(C===0)continue;z=!0,_="traditional"}else m.length===2&&w!==0&&C===0?[160,161,192,193,194,195,196,197,128,129].includes(w)||(z=!0,_="consumer"):m.length===2&&w===0&&C!==0&&(z=!0,_="scroll");if(!z)continue;const E=`${k??"none"}-${Array.from(m).join("-")}`,ee=o.get(E);if(ee){if(ee.count++,ee.count>=t){if(console.log(`[ButtonDetect] Button ${e} DETECTED via HID (${_}, reportId=${k}): bytes=[${Array.from(m).join(",")}], count=${ee.count}`),l=!0,clearInterval(g),window.removeEventListener("keydown",f),_==="keyboard")r({buttonNumber:e,modifier:w,keycode:C,reportId:k,interfaceType:"keyboard"});else if(_==="consumer")r({buttonNumber:e,consumerCode:w,reportId:k,interfaceType:"keyboard"});else if(_==="scroll"){const te=m[m.length-1];r({buttonNumber:e,scrollDelta:te,reportId:k,interfaceType:"keyboard"})}else r({buttonNumber:e,scanCode:C,statusByte:w});return}}else o.set(E,{packet:new Uint8Array(m),count:1,reportId:k,detectionType:_})}if(u&&u.count>=t&&o.size===0&&d>40){console.log(`[ButtonDetect] Button ${e} DETECTED via keyboard (fallback): ${u.signature}, count=${u.count}`),l=!0,clearInterval(g),window.removeEventListener("keydown",f);const m=u.event;r({buttonNumber:e,key:m.key,code:m.code,ctrlKey:m.ctrlKey||void 0,shiftKey:m.shiftKey||void 0,altKey:m.altKey||void 0,metaKey:m.metaKey||void 0})}},50)})}handleSaveConfig(e){var t;if(this.pendingSaveConfig){if(e&&this.completeConfig){const s=new Blob([JSON.stringify(this.completeConfig,null,2)],{type:"application/json"}),i=URL.createObjectURL(s),r=document.createElement("a");r.href=i,r.download=`${((t=this.completeConfig.name)==null?void 0:t.toLowerCase().replace(/\s+/g,"_"))||"tablet"}_config.json`,r.click(),URL.revokeObjectURL(i),this.pendingSaveConfig({save:!0,filename:r.download})}else this.pendingSaveConfig({save:!1});this.pendingSaveConfig=null}}handleGestureComplete(){this.pendingGestureComplete&&(this.pendingGestureComplete(),this.pendingGestureComplete=null)}handleSkipButton(){this.handleGestureComplete()}async handleSimulate(){var i;if(!this.mockReader||this.isPlaying||!((i=this.stepInfo)!=null&&i.gesture))return;this.isPlaying=!0;const e=this.controller.getEngine();e.startCapture(),this.captureStatus.isCapturing=!0,this.capturedPackets=[],this.requestUpdate(),await this.mockReader.playGestureForStep(this.stepInfo.gesture,2e3),await new Promise(r=>setTimeout(r,200)),e.stopCapture(),this.isPlaying=!1;const t=e.getFilterStats();this.captureStatus={packetCount:t.captured,duplicatesFiltered:t.duplicates,idleFiltered:t.idle,isCapturing:!1};const s=e.getStepData(this.walkthroughStep);s&&(this.detectedBytes=s.detectedBytes),this.requestUpdate()}async handleStartWalkthrough(){console.log("[HID] handleStartWalkthrough called"),!this.isRealDevice||this.webReaders.length===0?(this.isMockMode=!0,this.controller.setReader(this.mockReader),this.controller.setDeviceInfo({vendorId:0,productId:0,productName:"Mock Tablet"})):(this.isMockMode=!1,this.controller.setReader(this.webReaders[0]),this.controller.setDeviceInfo(this.deviceMetadata)),this.controller.getEngine().start(),this.stepInfo=this.controller.getCurrentStepInfo(),this.walkthroughStep=this.controller.getCurrentStep(),this.showInfo(this.isMockMode?"Using mock data":`Connected to ${this.realDeviceName}`),this.requestUpdate()}handleReset(){this.controller.resetStep(),this.capturedPackets=[],this.detectedBytes=[],this.detectedButtons=[],this.currentButtonPrompt=null,this.pendingNavigation=null,this.requestUpdate()}render(){return p`
      <div class="page-header">
        <div class="header-info">
          <h1>BlankSlate Config Generator</h1>
        </div>
        <div class="header-controls">
          ${this._renderDeviceStatus()}
          ${this._renderMessages()}
        </div>
      </div>

      <div class="content">
        ${this._renderCurrentStep()}
        ${this.deviceDataStreams.size>0?this._renderDeviceStreams():""}
      </div>
    `}_renderMessages(){return p`
      ${this.messages.map(e=>p`
        <span class="message ${e.type}">${e.text}</span>
      `)}
    `}_renderDeviceStatus(){return this.isRealDevice?"":p`
      <sp-button
        size="s"
        variant="accent"
        data-spectrum-pattern="button-accent"
        ?disabled="${this.isConnecting}"
        @click="${this._connectRealDevice}">
        <sp-icon-link slot="icon"></sp-icon-link>
        ${this.isConnecting?"Connecting...":"Connect Real Tablet"}
      </sp-button>
    `}_renderCurrentStep(){return this.pendingDataSource?this._renderDataSourceSelection():this.walkthroughStep==="idle"||!this.stepInfo?this._renderIdleState():this.walkthroughStep==="complete"?this._renderCompletion():this.walkthroughStep==="step10-metadata"?this._renderMetadataStep():this.walkthroughStep==="step9-tablet-buttons"?this._renderButtonDetectionStep():this._renderGestureStep()}_renderIdleState(){return p`
      <div class="section walkthrough">
        <h2>${xe.header.emoji} ${xe.header.title}</h2>
        <p>This walkthrough will help you configure your graphics tablet.</p>
        <sp-button
          variant="accent"
          @click="${()=>this.handleStartWalkthrough()}">
          Start Walkthrough
        </sp-button>
      </div>
    `}_renderDataSourceSelection(){return p`
      <div class="section walkthrough">
        <h3>Select Data Source</h3>
        <div class="button-row">
          <sp-button
            variant="secondary"
            @click=${()=>this.handleDataSourceSelect("mock")}>
            <sp-icon-play slot="icon"></sp-icon-play>
            Use Mock Data
          </sp-button>
          <sp-button
            variant="accent"
            @click=${()=>this.handleDataSourceSelect("device")}
            ?disabled="${!this.isRealDevice}">
            <sp-icon-link slot="icon"></sp-icon-link>
            Use Real Device ${this.isRealDevice?"":"(connect first)"}
          </sp-button>
          <sp-button
            variant="negative"
            @click=${()=>this.handleDataSourceSelect("exit")}>
            Cancel
          </sp-button>
        </div>
      </div>
    `}_renderGestureStep(){const e=this.stepInfo,t=this.captureStatus.packetCount>0;return p`
      <div class="section walkthrough active">
        <div class="step-header">
          <h3>Step ${e.number}/10: ${e.title}</h3>
          <sp-action-button
            quiet
            data-spectrum-pattern="action-button"
            @click="${this.handleReset}"
            label="Reset"
            aria-label="Reset">
            <sp-icon-refresh slot="icon"></sp-icon-refresh>
          </sp-action-button>
          <hid-walkthrough-progress currentStep="${e.number-1}" totalSteps="10"></hid-walkthrough-progress>
        </div>

        <div class="step-description">
          <p>${e.description}</p>
          <p class="instructions">${e.instructions}</p>
        </div>

        ${this._renderCaptureStatus()}

        ${this._renderStepNavigation(t)}
      </div>
    `}_renderStepNavigation(e){return p`
      <div class="navigation-buttons">
        ${this.isMockMode?p`
          <sp-button
            variant="secondary"
            data-spectrum-pattern="button-secondary"
            ?disabled=${this.isPlaying}
            @click=${this.handleSimulate}>
            ${this.isPlaying?"Simulating...":xe.ui.buttons.simulate}
          </sp-button>
        `:""}
        <sp-button
          variant="accent"
          data-spectrum-pattern="button-accent"
          ?disabled=${!e||this.isPlaying}
          @click=${()=>this._handleStepNext()}>
          ${xe.ui.buttons.next} →
        </sp-button>
        <sp-button
          variant="secondary"
          data-spectrum-pattern="button-secondary"
          @click=${()=>this._handleStepRetry()}>
          Retry
        </sp-button>
        <sp-button
          variant="secondary"
          data-spectrum-pattern="button-secondary"
          ?disabled=${this.walkthroughStep==="step1-horizontal"}
          @click=${()=>this._handleStepPrevious()}>
          ← Back
        </sp-button>
        <sp-button
          variant="negative"
          data-spectrum-pattern="button-negative"
          @click=${()=>this._resetWalkthrough()}>
          Cancel
        </sp-button>
        ${this._renderDetectedBytes()}
      </div>
    `}_handleStepNext(){const e=this.controller.getEngine();e.stopCapture();const t=e.getStepData(this.walkthroughStep);t&&(this.detectedBytes=t.detectedBytes),e.nextStep(),this.stepInfo=this.controller.getCurrentStepInfo(),this.walkthroughStep=this.controller.getCurrentStep(),this.detectedBytes=[],this.capturedPackets=[],this.requestUpdate()}_handleStepRetry(){const e=this.controller.getEngine();e.resetCurrentStep(),this.capturedPackets=[],this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!0},e.startCapture(),this.detectedBytes=[],this.requestUpdate()}_handleStepPrevious(){const e=this.controller.getEngine();e.stopCapture(),e.previousStep(),this.stepInfo=this.controller.getCurrentStepInfo(),this.walkthroughStep=this.controller.getCurrentStep(),this.requestUpdate()}_renderButtonDetectionStep(){const e=this.stepInfo,t=this.captureStatus.packetCount>0||this.detectedButtons.length>0;return p`
      <div class="section walkthrough active">
        <div class="step-header">
          <h3>Step ${e.number}/10: ${e.title}</h3>
          <sp-action-button quiet data-spectrum-pattern="action-button" @click="${this.handleReset}" label="Reset" aria-label="Reset">
            <sp-icon-refresh slot="icon"></sp-icon-refresh>
          </sp-action-button>
          <hid-walkthrough-progress currentStep="${e.number-1}" totalSteps="10"></hid-walkthrough-progress>
        </div>

        <div class="step-description">
          <p>${e.description}</p>
          <p class="instructions">${e.instructions}</p>
        </div>

        ${this._renderCaptureStatus()}

        ${this.pendingButtonCount?p`
          <div class="button-count-prompt" data-spectrum-pattern="form">
            <sp-field-label for="buttonCountInput" data-spectrum-pattern="field-label">How many tablet buttons does your device have?</sp-field-label>
            <sp-textfield
              type="number"
              id="buttonCountInput"
              data-spectrum-pattern="textfield"
              min="0"
              max="20"
              value="0"
              @keydown=${s=>{if(s.key==="Enter"){const i=s.target;this.handleButtonCountSubmit(parseInt(i.value)||0)}}}>
            </sp-textfield>
            <sp-button
              variant="accent"
              data-spectrum-pattern="button-accent"
              @click=${()=>{var i;const s=(i=this.shadowRoot)==null?void 0:i.getElementById("buttonCountInput");this.handleButtonCountSubmit(parseInt(s==null?void 0:s.value)||0)}}>
              Continue
            </sp-button>
          </div>
        `:""}

        ${this.currentButtonPrompt!==null?p`
          <div class="button-prompt">
            <p>Press Button ${this.currentButtonPrompt} three times</p>
            <sp-button
              variant="secondary"
              data-spectrum-pattern="button-secondary"
              @click=${this.handleSkipButton}>
              Skip this button
            </sp-button>
          </div>
        `:""}

        ${this.detectedButtons.length>0?p`
          <div class="button-summary">
            <h4>Detected Buttons:</h4>
            ${this.detectedButtons.map(s=>p`
              <div class="detected-button">
                ${s.modifier!==void 0&&s.keycode!==void 0?p`
                  ✓ Button ${s.buttonNumber}: modifier=${s.modifier}, keycode=${s.keycode} (Report ID ${s.reportId??3})
                `:s.key?p`
                  ✓ Button ${s.buttonNumber}: ${s.ctrlKey?"Ctrl+":""}${s.shiftKey?"Shift+":""}${s.altKey?"Alt+":""}${s.metaKey?"Meta+":""}${s.key} (${s.code})
                `:s.consumerCode!==void 0?p`
                  ✓ Button ${s.buttonNumber}: consumerCode=${s.consumerCode} (Report ID ${s.reportId??4})
                `:s.scrollDelta!==void 0?p`
                  ✓ Button ${s.buttonNumber}: scrollDelta=${s.scrollDelta} (Report ID ${s.reportId??5})
                `:p`
                  ✓ Button ${s.buttonNumber}: scanCode=${s.scanCode}, status=${s.statusByte}
                `}
              </div>
            `)}
          </div>
        `:""}

        ${!this.pendingButtonCount&&this.currentButtonPrompt===null?this._renderStepNavigation(t):""}
      </div>
    `}_renderMetadataStep(){const e=this.stepInfo;return p`
      <div class="section walkthrough active">
        <div class="step-header">
          <h3>Step ${e.number}/10: ${e.title}</h3>
          <hid-walkthrough-progress currentStep="${e.number-1}" totalSteps="10"></hid-walkthrough-progress>
        </div>

        <div class="step-description">
          <p>${e.description}</p>
        </div>

        <device-metadata-form
          .suggestedButtonCount=${this.buttonCount}
          @metadata-submit=${this.handleMetadataSubmit}
          @metadata-cancel=${this.handleMetadataCancel}>
        </device-metadata-form>
      </div>
    `}_renderCompletion(){return p`
      <div class="section walkthrough complete">
        <div class="step-header">
          <h3>✅ Configuration Complete!</h3>
          <sp-action-button
            quiet
            data-spectrum-pattern="action-button"
            @click="${this._resetWalkthrough}"
            label="Start Over"
            aria-label="Start Over">
            <sp-icon-refresh slot="icon"></sp-icon-refresh>
          </sp-action-button>
        </div>

        <p>Your device configuration has been generated.</p>

        ${this.completeConfig?p`
          <div class="config-panel">
            <div class="config-panel-header" @click="${()=>this.isConfigPanelExpanded=!this.isConfigPanelExpanded}">
              <h4>Device Configuration</h4>
              <span class="collapse-icon">${this.isConfigPanelExpanded?"▼":"▶"}</span>
            </div>
            ${this.isConfigPanelExpanded?p`
              <hid-json-config .config=${this.completeConfig}></hid-json-config>
            `:""}
          </div>

          ${this.pendingSaveConfig?p`
            <div class="button-row">
              <sp-button
                variant="accent"
                data-spectrum-pattern="button-accent"
                @click=${()=>this.handleSaveConfig(!0)}>
                <sp-icon-save-floppy slot="icon"></sp-icon-save-floppy>
                Download Configuration
              </sp-button>
              <sp-button
                variant="secondary"
                data-spectrum-pattern="button-secondary"
                @click=${()=>this.handleSaveConfig(!1)}>
                Skip
              </sp-button>
            </div>
          `:""}
        `:""}
      </div>
    `}_renderCaptureStatus(){return p`
      <div class="capture-status ${this.captureStatus.isCapturing?"capturing":""}">
        <div class="packet-count">
          ${this.captureStatus.packetCount} packets captured
        </div>
        <div class="filter-stats">
          Filtered: ${this.captureStatus.duplicatesFiltered} duplicates, 
          ${this.captureStatus.idleFiltered} idle
        </div>
      </div>
    `}_renderDetectedBytes(){return this.detectedBytes.length===0?"":p`
      <span class="bytes-detected-badge">✓ ${this.detectedBytes.length} byte${this.detectedBytes.length!==1?"s":""} detected</span>
    `}_renderDeviceStreams(){var o;const e=Array.from(this.deviceDataStreams.entries()).map(([a,c])=>({index:a,lastPacket:c.lastPacket,packetCount:c.packetCount,lastUpdate:c.lastUpdate})),t=new Map;e.forEach(a=>{if(a.index===-1)t.set(-1,{usagePage:13,usage:2});else{const c=this.webReaders[a.index];if(c){const l=c.deviceInfo;t.set(a.index,{usagePage:l.usagePage,usage:l.usage,opened:c.isOpen})}}});const{bytesData:s,deviceInfo:i,isEmpty:r}=this._getBytesDisplayData();return p`
      <div class="section">
        <h3>Device Interfaces</h3>
        <hid-devices
          .streams=${e}
          .deviceDetails=${t}
          .bytes=${s}
          .bytesEmpty=${r}
          .bytesPlaceholderCount=${9}
          .bytesDeviceInfo=${i}
          .isConnected=${this.isRealDevice}
          .connectedDeviceName=${this.realDeviceName}
          .isDeviceOpened=${((o=this.webReaders[0])==null?void 0:o.isOpen)||!1}
          @disconnect=${this._disconnectRealDevice}>
        </hid-devices>
      </div>
    `}_getBytesDisplayData(){var a;let e=null;this.capturedPackets.length>0?e=this.capturedPackets[this.capturedPackets.length-1]:this.lastCapturedPackets.length>0?e=this.lastCapturedPackets[this.lastCapturedPackets.length-1]:this.latestDisplayPacket&&(e=this.latestDisplayPacket);const t=this.currentActiveDeviceIndex,s=t!==void 0?this.deviceDataStreams.get(t):void 0,i=t===-1,r=t!==void 0?{deviceNumber:t,packetCount:(s==null?void 0:s.packetCount)||0,digitizerUsagePage:i?13:(a=this.webReaders[t])==null?void 0:a.deviceInfo.usagePage,isMock:i}:void 0;return e?{bytesData:Array.from(e).map((c,l)=>({byteIndex:l,value:c,isIdentified:this.detectedBytes.some(d=>d.byteIndex===l),label:void 0})),deviceInfo:r,isEmpty:!1}:{bytesData:[],deviceInfo:r,isEmpty:!0}}_setupMockReader(){this.mockReader=Ae({productName:"Mock Graphics Tablet",vendorId:0,productId:0}),this.deviceDataStreams.set(-1,{lastPacket:"",packetCount:0,lastUpdate:Date.now()}),this.mockReader.startReading((e,t)=>{this._handleDeviceData(-1,e,t)})}_setupDeviceFinder(){this.deviceFinder=new it(e=>{this._handleDeviceConnected(e)},()=>{this._handleDeviceDisconnected()},{autoConnect:!0})}async _checkForRealDevice(){if(this.deviceFinder)try{await this.deviceFinder.checkForExistingDevices()}catch(e){console.error("[HIDDataReader] Error checking for devices:",e)}}async _connectRealDevice(){if(this.deviceFinder){this.isConnecting=!0;try{await this.deviceFinder.requestDevice([])}catch(e){console.error("[HIDDataReader] Error connecting device:",e),this.showError("Failed to connect to device. Please try again.")}finally{this.isConnecting=!1}}}async _handleDeviceConnected(e){this.realDeviceName=e.deviceInfo.name,this.isRealDevice=!0,this.isMockMode=!1,console.log(`[HIDDataReader] Received ${e.allDevices.length} devices from DeviceFinder`),e.allDevices.forEach((a,c)=>{const l=a.collections.map(d=>`usagePage=${d.usagePage}, usage=${d.usage}`).join("; ");console.log(`  Device ${c}: opened=${a.opened}, [${l}]`)}),this.webReaders=e.allDevices.map(a=>qt(a));const t=e.allDevices.flatMap(a=>a.collections).filter(a=>a.usagePage!==void 0&&a.usage!==void 0).map(a=>({usagePage:a.usagePage,usage:a.usage})),s=Array.from(new Map(t.map(a=>[`${a.usagePage}-${a.usage}`,a])).values());this.deviceMetadata={vendorId:e.primaryDevice.vendorId,productId:e.primaryDevice.productId,productName:e.primaryDevice.productName,collections:s,allInterfaces:e.allDevices.flatMap(a=>a.collections.map(c=>c.usagePage)).filter(a=>a!==void 0).filter((a,c,l)=>l.indexOf(a)===c)};const i=this.deviceDataStreams.get(-1);this.deviceDataStreams.clear(),i&&this.deviceDataStreams.set(-1,i),this.webReaders.forEach((a,c)=>{this.deviceDataStreams.set(c,{lastPacket:"",packetCount:0,lastUpdate:0})}),this.requestUpdate();for(let a=0;a<this.webReaders.length;a++){const c=this.webReaders[a];if(!c.isOpen)try{await c.open(),console.log(`[HIDDataReader] Opened device ${a}: usagePage=${c.deviceInfo.usagePage}, usage=${c.deviceInfo.usage}`)}catch(l){console.error(`[HIDDataReader] Error opening device ${a}:`,l)}}this.webReaders.forEach((a,c)=>{console.log(`[HIDDataReader] Starting reading on device ${c}: isOpen=${a.isOpen}, usagePage=${a.deviceInfo.usagePage}`),a.startReading((l,d)=>{this._handleDeviceData(c,l,d)})});const r=e.allDevices.findIndex(a=>a===e.primaryDevice),o=r>=0?this.webReaders[r]:this.webReaders[0];o&&(this.controller.setReader(o),this.controller.setDeviceInfo(this.deviceMetadata),this.requestUpdate())}_handleDeviceDisconnected(){this.isRealDevice=!1,this.realDeviceName="",this.webReaders.forEach(e=>e.stopReading()),this.webReaders=[],this.isMockMode=!0,this.latestDisplayPacket=null}async _disconnectRealDevice(){if(this.deviceFinder)try{await this.deviceFinder.disconnect(),this._handleDeviceDisconnected()}catch(e){console.error("[HIDDataReader] Error disconnecting:",e)}}_handleDeviceData(e,t,s){const i=Array.from(t).map(o=>o.toString(16).padStart(2,"0").toUpperCase()).join(" ");if(e>=0&&this.webReaders[e]){const o=this.webReaders[e];(o.deviceInfo.usagePage===1||o.deviceInfo.usagePage===65280)&&console.log(`[NonDigitizer] Device ${e} (usagePage=${o.deviceInfo.usagePage}), reportId=${s}, len=${t.length}, bytes=[${i}]`)}const r=this.deviceDataStreams.get(e);if(r&&(r.lastPacket=i,r.packetCount++,r.lastUpdate=Date.now(),this.deviceDataStreams=new Map(this.deviceDataStreams)),this.currentActiveDeviceIndex=e,e>=0&&this.webReaders[e]){const a=this.webReaders[e].deviceInfo.usagePage;a!==void 0&&!this.deviceMetadata.dataSourceUsagePage&&(this.deviceMetadata.dataSourceUsagePage=a,this.controller.setDeviceInfo(this.deviceMetadata))}this.controller.processPacket(t,s),this.latestDisplayPacket=new Uint8Array(t),this.captureStatus.isCapturing&&this.capturedPackets.push(new Uint8Array(t)),this.requestUpdate()}_resetWalkthrough(){this.walkthroughStep="idle",this.stepInfo=null,this.captureStatus={packetCount:0,duplicatesFiltered:0,idleFiltered:0,isCapturing:!1},this.detectedBytes=[],this.detectedButtons=[],this.currentButtonPrompt=null,this.buttonCount=0,this.messages=[],this.completeConfig=null,this.capturedPackets=[],this.lastCapturedPackets=[],this.latestDisplayPacket=null,this.pendingDataSource=null,this.pendingNavigation=null,this.pendingButtonCount=null,this.pendingMetadata=null,this.pendingSaveConfig=null,this.pendingGestureComplete=null,this.requestUpdate()}};R.styles=Lt;N([x()],R.prototype,"isPlaying",void 0);N([x()],R.prototype,"isMockMode",void 0);N([x()],R.prototype,"walkthroughStep",void 0);N([x()],R.prototype,"stepInfo",void 0);N([x()],R.prototype,"captureStatus",void 0);N([x()],R.prototype,"detectedBytes",void 0);N([x()],R.prototype,"messages",void 0);N([x()],R.prototype,"detectedButtons",void 0);N([x()],R.prototype,"currentButtonPrompt",void 0);N([x()],R.prototype,"buttonCount",void 0);N([x()],R.prototype,"isRealDevice",void 0);N([x()],R.prototype,"realDeviceName",void 0);N([x()],R.prototype,"isConnecting",void 0);N([x()],R.prototype,"completeConfig",void 0);N([x()],R.prototype,"isConfigPanelExpanded",void 0);N([x()],R.prototype,"deviceDataStreams",void 0);N([x()],R.prototype,"currentActiveDeviceIndex",void 0);R=N([j("hid-data-reader")],R);var gs=Object.defineProperty,fs=Object.getOwnPropertyDescriptor,Ce=(n,e,t,s)=>{for(var i=s>1?void 0:s?fs(e,t):e,r=n.length-1,o;r>=0;r--)(o=n[r])&&(i=(s?o(e,t,i):o(i))||i);return s&&i&&gs(e,t,i),i};let le=class extends Y{constructor(){super(),this.currentPage="dashboard",this.loadedConfig=null,this.themeColor="light";const n=localStorage.getItem("sketchatone-theme");n?this.themeColor=n:window.matchMedia("(prefers-color-scheme: dark)").matches&&(this.themeColor="dark"),this._updateDocumentBackground()}_updateDocumentBackground(){const n=this.themeColor==="dark"?"#1a1a1a":"#f5f7fa";document.documentElement.style.backgroundColor=n,document.body.style.backgroundColor=n,document.documentElement.classList.remove("light-theme","dark-theme"),document.documentElement.classList.add(`${this.themeColor}-theme`)}_handleGoToGenerator(){this.currentPage="walkthrough"}_handleBackToDashboard(){this.currentPage="dashboard"}_handleConfigLoadedFromDashboard(n){this.loadedConfig=n.detail.config}_toggleTheme(){this.themeColor=this.themeColor==="light"?"dark":"light",localStorage.setItem("sketchatone-theme",this.themeColor),this._updateDocumentBackground()}render(){return p`
      <sp-theme system="spectrum" color=${this.themeColor} scale="medium">
        <div class="app">
          ${this.currentPage==="walkthrough"?p`
            <div class="nav-bar">
              <sp-button data-spectrum-pattern="button-secondary" variant="secondary" @click=${this._handleBackToDashboard}>
                ← Back to Dashboard
              </sp-button>
            </div>
          `:""}

          <div class="page-content">
            ${this.currentPage==="walkthrough"?p`
              <hid-data-reader></hid-data-reader>
            `:""}

            ${this.currentPage==="dashboard"?p`
              <hid-dashboard
                mode="webhid"
                app-title="Sketchatone Web"
                .config=${this.loadedConfig}
                .themeColor=${this.themeColor}
                @config-loaded=${this._handleConfigLoadedFromDashboard}
                @go-to-generator=${this._handleGoToGenerator}
                @theme-toggle=${this._toggleTheme}>
              </hid-dashboard>
            `:""}
          </div>
        </div>
      </sp-theme>
    `}};le.styles=dt;Ce([x()],le.prototype,"currentPage",2);Ce([x()],le.prototype,"loadedConfig",2);Ce([x()],le.prototype,"themeColor",2);le=Ce([j("sketchatone-web-app")],le);
