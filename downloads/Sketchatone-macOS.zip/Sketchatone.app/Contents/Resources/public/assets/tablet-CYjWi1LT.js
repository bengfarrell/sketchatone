import{i as k,a as Xe,r as We,t as Ke,B as Re,b as S,I as T,s as H,c as n,o as x,d as K,n as l,P as Je,L as dt,e as L,f as Bt,g as nt,h as ut,F as Qe,j as Ge,k as Mt,l as to,m as eo,p as oo,A as z,q as ro,T as io,u as so,v as xe,w as ao,x as no,y as U,z as G,C as p,D as J,E as lo,G as co}from"./config-OjKexx4c.js";import{i as uo}from"./modal.css-BWEQnxJY.js";import{f as ho}from"./first-focusable-in-BzgrVKDE.js";const po=k`
  :host {
    display: block;
  }

  .app {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    background: var(--spectrum-gray-100);
  }

  .nav-bar {
    padding: 16px 24px;
    background: var(--spectrum-gray-50);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid var(--spectrum-gray-300);
    position: sticky;
    top: 0;
    z-index: 100;
  }

  .back-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: var(--spectrum-gray-50);
    border: 2px solid var(--spectrum-accent-color-900);
    border-radius: 8px;
    color: var(--spectrum-accent-color-900);
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .back-button:hover {
    background: var(--spectrum-accent-color-900);
    color: var(--spectrum-gray-50);
  }

  .back-arrow {
    font-size: 1.2rem;
    transition: transform 0.2s ease;
  }

  .back-button:hover .back-arrow {
    transform: translateX(-3px);
  }

  .page-content {
    flex: 1;
  }

  /* Walkthrough page styling */
  .page-content hid-data-reader {
    max-width: 1000px;
    margin: 0 auto;
    padding: 30px;
  }

  /* Dashboard page styling */
  .page-content hid-dashboard {
    max-width: 1400px;
    margin: 0 auto;
    padding: 30px;
  }
`,mo=k`
  :host {
    display: block;
    width: 100%;
    max-width: 100%;
    overflow-x: hidden;
  }

  .dashboard {
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 16px;
    background: var(--spectrum-gray-50);
    max-width: 100%;
    box-sizing: border-box;
  }

  @media (max-width: 640px) {
    .dashboard {
      padding: 8px;
      gap: 12px;
    }
  }

  /* Header */
  .dashboard-header {
    display: flex;
    flex-direction: row;
    gap: 16px;
    padding: 12px 16px;
    background: var(--spectrum-gray-100);
    border-radius: 8px;
    align-items: center;
  }

  @media (max-width: 640px) {
    .dashboard-header {
      flex-direction: column;
      align-items: stretch;
      gap: 12px;
      padding: 12px;
    }
  }

  .header-logo-container {
    display: flex;
    align-items: center;
    flex-shrink: 0;
  }

  @media (max-width: 640px) {
    .header-logo-container {
      justify-content: center;
    }
  }

  .header-logo {
    height: 130px;
  }

  @media (max-width: 640px) {
    .header-logo {
      height: 80px;
    }
  }

  /* Theme-adaptive logo colors */
  .logo-bg {
    fill: var(--spectrum-gray-200);
  }

  .logo-title {
    fill: var(--spectrum-gray-800);
  }

  .logo-subtitle {
    fill: var(--spectrum-gray-600);
  }

  .logo-line {
    stroke: var(--spectrum-gray-500);
  }

  .header-content {
    display: flex;
    flex-direction: column;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .header-row {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }

  @media (max-width: 640px) {
    .header-row {
      justify-content: center;
    }
  }

  .header-controls {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
  }

  @media (max-width: 640px) {
    .header-controls {
      justify-content: center;
    }
  }

  /* Connection UI */
  .connection-row {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 16px;
    flex-wrap: wrap;
  }

  @media (max-width: 640px) {
    .connection-row {
      justify-content: center;
      gap: 8px;
    }
  }

  .connection-group {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .save-button-group {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  /* Config Header */
  .config-header {
    display: flex;
    align-items: center;
    margin-top: 12px;
  }

  .config-filename {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .config-separator {
    border-top: 1px solid var(--spectrum-gray-200);
    margin-top: 8px;
  }

  /* Config Management Row */
  .config-row {
    display: flex;
    align-items: center;
    gap: 16px;
    padding-top: 8px;
  }

  .config-management-group {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  .config-management-group sp-picker {
    min-width: 150px;
  }

  .status-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 16px;
    font-size: 0.75rem;
    font-weight: 500;
  }

  .status-badge.connected {
    background: var(--spectrum-green-100);
    color: var(--spectrum-green-900);
  }

  .status-badge.disconnected {
    background: var(--spectrum-gray-200);
    color: var(--spectrum-gray-700);
  }

  .status-badge.disconnected .status-dot {
    background: var(--spectrum-gray-500);
  }

  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--spectrum-green-600);
  }

  /* Version Info */
  .version-info {
    display: flex;
    gap: 16px;
    justify-content: flex-end;
    font-size: 0.7rem;
    color: var(--spectrum-gray-500);
    margin-top: 4px;
  }

  .version-label {
    font-family: monospace;
  }

  /* Disconnected Message */
  .disconnected-message {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 48px 24px;
    color: var(--spectrum-gray-600);
    font-size: 1rem;
  }

  .disconnected-message p {
    margin: 0;
  }

  /* Panels Grid - main layout for all panels */
  .panels-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
    margin-top: 16px;
    max-width: 100%;
    overflow: hidden;
  }

  @media (max-width: 1024px) {
    .panels-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  @media (max-width: 640px) {
    .panels-grid {
      grid-template-columns: 1fr;
      gap: 12px;
      margin-top: 12px;
    }
  }

  /* MIDI Panel Content */
  .midi-panel-content {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .midi-status-row {
    display: flex;
    justify-content: flex-start;
  }

  /* Strum Main Visualizer */
  .strum-main-visualizer {
    margin-bottom: 16px;
  }

  .strum-visualizer-wrapper {
    display: flex;
    justify-content: center;
    padding: 16px;
  }

  .strum-visualizer-wrapper tablet-visualizer {
    max-width: 600px;
    width: 100%;
  }

  /* Piano styling */
  piano-keys {
    width: 100%;
    max-width: 100%;
  }

  /* Settings Grid - matches visualizers-grid sizing */
  .settings-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
  }

  @media (max-width: 1024px) {
    .settings-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  @media (max-width: 640px) {
    .settings-grid {
      grid-template-columns: 1fr;
    }
  }

  /* Settings Form */
  .settings-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 8px 0;
  }

  .setting-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .setting-row label {
    font-size: 0.875rem;
    color: var(--spectrum-gray-700);
    flex-shrink: 0;
  }

  .setting-row sp-number-field {
    width: 100px;
  }

  .setting-row sp-picker {
    flex: 1;
    min-width: 150px;
  }

  .setting-row sp-checkbox {
    margin: 0;
  }

  /* Chord Progression */
  .chord-progression {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .preset-row {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .preset-row sp-picker {
    flex: 1;
  }

  .chord-buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
  }

  .chord-button {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 12px 8px;
    background: var(--spectrum-gray-100);
    border: 2px solid var(--spectrum-gray-300);
    border-radius: 8px;
    transition: all 0.15s ease;
  }

  .chord-button.active {
    background: var(--spectrum-green-100);
    border-color: var(--spectrum-green-600);
  }

  .chord-button .button-number {
    font-size: 0.7rem;
    color: var(--spectrum-gray-600);
    margin-bottom: 4px;
  }

  .chord-button .chord-name {
    font-size: 1rem;
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .chord-button.active .chord-name {
    color: var(--spectrum-green-800);
  }

  /* Placeholder */
  .placeholder-visualizer {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 48px;
    background: var(--spectrum-gray-75);
    border-radius: 8px;
    border: 2px dashed var(--spectrum-gray-300);
  }

  .placeholder-visualizer p {
    margin: 0;
    font-size: 1.25rem;
    color: var(--spectrum-gray-700);
  }

  .placeholder-hint {
    font-size: 0.875rem !important;
    color: var(--spectrum-gray-500) !important;
    margin-top: 8px !important;
  }

  /* Visualizers Grid */
  .visualizers-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
  }

  .visualizer-card {
    background: var(--spectrum-gray-100);
    border-radius: 12px;
    border: 1px solid var(--spectrum-gray-200);
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  }

  .visualizer-card:hover {
    border-color: var(--spectrum-gray-300);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }

  .visualizer-card.compact {
    padding: 12px;
  }

  .visualizer-wrapper {
    aspect-ratio: 1;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .events-panel {
    grid-row: span 1;
  }

  .bytes-panel {
    grid-column: span 3;
  }

  /* Data Values */
  .data-values {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .data-values.compact {
    gap: 4px;
  }

  .data-item {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    background: var(--spectrum-gray-100);
    border-radius: 4px;
    font-size: 0.75rem;
  }

  .data-label {
    color: var(--spectrum-gray-600);
    font-weight: 500;
  }

  .data-value {
    color: var(--spectrum-gray-900);
    font-family: monospace;
  }

  .data-value.zero {
    color: var(--spectrum-gray-400);
  }

  /* Responsive */
  @media (max-width: 1024px) {
    .visualizers-grid {
      grid-template-columns: repeat(2, 1fr);
    }

    .bytes-panel {
      grid-column: span 2;
    }
  }

  @media (max-width: 640px) {
    .visualizers-grid {
      grid-template-columns: 1fr;
    }

    .bytes-panel {
      grid-column: span 1;
    }

  }

  /* MIDI Input Panel (inside visualizers-grid) */
  .visualizer-card.midi-panel {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 12px;
  }

  .midi-panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .midi-panel-title {
    font-size: 1rem;
    font-weight: 600;
    color: var(--spectrum-gray-900);
  }

  .status-badge.small {
    font-size: 0.8rem;
    padding: 3px 8px;
  }

  .midi-notes {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: var(--spectrum-blue-100);
    border-radius: 6px;
    font-size: 0.875rem;
  }

  .midi-notes.compact {
    padding: 6px 10px;
    font-size: 0.875rem;
  }

  .midi-notes-label {
    color: var(--spectrum-blue-900);
    font-weight: 500;
  }

  .midi-notes-value {
    color: var(--spectrum-blue-900);
    font-family: monospace;
    font-weight: 600;
  }

  .midi-source {
    font-size: 0.8rem;
    color: var(--spectrum-gray-700);
    font-style: italic;
  }

  .midi-ports-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .midi-ports-label {
    font-size: 0.875rem;
    color: var(--spectrum-gray-800);
  }

  .midi-ports {
    list-style: none;
    margin: 6px 0 0 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
    max-height: 150px;
    overflow-y: auto;
  }

  .midi-port-item {
    padding: 6px 10px;
    background: var(--spectrum-gray-200);
    border-radius: 4px;
    font-family: monospace;
    font-size: 0.875rem;
    color: var(--spectrum-gray-900);
    cursor: pointer;
    transition: background 0.15s ease;
  }

  .midi-port-item:hover {
    background: var(--spectrum-gray-300);
  }

  .midi-port-item.selected {
    background: var(--spectrum-blue-200);
    border-left: 3px solid var(--spectrum-blue-700);
    color: var(--spectrum-blue-900);
    font-weight: 600;
  }

  .midi-port-item.active {
    background: var(--spectrum-green-200);
    border-left: 3px solid var(--spectrum-green-700);
    color: var(--spectrum-green-900);
  }

  .midi-port-item.selected.active {
    background: var(--spectrum-green-200);
    border-left: 3px solid var(--spectrum-blue-700);
  }

`;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const lt=(o,t)=>{var r;const e=o._$AN;if(e===void 0)return!1;for(const i of e)(r=i._$AO)==null||r.call(i,t,!1),lt(i,t);return!0},Ct=o=>{let t,e;do{if((t=o._$AM)===void 0)break;e=t._$AN,e.delete(o),o=t}while((e==null?void 0:e.size)===0)},_e=o=>{for(let t;t=o._$AM;o=t){let e=t._$AN;if(e===void 0)t._$AN=e=new Set;else if(e.has(o))break;e.add(o),vo(t)}};function go(o){this._$AN!==void 0?(Ct(this),this._$AM=o,_e(this)):this._$AM=o}function bo(o,t=!1,e=0){const r=this._$AH,i=this._$AN;if(i!==void 0&&i.size!==0)if(t)if(Array.isArray(r))for(let s=e;s<r.length;s++)lt(r[s],!1),Ct(r[s]);else r!=null&&(lt(r,!1),Ct(r));else lt(this,o)}const vo=o=>{o.type==Ke.CHILD&&(o._$AP??(o._$AP=bo),o._$AQ??(o._$AQ=go))};class fo extends Xe{constructor(){super(...arguments),this._$AN=void 0}_$AT(t,e,r){super._$AT(t,e,r),_e(this),this.isConnected=t._$AU}_$AO(t,e=!0){var r,i;t!==this.isConnected&&(this.isConnected=t,t?(r=this.reconnected)==null||r.call(this):(i=this.disconnected)==null||i.call(this)),e&&(lt(this,t),Ct(this))}setValue(t){if(We(this._$Ct))this._$Ct._$AI(t,this);else{const e=[...this._$Ct._$AH];e[this._$Ci]=t,this._$Ct._$AI(e,this,0)}}disconnected(){}reconnected(){}}class yo extends Re{}const wo=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross200"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 10 10"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m6.29 5 2.922-2.922a.911.911 0 0 0-1.29-1.29L5 3.712 2.078.789a.911.911 0 0 0-1.29 1.289L3.712 5 .79 7.922a.911.911 0 1 0 1.289 1.29L5 6.288 7.923 9.21a.911.911 0 0 0 1.289-1.289z"
    />
  </svg>`,xo=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross200"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 10 10"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m6.29 5 2.922-2.922a.911.911 0 0 0-1.29-1.29L5 3.712 2.078.789a.911.911 0 0 0-1.29 1.289L3.712 5 .79 7.922a.911.911 0 1 0 1.289 1.29L5 6.288 7.923 9.21a.911.911 0 0 0 1.289-1.289z"
    />
  </svg>`;class ko extends T{render(){return H(n),this.spectrumVersion===2?wo({hidden:!this.label,title:this.label}):xo({hidden:!this.label,title:this.label})}}x("sp-icon-cross200",ko);const $o=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross300"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.344 6 3.395-3.396a.95.95 0 0 0-1.344-1.342L6 4.657 2.604 1.262a.95.95 0 0 0-1.342 1.342L4.657 6 1.262 9.396a.95.95 0 0 0 1.343 1.343L6 7.344l3.395 3.395a.95.95 0 0 0 1.344-1.344z"
    />
  </svg>`,Co=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross300"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.344 6 3.395-3.396a.95.95 0 0 0-1.344-1.342L6 4.657 2.604 1.262a.95.95 0 0 0-1.342 1.342L4.657 6 1.262 9.396a.95.95 0 0 0 1.343 1.343L6 7.344l3.395 3.395a.95.95 0 0 0 1.344-1.344z"
    />
  </svg>`;class zo extends T{render(){return H(n),this.spectrumVersion===2?$o({hidden:!this.label,title:this.label}):Co({hidden:!this.label,title:this.label})}}x("sp-icon-cross300",zo);const So=k`
    .spectrum-UIIcon-Cross75{--spectrum-icon-size:var(--spectrum-cross-icon-size-75)}.spectrum-UIIcon-Cross100{--spectrum-icon-size:var(--spectrum-cross-icon-size-100)}.spectrum-UIIcon-Cross200{--spectrum-icon-size:var(--spectrum-cross-icon-size-200)}.spectrum-UIIcon-Cross300{--spectrum-icon-size:var(--spectrum-cross-icon-size-300)}.spectrum-UIIcon-Cross400{--spectrum-icon-size:var(--spectrum-cross-icon-size-400)}.spectrum-UIIcon-Cross500{--spectrum-icon-size:var(--spectrum-cross-icon-size-500)}.spectrum-UIIcon-Cross600{--spectrum-icon-size:var(--spectrum-cross-icon-size-600)}
`,Po=k`
    :host{cursor:pointer;-webkit-user-select:none;user-select:none;box-sizing:border-box;font-family:var(--mod-button-font-family,var(--mod-sans-font-family-stack,var(--spectrum-sans-font-family-stack)));-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;line-height:var(--mod-button-line-height,var(--mod-line-height-100,var(--spectrum-line-height-100)));text-transform:none;vertical-align:top;-webkit-appearance:button;transition:background var(--mod-button-animation-duration,var(--mod-animation-duration-100,var(--spectrum-animation-duration-100)))ease-out,border-color var(--mod-button-animation-duration,var(--mod-animation-duration-100,var(--spectrum-animation-duration-100)))ease-out,color var(--mod-button-animation-duration,var(--mod-animation-duration-100,var(--spectrum-animation-duration-100)))ease-out,box-shadow var(--mod-button-animation-duration,var(--mod-animation-duration-100,var(--spectrum-animation-duration-100)))ease-out;border-style:solid;margin:0;-webkit-text-decoration:none;text-decoration:none;overflow:visible}:host(:focus){outline:none}:host([disabled]),:host([disabled]){cursor:default}:host a{-webkit-user-select:none;user-select:none;-webkit-appearance:none}@media (forced-colors:active){:host{--highcontrast-closebutton-icon-color-disabled:GrayText;--highcontrast-closebutton-icon-color-down:Highlight;--highcontrast-closebutton-icon-color-hover:Highlight;--highcontrast-closebutton-icon-color-focus:Highlight;--highcontrast-closebutton-background-color-default:ButtonFace;--highcontrast-closebutton-focus-indicator-color:ButtonText}:host(:focus-visible):after{forced-color-adjust:none;margin:var(--mod-closebutton-focus-indicator-gap,var(--spectrum-closebutton-focus-indicator-gap));transition:opacity var(--mod-closebutton-animation-duration,var(--spectrum-closebutton-animation-duration))ease-out,margin var(--mod-closebutton-animation-duraction,var(--spectrum-closebutton-animation-duration))ease-out}:host([static-color=black]){--highcontrast-closebutton-static-background-color-default:ButtonFace;--highcontrast-closebutton-icon-color-default:Highlight;--highcontrast-closebutton-icon-color-disabled:GrayText}:host([static-color=white]){--highcontrast-closebutton-static-background-color-default:ButtonFace;--highcontrast-closebutton-icon-color-default:Highlight;--highcontrast-closebutton-icon-color-disabled:Highlight}}:host{--spectrum-closebutton-icon-color-default:var(--spectrum-neutral-content-color-default);--spectrum-closebutton-icon-color-hover:var(--spectrum-neutral-content-color-hover);--spectrum-closebutton-icon-color-down:var(--spectrum-neutral-content-color-down);--spectrum-closebutton-icon-color-focus:var(--spectrum-neutral-content-color-key-focus);--spectrum-closebutton-icon-color-disabled:var(--spectrum-disabled-content-color);--spectrum-closebutton-focus-indicator-thickness:var(--spectrum-focus-indicator-thickness);--spectrum-closebutton-focus-indicator-gap:var(--spectrum-focus-indicator-gap);--spectrum-closebutton-focus-indicator-color:var(--spectrum-focus-indicator-color);--spectrum-closebutton-animation-duration:var(--spectrum-animation-duration-100);block-size:var(--mod-closebutton-height,var(--spectrum-closebutton-size));inline-size:var(--mod-closebutton-width,var(--mod-closebutton-height,var(--spectrum-closebutton-size)));color:inherit;border-radius:var(--mod-closebutton-border-radius,var(--spectrum-closebutton-border-radius));transition:border-color var(--mod-closebutton-animation-duration,var(--spectrum-closebutton-animation-duration))ease-in-out;margin-inline:var(--mod-closebutton-margin-inline);justify-content:center;align-items:center;align-self:var(--mod-closebutton-align-self);border-width:0;border-color:#0000;flex-direction:row;margin-block-start:var(--mod-closebutton-margin-top);padding:0;display:inline-flex;position:relative}:host([size=s]){--spectrum-closebutton-size:var(--spectrum-component-height-75);--spectrum-closebutton-border-radius:var(--spectrum-component-height-75)}:host,:host{--spectrum-closebutton-size:var(--spectrum-component-height-100);--spectrum-closebutton-border-radius:var(--spectrum-component-height-100)}:host([size=l]){--spectrum-closebutton-size:var(--spectrum-component-height-200);--spectrum-closebutton-border-radius:var(--spectrum-component-height-200)}:host([size=xl]){--spectrum-closebutton-size:var(--spectrum-component-height-300);--spectrum-closebutton-border-radius:var(--spectrum-component-height-300)}:host([static-color=white]){--spectrum-closebutton-static-background-color-default:transparent;--spectrum-closebutton-icon-color-default:var(--spectrum-white);--spectrum-closebutton-icon-color-disabled:var(--spectrum-disabled-static-white-content-color);--spectrum-closebutton-focus-indicator-color:var(--spectrum-static-white-focus-indicator-color)}:host([static-color=black]){--spectrum-closebutton-static-background-color-default:transparent;--spectrum-closebutton-icon-color-default:var(--spectrum-black);--spectrum-closebutton-icon-color-disabled:var(--spectrum-disabled-static-black-content-color);--spectrum-closebutton-focus-indicator-color:var(--spectrum-static-black-focus-indicator-color)}:host:after{pointer-events:none;content:"";margin:calc(var(--mod-closebutton-focus-indicator-gap,var(--spectrum-closebutton-focus-indicator-gap))*-1);border-radius:calc(var(--mod-closebutton-size,var(--spectrum-closebutton-size)) + var(--mod-closebutton-focus-indicator-gap,var(--spectrum-closebutton-focus-indicator-gap)));transition:box-shadow var(--mod-closebutton-animation-duration,var(--spectrum-closebutton-animation-duration))ease-in-out;position:absolute;inset-block:0;inset-inline:0}:host(:focus-visible){box-shadow:none;outline:none}:host(:focus-visible):after{box-shadow:0 0 0 var(--mod-closebutton-focus-indicator-thickness,var(--spectrum-closebutton-focus-indicator-thickness))var(--highcontrast-closebutton-focus-indicator-color,var(--mod-closebutton-focus-indicator-color,var(--spectrum-closebutton-focus-indicator-color)))}:host(:not([disabled])){background-color:var(--highcontrast-closebutton-background-color-default,var(--mod-closebutton-background-color-default,var(--spectrum-closebutton-background-color-default)))}:host(:not([disabled]):is(:active,[active])){background-color:var(--mod-closebutton-background-color-down,var(--spectrum-closebutton-background-color-down))}:host(:not([disabled]):is(:active,[active])) .icon{color:var(--highcontrast-closebutton-icon-color-down,var(--mod-closebutton-icon-color-down,var(--spectrum-closebutton-icon-color-down)))}:host([focused]:not([disabled])),:host(:not([disabled]):focus-visible){background-color:var(--mod-closebutton-background-color-focus,var(--spectrum-closebutton-background-color-focus))}:host([focused]:not([disabled])) .icon,:host(:not([disabled]):focus-visible) .icon{color:var(--highcontrast-closebutton-icon-color-focus,var(--mod-closebutton-icon-color-focus,var(--spectrum-closebutton-icon-color-focus)))}:host(:not([disabled])) .icon{color:var(--mod-closebutton-icon-color-default,var(--spectrum-closebutton-icon-color-default))}:host([focused]:not([disabled])) .icon,:host(:not([disabled]):focus) .icon{color:var(--highcontrast-closebutton-icon-color-focus,var(--mod-closebutton-icon-color-focus,var(--spectrum-closebutton-icon-color-focus)))}:host([disabled]){background-color:var(--mod-closebutton-background-color-default,var(--spectrum-closebutton-background-color-default))}:host([disabled]) .icon{color:var(--highcontrast-closebutton-icon-color-disabled,var(--mod-closebutton-icon-color-disabled,var(--spectrum-closebutton-icon-color-disabled)))}:host([static-color=black]:not([disabled])),:host([static-color=white]:not([disabled])){background-color:var(--highcontrast-closebutton-static-background-color-default,var(--mod-closebutton-static-background-color-default,var(--spectrum-closebutton-static-background-color-default)))}@media (hover:hover){:host(:not([disabled]):hover){background-color:var(--mod-closebutton-background-color-hover,var(--spectrum-closebutton-background-color-hover))}:host(:not([disabled]):hover) .icon{color:var(--highcontrast-closebutton-icon-color-hover,var(--mod-closebutton-icon-color-hover,var(--spectrum-closebutton-icon-color-hover)))}:host([static-color=black]:not([disabled]):hover),:host([static-color=white]:not([disabled]):hover){background-color:var(--mod-closebutton-static-background-color-hover,var(--spectrum-closebutton-static-background-color-hover))}:host([static-color=black]:not([disabled]):hover) .icon,:host([static-color=white]:not([disabled]):hover) .icon{color:var(--highcontrast-closebutton-icon-color-default,var(--mod-closebutton-icon-color-default,var(--spectrum-closebutton-icon-color-default)))}}:host([static-color=black]:not([disabled]):is(:active,[active])),:host([static-color=white]:not([disabled]):is(:active,[active])){background-color:var(--mod-closebutton-static-background-color-down,var(--spectrum-closebutton-static-background-color-down))}:host([static-color=black]:not([disabled]):is(:active,[active])) .icon,:host([static-color=white]:not([disabled]):is(:active,[active])) .icon{color:var(--highcontrast-closebutton-icon-color-default,var(--mod-closebutton-icon-color-default,var(--spectrum-closebutton-icon-color-default)))}:host([static-color=black][focused]:not([disabled])),:host([static-color=black]:not([disabled]):focus-visible),:host([static-color=white][focused]:not([disabled])),:host([static-color=white]:not([disabled]):focus-visible){background-color:var(--mod-closebutton-static-background-color-focus,var(--spectrum-closebutton-static-background-color-focus))}:host([static-color=black][focused]:not([disabled])) .icon,:host([static-color=black][focused]:not([disabled])) .icon,:host([static-color=black]:not([disabled]):focus) .icon,:host([static-color=black]:not([disabled]):focus-visible) .icon,:host([static-color=white][focused]:not([disabled])) .icon,:host([static-color=white][focused]:not([disabled])) .icon,:host([static-color=white]:not([disabled]):focus) .icon,:host([static-color=white]:not([disabled]):focus-visible) .icon{color:var(--highcontrast-closebutton-icon-color-default,var(--mod-closebutton-icon-color-default,var(--spectrum-closebutton-icon-color-default)))}:host([static-color=black]:not([disabled])) .icon,:host([static-color=white]:not([disabled])) .icon{color:var(--mod-closebutton-icon-color-default,var(--spectrum-closebutton-icon-color-default))}:host([static-color=black][disabled]) .icon,:host([static-color=white][disabled]) .icon{color:var(--mod-closebutton-icon-color-disabled,var(--spectrum-closebutton-icon-color-disabled))}.icon{margin:0}:host{--spectrum-closebutton-background-color-default:var(--system-close-button-background-color-default);--spectrum-closebutton-background-color-hover:var(--system-close-button-background-color-hover);--spectrum-closebutton-background-color-down:var(--system-close-button-background-color-down);--spectrum-closebutton-background-color-focus:var(--system-close-button-background-color-focus)}:host([static-color=white]){--spectrum-closebutton-static-background-color-hover:var(--system-close-button-static-white-static-background-color-hover);--spectrum-closebutton-static-background-color-down:var(--system-close-button-static-white-static-background-color-down);--spectrum-closebutton-static-background-color-focus:var(--system-close-button-static-white-static-background-color-focus)}:host([static-color=black]){--spectrum-closebutton-static-background-color-hover:var(--system-close-button-static-black-static-background-color-hover);--spectrum-closebutton-static-background-color-down:var(--system-close-button-static-black-static-background-color-down);--spectrum-closebutton-static-background-color-focus:var(--system-close-button-static-black-static-background-color-focus)}.visually-hidden{clip:rect(0,0,0,0);clip-path:inset(50%);white-space:nowrap;border:0;width:1px;height:1px;margin:0 -1px -1px 0;padding:0;position:absolute;overflow:hidden}
`,Do=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross400"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.398 6 3.932-3.932A.989.989 0 0 0 9.932.67L6 4.602 2.068.67A.989.989 0 0 0 .67 2.068L4.602 6 .67 9.932a.989.989 0 1 0 1.398 1.398L6 7.398l3.932 3.932a.989.989 0 0 0 1.398-1.398z"
    />
  </svg>`,Io=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross400"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.398 6 3.932-3.932A.989.989 0 0 0 9.932.67L6 4.602 2.068.67A.989.989 0 0 0 .67 2.068L4.602 6 .67 9.932a.989.989 0 1 0 1.398 1.398L6 7.398l3.932 3.932a.989.989 0 0 0 1.398-1.398z"
    />
  </svg>`;class Bo extends T{render(){return H(n),this.spectrumVersion===2?Do({hidden:!this.label,title:this.label}):Io({hidden:!this.label,title:this.label})}}x("sp-icon-cross400",Bo);const Ao=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross500"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 14 14"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m8.457 7 4.54-4.54a1.03 1.03 0 0 0-1.458-1.456L7 5.543l-4.54-4.54a1.03 1.03 0 0 0-1.457 1.458L5.543 7l-4.54 4.54a1.03 1.03 0 1 0 1.457 1.456L7 8.457l4.54 4.54a1.03 1.03 0 0 0 1.456-1.458z"
    />
  </svg>`,Eo=({width:o=24,height:t=24,hidden:e=!1,title:r="Cross500"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 14 14"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m8.457 7 4.54-4.54a1.03 1.03 0 0 0-1.458-1.456L7 5.543l-4.54-4.54a1.03 1.03 0 0 0-1.457 1.458L5.543 7l-4.54 4.54a1.03 1.03 0 1 0 1.457 1.456L7 8.457l4.54 4.54a1.03 1.03 0 0 0 1.456-1.458z"
    />
  </svg>`;class To extends T{render(){return H(n),this.spectrumVersion===2?Ao({hidden:!this.label,title:this.label}):Eo({hidden:!this.label,title:this.label})}}x("sp-icon-cross500",To);var Mo=Object.defineProperty,ke=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Mo(t,e,i),i};const No={s:()=>n`
        <sp-icon-cross200
            slot="icon"
            class="icon spectrum-UIIcon-Cross200"
        ></sp-icon-cross200>
    `,m:()=>n`
        <sp-icon-cross300
            slot="icon"
            class="icon spectrum-UIIcon-Cross300"
        ></sp-icon-cross300>
    `,l:()=>n`
        <sp-icon-cross400
            slot="icon"
            class="icon spectrum-UIIcon-Cross400"
        ></sp-icon-cross400>
    `,xl:()=>n`
        <sp-icon-cross500
            slot="icon"
            class="icon spectrum-UIIcon-Cross500"
        ></sp-icon-cross500>
    `};class Gt extends K(yo,{noDefaultSize:!0}){constructor(){super(...arguments),this.variant=""}static get styles(){return[...super.styles,Po,So]}get buttonContent(){return[No[this.size](),n`
                <span id="label" class="visually-hidden">
                    <slot @slotchange=${this.manageTextObservedSlot}></slot>
                </span>
            `]}}ke([l({reflect:!0})],Gt.prototype,"variant"),ke([l({reflect:!0,attribute:"static-color"})],Gt.prototype,"staticColor");x("sp-picker",Je);const Fo=k`
    :host{--spectrum-menu-divider-thickness:var(--spectrum-divider-thickness-medium);inline-size:auto;margin-block:var(--mod-menu-section-divider-margin-block,max(0px,(var(--spectrum-menu-item-section-divider-height) - var(--spectrum-menu-divider-thickness))/2));margin-inline:var(--mod-menu-item-label-inline-edge-to-content,var(--spectrum-menu-item-label-inline-edge-to-content));overflow:visible}.spectrum-Menu-back:focus-visible{box-shadow:var(--spectrum-menu-item-focus-indicator-shadow)var(--spectrum-menu-item-focus-indicator-border-width)0 0 0 var(--spectrum-menu-item-focus-indicator-color-default);outline:var(--spectrum-menu-item-focus-indicator-width)var(--spectrum-menu-item-focus-indicator-outline-style)var(--spectrum-menu-item-focus-indicator-color-default);outline-offset:var(--spectrum-menu-item-focus-indicator-offset);border-radius:var(--spectrum-menu-item-corner-radius)}.spectrum-Menu-back{padding-inline:var(--mod-menu-back-padding-inline-start,0)var(--mod-menu-back-padding-inline-end,var(--spectrum-menu-item-label-inline-edge-to-content));padding-block:var(--mod-menu-back-padding-block-start,0)var(--mod-menu-back-padding-block-end,0);flex-flow:wrap;align-items:center;display:flex}.spectrum-Menu-backButton{cursor:pointer;background:0 0;border:0;margin:0;padding:0;display:inline-flex}.spectrum-Menu-backButton:focus-visible{outline:var(--spectrum-focus-indicator-thickness)solid var(--spectrum-focus-indicator-color);outline-offset:calc((var(--spectrum-focus-indicator-thickness) + 1px)*-1)}.spectrum-Menu-backHeading{color:var(--highcontrast-menu-item-color-default,var(--mod-menu-back-heading-color,var(--spectrum-menu-section-header-color)));font-size:var(--mod-menu-section-header-font-size,var(--spectrum-menu-section-header-font-size));font-weight:var(--mod-menu-section-header-font-weight,var(--spectrum-menu-section-header-font-weight));line-height:var(--mod-menu-section-header-line-height,var(--spectrum-menu-section-header-line-height));display:block}:host{flex-shrink:0;display:block}
`,Oe=k`
    @media (forced-colors:active){:host{--highcontrast-divider-background-color:CanvasText}}:host{--spectrum-divider-thickness:var(--spectrum-divider-thickness-medium)}:host([size=s]){--spectrum-divider-thickness:var(--spectrum-divider-thickness-small)}:host([size=l]){--spectrum-divider-thickness:var(--spectrum-divider-thickness-large);--spectrum-divider-background-color:var(--spectrum-gray-800)}:host([static-color=white]){--mod-divider-background-color:var(--mod-divider-background-color-medium-static-white,var(--spectrum-divider-background-color-static-white))}:host([static-color=white][size=s]){--mod-divider-background-color:var(--mod-divider-background-color-small-static-white,var(--spectrum-divider-background-color-static-white))}:host([static-color=white][size=l]){--mod-divider-background-color:var(--mod-divider-background-color-large-static-white,var(--spectrum-transparent-white-800))}:host([static-color=black]){--mod-divider-background-color:var(--mod-divider-background-color-medium-static-black,var(--spectrum-divider-background-color-static-black))}:host([static-color=black][size=s]){--mod-divider-background-color:var(--mod-divider-background-color-small-static-black,var(--spectrum-divider-background-color-static-black))}:host([static-color=black][size=l]){--mod-divider-background-color:var(--mod-divider-background-color-large-static-black,var(--spectrum-transparent-black-800))}:host{block-size:var(--mod-divider-thickness,var(--spectrum-divider-thickness));border:none;border-width:var(--mod-divider-thickness,var(--spectrum-divider-thickness));border-radius:var(--mod-divider-thickness,var(--spectrum-divider-thickness));background-color:var(--highcontrast-divider-background-color,var(--mod-divider-background-color,var(--spectrum-divider-background-color)));inline-size:100%;overflow:visible}:host([vertical]){inline-size:var(--mod-divider-thickness,var(--spectrum-divider-thickness));block-size:100%;block-size:var(--mod-divider-vertical-height,100%);margin-block:var(--mod-divider-vertical-margin);align-self:var(--mod-divider-vertical-align)}:host{--spectrum-divider-background-color:var(--system-divider-background-color);--spectrum-divider-background-color-static-white:var(--system-divider-background-color-static-white);--spectrum-divider-background-color-static-black:var(--system-divider-background-color-static-black)}:host{display:block}hr{border:none;margin:0}
`;class Ro extends K(dt,{validSizes:["s","m","l"]}){static get styles(){return[Oe,Fo]}firstUpdated(t){super.firstUpdated(t),this.setAttribute("role","separator")}}x("sp-menu-divider",Ro);const Go=({width:o=24,height:t=24,hidden:e=!1,title:r="Link Off"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    viewBox="0 0 36 36"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="m11.136 9.523-1.496 1.44-5.328-5.24 1.496-1.439 5.328 5.239zM31.801 30.277l-1.496 1.439-5.299-5.334 1.495-1.439 5.3 5.334zM11.057 1.8h2.314v4.629h-2.314zM1.8 11.057h4.629v2.314H1.8zM29.571 22.629H34.2v2.314h-4.629zM22.629 29.571h2.314V34.2h-2.314zM18.053 23.708l-5.84 5.878a4.101 4.101 0 0 1-5.8-5.8l5.858-5.858-2.171-2.174-5.861 5.858A7.176 7.176 0 0 0 14.388 31.76l5.842-5.874ZM17.917 12.258l5.84-5.878a4.101 4.101 0 1 1 5.8 5.8l-5.858 5.858 2.171 2.174 5.861-5.858A7.176 7.176 0 1 0 21.582 4.206L15.74 10.08Z"
    />
  </svg>`,_o=({width:o=24,height:t=24,hidden:e=!1,title:r="Unlink"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    viewBox="0 0 20 20"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="m13.5,17.77148c-.32031,0-.61621-.20605-.71582-.52734l-.82129-2.64258c-.12305-.39551.09766-.81641.49316-.93848.40039-.125.81641.09863.93848.49316l.82129,2.64258c.12305.39551-.09766.81641-.49316.93848-.07422.02344-.14941.03418-.22266.03418Z"
      fill="currentColor"
    />
    <path
      d="m17,14.27148c-.07422,0-.14941-.01074-.22363-.03418l-2.65723-.8291c-.39551-.12305-.61523-.54395-.49219-.93945.12207-.39551.54395-.62012.93945-.49219l2.65723.8291c.39551.12305.61523.54395.49219.93945-.09961.32031-.39648.52637-.71582.52637Z"
      fill="currentColor"
    />
    <path
      d="m7.31641,6.40527c-.32031,0-.61621-.20605-.7168-.52832l-.81641-2.63379c-.12207-.39551.09863-.81543.49512-.93848.39453-.12207.81445.09863.93848.49512l.81641,2.63379c.12207.39551-.09863.81543-.49512.93848-.07324.02246-.14844.0332-.22168.0332Z"
      fill="currentColor"
    />
    <path
      d="m5.63965,8.09082c-.07324,0-.14844-.01074-.22266-.03418l-2.63965-.81934c-.39551-.12207-.61621-.54297-.49316-.93848.12305-.39453.54004-.61523.93848-.49316l2.63965.81934c.39551.12207.61621.54297.49316.93848-.09961.32129-.39551.52734-.71582.52734Z"
      fill="currentColor"
    />
    <path
      d="m5.31348,18.76953c-1.04102,0-2.08105-.39648-2.87305-1.18848-1.58496-1.58398-1.58496-4.16309,0-5.74707l1.92676-1.92676c.29297-.29297.76758-.29297,1.06055,0s.29297.76758,0,1.06055l-1.92676,1.92676c-1,1-1,2.62598,0,3.62598,1.00098,1.00098,2.62695.99707,3.62598,0l1.95215-1.95312c.29199-.29199.7666-.29395,1.06055,0,.29297.29199.29297.76758,0,1.06055l-1.95215,1.95312c-.79199.79199-1.83301,1.1875-2.87402,1.18848Z"
      fill="currentColor"
    />
    <path
      d="m15.10059,10.35645c-.19238,0-.38379-.07324-.53027-.21973-.29297-.29297-.29297-.76758,0-1.06055l1.92773-1.92773c1-1,1-2.62695.00098-3.62598-.96875-.96875-2.65723-.96875-3.62598,0l-1.95215,1.95215c-.29297.29297-.76758.29297-1.06055,0s-.29297-.76758,0-1.06055l1.95215-1.95215c.76758-.76758,1.78809-1.19141,2.87402-1.19141,1.08496,0,2.10547.42383,2.87305,1.19141,1.58398,1.58398,1.58398,4.16211,0,5.74609l-1.92871,1.92871c-.14648.14648-.33789.21973-.53027.21973Z"
      fill="currentColor"
    />
  </svg>`;class Oo extends T{render(){return Bt(n),this.spectrumVersion===1?Go({hidden:!this.label,title:this.label}):_o({hidden:!this.label,title:this.label})}}x("sp-icon-link-off",Oo);const Lo=({width:o=24,height:t=24,hidden:e=!1,title:r="Edit"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    viewBox="0 0 20 20"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="m17.78076,1.75684c-1.27197-1.04102-3.22705-.89844-4.4502.32324L3.07764,12.33398c-.32031.31934-.55859.7168-.68896,1.15039l-1.38428,4.58398c-.08008.26465-.00781.55176.1875.74707.14258.14258.33447.21973.53027.21973.07227,0,.14551-.01074.2168-.03223l4.58252-1.38379c.43359-.12988.83154-.36816,1.15088-.68848,0,0,10.16846-10.16797,10.35547-10.35547.64795-.64746.99316-1.54492.94775-2.45996-.0459-.91504-.48145-1.77539-1.19482-2.3584ZM2.84473,17.16309l.97998-3.24609c.02716-.09033.06714-.17578.11377-.25732l2.40869,2.40918c-.08154.04639-.16718.08643-.25781.11377l-3.24463.98047Zm14.12158-11.64746c-.15472.15552-7.09985,7.1001-9.52545,9.52588l-2.47461-2.4751L14.39111,3.14062c.38623-.38672.896-.58594,1.38965-.58594.38086,0,.75244.11914,1.05029.3623.3916.32129.62109.77246.646,1.27246.0249.49316-.16113.97656-.51074,1.32617Z"
      fill="currentColor"
    />
  </svg>`,Vo=({width:o=24,height:t=24,hidden:e=!1,title:r="Edit"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${t}"
    viewBox="0 0 36 36"
    width="${o}"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="M33.567 8.2 27.8 2.432a1.215 1.215 0 0 0-.866-.353H26.9a1.371 1.371 0 0 0-.927.406L5.084 23.372a.99.99 0 0 0-.251.422L2.055 33.1c-.114.377.459.851.783.851a.251.251 0 0 0 .062-.007c.276-.063 7.866-2.344 9.311-2.778a.972.972 0 0 0 .414-.249l20.888-20.889a1.372 1.372 0 0 0 .4-.883 1.221 1.221 0 0 0-.346-.945ZM11.4 29.316c-2.161.649-4.862 1.465-6.729 2.022l2.009-6.73Z"
    />
  </svg>`;class jo extends T{render(){return Bt(n),this.spectrumVersion===2?Lo({hidden:!this.label,title:this.label}):Vo({hidden:!this.label,title:this.label})}}x("sp-icon-edit",jo);var Ho=Object.defineProperty,vt=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Ho(t,e,i),i};function Uo(o){class t extends o{constructor(){super(...arguments),this.checked=!1,this.readonly=!1}handleChange(){if(this.readonly){this.inputElement.checked=this.checked;return}this.checked=this.inputElement.checked;const r=new CustomEvent("change",{bubbles:!0,cancelable:!0,composed:!0});this.dispatchEvent(r)||(this.checked=!this.inputElement.checked,this.inputElement.checked=this.checked)}render(){return n`
                <input
                    id="input"
                    name=${nt(this.name||void 0)}
                    type="checkbox"
                    .checked=${this.checked}
                    ?disabled=${this.readonly}
                    @change=${this.handleChange}
                />
            `}}return vt([l({type:Boolean,reflect:!0})],t.prototype,"checked"),vt([l({type:String,reflect:!0})],t.prototype,"name"),vt([l({type:Boolean,reflect:!0})],t.prototype,"readonly"),vt([ut("#input")],t.prototype,"inputElement"),t}class qo extends Uo(Qe){get focusElement(){return this.inputElement}}const $e=k`
    :host{--spectrum-switch-label-color-default:var(--spectrum-neutral-content-color-default);--spectrum-switch-label-color-hover:var(--spectrum-neutral-content-color-hover);--spectrum-switch-label-color-down:var(--spectrum-neutral-content-color-down);--spectrum-switch-label-color-focus:var(--spectrum-neutral-content-color-key-focus);--spectrum-switch-label-color-disabled:var(--spectrum-disabled-content-color);--spectrum-switch-background-color-selected-default:var(--spectrum-neutral-background-color-selected-default);--spectrum-switch-background-color-selected-hover:var(--spectrum-neutral-background-color-selected-hover);--spectrum-switch-background-color-selected-down:var(--spectrum-neutral-background-color-selected-down);--spectrum-switch-background-color-selected-focus:var(--spectrum-neutral-background-color-selected-key-focus);--spectrum-switch-background-color-selected-disabled:var(--spectrum-disabled-content-color);--spectrum-switch-focus-indicator-thickness:var(--mod-focus-indicator-thickness,var(--spectrum-focus-indicator-thickness));--spectrum-switch-focus-indicator-color:var(--spectrum-focus-indicator-color);--spectrum-switch-handle-border-color-disabled:var(--spectrum-disabled-content-color)}:host([disabled]){--spectrum-switch-label-color-default:var(--spectrum-disabled-content-color)}:host([emphasized]){--spectrum-switch-background-color-selected-default:var(--spectrum-accent-color-900);--spectrum-switch-background-color-selected-hover:var(--spectrum-accent-color-1000);--spectrum-switch-background-color-selected-down:var(--spectrum-accent-color-1100);--spectrum-switch-background-color-selected-focus:var(--spectrum-accent-color-1000);--spectrum-switch-handle-border-color-selected-default:var(--spectrum-accent-color-900);--spectrum-switch-handle-border-color-selected-hover:var(--spectrum-accent-color-1000);--spectrum-switch-handle-border-color-selected-down:var(--spectrum-accent-color-1100);--spectrum-switch-handle-border-color-selected-focus:var(--spectrum-accent-color-1000)}:host,:host{--spectrum-switch-min-height:var(--spectrum-component-height-100);--spectrum-switch-control-width:var(--spectrum-switch-control-width-medium);--spectrum-switch-control-height:var(--spectrum-switch-control-height-medium);--spectrum-switch-control-label-spacing:var(--spectrum-text-to-control-100);--spectrum-switch-spacing-top-to-control:var(--spectrum-switch-top-to-control-medium);--spectrum-switch-spacing-top-to-label:var(--spectrum-component-top-to-text-100);--spectrum-switch-font-size:var(--spectrum-font-size-100)}:host([size=s]){--spectrum-switch-min-height:var(--spectrum-component-height-75);--spectrum-switch-control-width:var(--spectrum-switch-control-width-small);--spectrum-switch-control-height:var(--spectrum-switch-control-height-small);--spectrum-switch-control-label-spacing:var(--spectrum-text-to-control-75);--spectrum-switch-spacing-top-to-control:var(--spectrum-switch-top-to-control-small);--spectrum-switch-spacing-top-to-label:var(--spectrum-component-top-to-text-75);--spectrum-switch-font-size:var(--spectrum-font-size-75)}:host([size=l]){--spectrum-switch-min-height:var(--spectrum-component-height-200);--spectrum-switch-control-width:var(--spectrum-switch-control-width-large);--spectrum-switch-control-height:var(--spectrum-switch-control-height-large);--spectrum-switch-control-label-spacing:var(--spectrum-text-to-control-200);--spectrum-switch-spacing-top-to-control:var(--spectrum-switch-top-to-control-large);--spectrum-switch-spacing-top-to-label:var(--spectrum-component-top-to-text-200);--spectrum-switch-font-size:var(--spectrum-font-size-200)}:host([size=xl]){--spectrum-switch-min-height:var(--spectrum-component-height-300);--spectrum-switch-control-width:var(--spectrum-switch-control-width-extra-large);--spectrum-switch-control-height:var(--spectrum-switch-control-height-extra-large);--spectrum-switch-control-label-spacing:var(--spectrum-text-to-control-300);--spectrum-switch-spacing-top-to-control:var(--spectrum-switch-top-to-control-extra-large);--spectrum-switch-spacing-top-to-label:var(--spectrum-component-top-to-text-300);--spectrum-switch-font-size:var(--spectrum-font-size-300)}:host{min-block-size:var(--mod-switch-height,var(--spectrum-switch-min-height));vertical-align:top;align-items:flex-start;max-inline-size:100%;display:inline-flex;position:relative}#input{box-sizing:border-box;opacity:0;z-index:1;cursor:pointer;block-size:100%;inline-size:100%;margin:0;padding:0;position:absolute;inset-block-start:0;inset-inline-start:0}:host([checked]) #input+#switch:before{transform:translateX(calc(var(--mod-switch-control-width,var(--spectrum-switch-control-width)) - 100%))}:host([checked]) #input+#switch:dir(rtl):before,:host([dir=rtl][checked]) #input+#switch:before{transform:translateX(calc((var(--mod-switch-control-width,var(--spectrum-switch-control-width)) - 100%)*-1))}:host([disabled]) #input,:host([disabled]) #input{cursor:default}#input:focus-visible+#switch:after{margin:calc(var(--mod-focus-indicator-gap,var(--spectrum-focus-indicator-gap))*-1)}#label{color:var(--highcontrast-switch-label-color-default,var(--mod-switch-label-color-default,var(--spectrum-switch-label-color-default)));margin-inline:var(--mod-switch-control-label-spacing,var(--spectrum-switch-control-label-spacing));font-size:var(--mod-switch-font-size,var(--spectrum-switch-font-size));line-height:var(--mod-line-height-100,var(--spectrum-line-height-100));transition:color var(--mod-animation-duration-200,var(--spectrum-animation-duration-200))ease-in-out;margin-block-start:var(--mod-switch-spacing-top-to-label,var(--spectrum-switch-spacing-top-to-label));margin-block-end:0}#switch{box-sizing:border-box;inline-size:var(--mod-switch-control-width,var(--spectrum-switch-control-width));margin-block:calc(var(--mod-switch-height,var(--spectrum-switch-min-height)) - var(--mod-switch-control-height,var(--spectrum-switch-control-height)) - var(--mod-switch-spacing-top-to-control,var(--spectrum-switch-spacing-top-to-control)));vertical-align:middle;transition:background var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out,border var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out;block-size:var(--mod-switch-control-height,var(--spectrum-switch-control-height));border-radius:calc(var(--mod-switch-control-height,var(--spectrum-switch-control-height))/2);flex-grow:0;flex-shrink:0;margin-inline:0;display:inline-block;position:relative;inset-inline:0}#switch:before{box-sizing:border-box;transition:background var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out,border var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out,transform var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out,box-shadow var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-in-out;inline-size:var(--mod-switch-control-height,var(--spectrum-switch-control-height));block-size:var(--mod-switch-control-height,var(--spectrum-switch-control-height));border-width:var(--mod-border-width-200,var(--spectrum-border-width-200));border-radius:calc(var(--mod-switch-control-height,var(--spectrum-switch-control-height))/2);border-style:solid}#switch:after,#switch:before{content:"";display:block;position:absolute;inset-block-start:0;inset-inline-start:0}#switch:after{border-radius:calc(var(--mod-switch-control-height,var(--spectrum-switch-control-height))/2 + var(--mod-focus-indicator-gap,var(--spectrum-focus-indicator-gap))*2);transition:opacity var(--mod-animation-duration-100,var(--spectrum-animation-duration-100))ease-out,margin var(--spectrum-animation-duration-100,var(--spectrum-animation-duration-100))ease-out;margin:0;inset-block-end:0;inset-inline-end:0}#switch{background-color:var(--highcontrast-switch-background-color,var(--mod-switch-background-color,var(--spectrum-switch-background-color)))}#switch:before{background-color:var(--highcontrast-switch-handle-background-color,var(--mod-switch-handle-background-color,var(--spectrum-switch-handle-background-color)));border-color:var(--highcontrast-switch-handle-border-color-default,var(--mod-switch-handle-border-color-default,var(--spectrum-switch-handle-border-color-default)))}:host(:active) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-down,var(--mod-switch-handle-border-color-down,var(--spectrum-switch-handle-border-color-down)))}:host(:active) #input~#label{color:var(--highcontrast-switch-label-color-down,var(--mod-switch-label-color-down,var(--spectrum-switch-label-color-down)))}#input:focus-visible+#switch:after{box-shadow:0 0 0 var(--mod-switch-focus-indicator-thickness,var(--spectrum-switch-focus-indicator-thickness))var(--highcontrast-switch-focus-indicator-color,var(--mod-switch-focus-indicator-color,var(--spectrum-switch-focus-indicator-color)))}#input:focus-visible+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-focus,var(--mod-switch-handle-border-color-focus,var(--spectrum-switch-handle-border-color-focus)))}:host([checked]) #input:focus-visible+#switch{background-color:var(--highcontrast-switch-background-color-selected-focus,var(--mod-switch-background-color-selected-focus,var(--spectrum-switch-background-color-selected-focus)))}:host([checked]) #input:focus-visible+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selected-focus,var(--mod-switch-handle-border-color-selected-focus,var(--spectrum-switch-handle-border-color-selected-focus)))}#input:focus-visible~#label{color:var(--highcontrast-switch-label-color-focus,var(--mod-switch-label-color-focus,var(--spectrum-switch-label-color-focus)))}@media (hover:hover){:host(:hover) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-hover,var(--mod-switch-handle-border-color-hover,var(--spectrum-switch-handle-border-color-hover)));box-shadow:none}:host(:hover) #input~#label{color:var(--highcontrast-switch-label-color-hover,var(--mod-switch-label-color-hover,var(--spectrum-switch-label-color-hover)))}:host([checked]:hover) #input:enabled+#switch{background-color:var(--highcontrast-switch-background-color-selected-hover,var(--mod-switch-background-color-selected-hover,var(--spectrum-switch-background-color-selected-hover)))}:host([checked]:hover) #input:enabled+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selected-hover,var(--mod-switch-handle-border-color-selected-hover,var(--spectrum-switch-handle-border-color-selected-hover)))}:host([disabled]:hover) #input+#switch,:host([disabled]:hover) #input+#switch{background-color:var(--mod-switch-background-color-disabled,var(--spectrum-switch-background-color-disabled))}:host([disabled]:hover) #input+#switch:before,:host([disabled]:hover) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-disabled,var(--mod-switch-handle-border-color-disabled,var(--spectrum-switch-handle-border-color-disabled)))}:host([disabled]:hover) #input~#label,:host([disabled]:hover) #input~#label{color:var(--highcontrast-switch-label-color-disabled,var(--mod-switch-label-color-disabled,var(--spectrum-switch-label-color-disabled)))}:host([disabled][checked]:hover) #input+#switch,:host([disabled][checked]:hover) #input+#switch{background-color:var(--highcontrast-switch-background-color-selected-disabled,var(--mod-switch-background-color-selected-disabled,var(--spectrum-switch-background-color-selected-disabled)))}:host([disabled][checked]:hover) #input+#switch:before,:host([disabled][checked]:hover) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-disabled,var(--mod-switch-handle-border-color-disabled,var(--spectrum-switch-handle-border-color-disabled)))}:host([disabled][checked]:hover) #input~#label,:host([disabled][checked]:hover) #input~#label{color:var(--highcontrast-switch-label-color-disabled,var(--mod-switch-label-color-disabled,var(--spectrum-switch-label-color-disabled)))}:host(:hover) #input:focus-visible+#switch:after{box-shadow:0 0 0 var(--mod-switch-focus-indicator-thickness,var(--spectrum-switch-focus-indicator-thickness))var(--highcontrast-switch-focus-indicator-color,var(--mod-switch-focus-indicator-color,var(--spectrum-switch-focus-indicator-color)))}:host(:hover) #input:focus-visible+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-focus,var(--mod-switch-handle-border-color-focus,var(--spectrum-switch-handle-border-color-focus)))}:host([checked]:hover) #input:focus-visible+#switch{background-color:var(--highcontrast-switch-background-color-selected-focus,var(--mod-switch-background-color-selected-focus,var(--spectrum-switch-background-color-selected-focus)))}:host([checked]:hover) #input:focus-visible+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selected-focus,var(--mod-switch-handle-border-color-selected-focus,var(--spectrum-switch-handle-border-color-selected-focus)))}:host(:hover) #input:focus-visible~#label{color:var(--highcontrast-switch-label-color-focus,var(--mod-switch-label-color-focus,var(--spectrum-switch-label-color-focus)))}}:host([checked]) #input+#switch{background-color:var(--highcontrast-switch-background-color-selected-default,var(--mod-switch-background-color-selected-default,var(--spectrum-switch-background-color-selected-default)))}:host([checked]) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selected-default,var(--mod-switch-handle-border-color-selected-default,var(--spectrum-switch-handle-border-color-selected-default)))}:host([disabled]) #input+#switch,:host([disabled]) #input+#switch{background-color:var(--mod-switch-background-color-disabled,var(--spectrum-switch-background-color-disabled))}:host([disabled]) #input+#switch:before,:host([disabled]) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-disabled,var(--mod-switch-handle-border-color-disabled,var(--spectrum-switch-handle-border-color-disabled)))}:host([disabled][checked]) #input+#switch,:host([disabled][checked]) #input+#switch{background-color:var(--highcontrast-switch-background-color-selected-disabled,var(--mod-switch-background-color-selected-disabled,var(--spectrum-switch-background-color-selected-disabled)))}:host([disabled][checked]) #input+#switch:before,:host([disabled][checked]) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-disabled,var(--mod-switch-handle-border-color-disabled,var(--spectrum-switch-handle-border-color-disabled)))}:host([disabled]) #input~#label,:host([disabled]) #input~#label{color:var(--highcontrast-switch-label-color-disabled,var(--mod-switch-label-color-disabled,var(--spectrum-switch-label-color-disabled)))}@media (forced-colors:active){:host{--highcontrast-switch-label-color-default:ButtonText;--highcontrast-switch-label-color-hover:ButtonText;--highcontrast-switch-label-color-down:ButtonText;--highcontrast-switch-label-color-focus:ButtonText;--highcontrast-switch-label-color-disabled:GrayText;--highcontrast-switch-handle-background-color:ButtonFace;--highcontrast-switch-handle-border-color-default:ButtonText;--highcontrast-switch-handle-border-color-hover:Highlight;--highcontrast-switch-handle-border-color-down:Highlight;--highcontrast-switch-handle-border-color-focus:Highlight;--highcontrast-switch-handle-border-color-disabled:Highlight;--highcontrast-switch-handle-border-color-selected-default:Highlight;--highcontrast-switch-handle-border-color-selected-hover:Highlight;--highcontrast-switch-handle-border-color-selected-down:Highlight;--highcontrast-switch-handle-border-color-selected-focus:Highlight;--highcontrast-switch-background-color:ButtonFace;--highcontrast-switch-background-color-selected-default:Highlight;--highcontrast-switch-background-color-selected-hover:Highlight;--highcontrast-switch-background-color-selected-down:Highlight;--highcontrast-switch-background-color-selected-focus:Highlight;--highcontrast-switch-background-color-selected-disabled:Highlight;--highcontrast-switch-focus-indicator-color:ButtonText;forced-color-adjust:none}#input:not(:checked)+#switch{box-shadow:inset 0 0 0 1px buttontext}@media (hover:hover){:host(:hover) #input:not(:checked)+#switch{box-shadow:inset 0 0 0 1px highlight}:host([disabled][checked]:hover) #input+#switch,:host([disabled][checked]:hover) #input+#switch{background-color:graytext;box-shadow:inset 0 0 0 1px graytext}:host([disabled][checked]:hover) #input+#switch:before,:host([disabled][checked]:hover) #input+#switch:before{background-color:buttonface;border-color:graytext}}:host([disabled]) #input:not(:checked)+#switch,:host([disabled]) #input:not(:checked)+#switch{background-color:buttonface;box-shadow:inset 0 0 0 1px graytext}:host([disabled]) #input:not(:checked)+#switch:before,:host([disabled]) #input:not(:checked)+#switch:before{background-color:buttonface;border-color:graytext}:host([disabled][checked]) #input+#switch,:host([disabled][checked]) #input+#switch{background-color:graytext;box-shadow:inset 0 0 0 1px graytext}:host([disabled][checked]) #input+#switch:before,:host([disabled][checked]) #input+#switch:before{background-color:buttonface;border-color:graytext}:host([disabled]) #input~#label,:host([disabled]) #input~#label{color:graytext}}:host{--spectrum-switch-handle-border-color-default:var(--system-switch-handle-border-color-default);--spectrum-switch-handle-border-color-hover:var(--system-switch-handle-border-color-hover);--spectrum-switch-handle-border-color-down:var(--system-switch-handle-border-color-down);--spectrum-switch-handle-border-color-focus:var(--system-switch-handle-border-color-focus);--spectrum-switch-handle-border-color-selected-default:var(--system-switch-handle-border-color-selected-default);--spectrum-switch-handle-border-color-selected-hover:var(--system-switch-handle-border-color-selected-hover);--spectrum-switch-handle-border-color-selected-down:var(--system-switch-handle-border-color-selected-down);--spectrum-switch-handle-border-color-selected-focus:var(--system-switch-handle-border-color-selected-focus);--spectrum-switch-background-color:var(--system-switch-background-color);--spectrum-switch-background-color-disabled:var(--system-switch-background-color-disabled);--spectrum-switch-handle-background-color:var(--system-switch-handle-background-color)}:host([disabled]){pointer-events:none}:host(:hover:active) #input+#switch:before,:host([emphasized]:hover:active) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-down,var(--mod-switch-handle-border-color-down,var(--spectrum-switch-handle-border-color-down)))}:host(:active[checked]) #input:enabled+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selelcted-down,var(--mod-switch-handle-border-color-selected-down,var(--spectrum-switch-handle-border-color-selected-down)))}:host(:active[checked]) #input:enabled+#switch{background-color:var(--highcontrast-switch-background-color-selected-down,var(--mod-switch-background-color-selected-down,var(--spectrum-switch-background-color-selected-down)))}:host([readonly]) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-default,var(--mod-switch-handle-border-color-default,var(--spectrum-switch-handle-border-color-default)))!important}:host([readonly][checked]) #input+#switch:before{border-color:var(--highcontrast-switch-handle-border-color-selected-default,var(--mod-switch-handle-border-color-selected-default,var(--spectrum-switch-handle-border-color-selected-default)))!important}
`,Zo=k`
    #switch:before{transition:background var(--spectrum-animation-duration-100,.13s)ease-in-out,border var(--spectrum-animation-duration-100,.13s)ease-in-out,box-shadow var(--spectrum-animation-duration-100,.13s)ease-in-out}
`;var Yo=Object.defineProperty,Xo=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Yo(t,e,i),i};class Le extends K(qo){constructor(){super(...arguments),this.emphasized=!1}static get styles(){return window.hasOwnProperty("ShadyDOM")?[$e,Zo]:[$e]}render(){return n`
            ${super.render()}
            <span id="switch"></span>
            <label id="label" for="input"><slot></slot></label>
        `}firstUpdated(t){super.firstUpdated(t),this.inputElement.setAttribute("role","switch")}updated(t){t.has("checked")&&this.inputElement.setAttribute("aria-checked",this.checked?"true":"false")}}Xo([l({type:Boolean,reflect:!0})],Le.prototype,"emphasized");x("sp-switch",Le);const Wo=k`
    :host{--spectrum-buttongroup-spacing:var(--mod-buttongroup-spacing,var(--mod-buttongroup-spacing-horizontal,var(--spectrum-spacing-300)));--spectrum-buttongroup-display:flex;--spectrum-buttongroup-flex-direction:row;--spectrum-buttongroup-justify-content:var(--mod-buttongroup-justify-content,normal)}:host([size=s]){--spectrum-buttongroup-spacing:var(--mod-buttongroup-spacing,var(--mod-buttongroup-spacing-horizontal,var(--spectrum-spacing-200)))}:host([vertical]){--mod-buttongroup-spacing:var(--mod-buttongroup-spacing-vertical);--spectrum-buttongroup-display:inline-flex;--spectrum-buttongroup-flex-direction:column}:host{display:var(--spectrum-buttongroup-display);flex-direction:var(--spectrum-buttongroup-flex-direction);gap:var(--spectrum-buttongroup-spacing);justify-content:var(--spectrum-buttongroup-justify-content);flex-wrap:wrap}::slotted(*){flex-shrink:0}:host([vertical]) ::slotted(sp-action-button){--spectrum-actionbutton-label-flex-grow:1}:host([dir=ltr][vertical]) ::slotted(sp-action-button){--spectrum-actionbutton-label-text-align:left}:host([dir=rtl][vertical]) ::slotted(sp-action-button){--spectrum-actionbutton-label-text-align:right}
`;var Ko=Object.defineProperty,Ce=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Ko(t,e,i),i};class _t extends K(dt,{noDefaultSize:!0}){constructor(){super(...arguments),this.vertical=!1}static get styles(){return[Wo]}updated(t){super.updated(t),t.has("size")&&this.manageChildrenSize(this.slotElement)}handleSlotchange({target:t}){this.manageChildrenSize(t)}manageChildrenSize(t){t.assignedElements().forEach(e=>{e.size=this.size})}render(){return n`
            <slot @slotchange=${this.handleSlotchange}></slot>
        `}}Ce([l({type:Boolean,reflect:!0})],_t.prototype,"vertical"),Ce([ut("slot")],_t.prototype,"slotElement");x("sp-button-group",_t);x("sp-close-button",Gt);const Jo=["s","m","l"],Qo=["white","black"];var tr=Object.defineProperty,Ve=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&tr(t,e,i),i};let At=class extends K(dt,{validSizes:Jo,noDefaultSize:!0}){constructor(){super(...arguments),this.vertical=!1}firstUpdated(t){super.firstUpdated(t),this.setAttribute("role","separator")}updated(t){super.updated(t),t.has("vertical")&&(this.vertical?this.setAttribute("aria-orientation","vertical"):this.removeAttribute("aria-orientation"))}};At.STATIC_COLORS=Qo;Ve([l({type:Boolean,reflect:!0})],At.prototype,"vertical");Ve([l({reflect:!0,attribute:"static-color"})],At.prototype,"staticColor");class je extends At{render(){return n``}}je.styles=[Oe];x("sp-divider",je);let er=class{constructor(t,{target:e,config:r,callback:i,skipInitial:s}){this.t=new Set,this.o=!1,this.i=!1,this.h=t,e!==null&&this.t.add(e??t),this.l=r,this.o=s??this.o,this.callback=i,window.ResizeObserver?(this.u=new ResizeObserver(a=>{this.handleChanges(a),this.h.requestUpdate()}),t.addController(this)):console.warn("ResizeController error: browser does not support ResizeObserver.")}handleChanges(t){var e;this.value=(e=this.callback)==null?void 0:e.call(this,t,this.u)}hostConnected(){for(const t of this.t)this.observe(t)}hostDisconnected(){this.disconnect()}async hostUpdated(){!this.o&&this.i&&this.handleChanges([]),this.i=!1}observe(t){this.t.add(t),this.u.observe(t,this.l),this.i=!0,this.h.requestUpdate()}unobserve(t){this.t.delete(t),this.u.unobserve(t)}disconnect(){this.u.disconnect()}};const or=k`
            /*!
 * Copyright 2025 Adobe. All rights reserved. This file is licensed to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License./
 * 
 *  Override divider background color when used inside alert-dialog/
 * .divider {
 *     --spectrum-divider-background-color: var(--system-alert-dialog-divider-background-color);
 *     --spectrum-divider-background-color-static-white: var(--spectrum-alert-dialog-divider-background-color-static-white);
 *     --spectrum-divider-background-color-static-black: var(--spectrum-alert-dialog-divider-background-color-static-black);
 * }
 */
:host{--spectrum-alert-dialog-min-width:var(--spectrum-alert-dialog-minimum-width);--spectrum-alert-dialog-max-width:var(--spectrum-alert-dialog-maximum-width);--spectrum-alert-dialog-icon-size:var(--spectrum-workflow-icon-size-100);--spectrum-alert-dialog-warning-icon-color:var(--spectrum-notice-visual-color);--spectrum-alert-dialog-error-icon-color:var(--spectrum-negative-visual-color);--spectrum-alert-dialog-title-font-family:var(--spectrum-sans-font-family-stack);--spectrum-alert-dialog-title-font-weight:var(--spectrum-heading-sans-serif-font-weight);--spectrum-alert-dialog-title-font-style:var(--spectrum-heading-sans-serif-font-style);--spectrum-alert-dialog-title-font-size:var(--spectrum-alert-dialog-title-size);--spectrum-alert-dialog-title-line-height:var(--spectrum-heading-line-height);--spectrum-alert-dialog-title-color:var(--spectrum-heading-color);--spectrum-alert-dialog-body-font-family:var(--spectrum-sans-font-family-stack);--spectrum-alert-dialog-body-font-weight:var(--spectrum-body-sans-serif-font-weight);--spectrum-alert-dialog-body-font-style:var(--spectrum-body-sans-serif-font-style);--spectrum-alert-dialog-body-font-size:var(--spectrum-alert-dialog-description-size);--spectrum-alert-dialog-body-line-height:var(--spectrum-line-height-100);--spectrum-alert-dialog-body-color:var(--spectrum-body-color);--spectrum-alert-dialog-title-to-divider:var(--spectrum-spacing-200);--spectrum-alert-dialog-divider-to-description:var(--spectrum-spacing-300);--spectrum-alert-dialog-title-to-icon:var(--spectrum-spacing-300);--mod-buttongroup-justify-content:flex-end;box-sizing:border-box;inline-size:fit-content;min-inline-size:var(--mod-alert-dialog-min-width,var(--spectrum-alert-dialog-min-width));max-inline-size:var(--mod-alert-dialog-max-width,var(--spectrum-alert-dialog-max-width));max-block-size:inherit;padding:var(--mod-alert-dialog-padding,var(--spectrum-alert-dialog-padding));outline:none;display:flex}.icon{inline-size:var(--mod-alert-dialog-icon-size,var(--spectrum-alert-dialog-icon-size));block-size:var(--mod-alert-dialog-icon-size,var(--spectrum-alert-dialog-icon-size));flex-shrink:0;margin-inline-start:var(--mod-alert-dialog-title-to-icon,var(--spectrum-alert-dialog-title-to-icon))}:host([variant=warning]){--mod-icon-color:var(--mod-alert-dialog-warning-icon-color,var(--spectrum-alert-dialog-warning-icon-color))}:host([variant=error]){--mod-icon-color:var(--mod-alert-dialog-error-icon-color,var(--spectrum-alert-dialog-error-icon-color))}.grid{display:grid}.header{justify-content:space-between;align-items:baseline;display:flex}::slotted([slot=heading]){font-family:var(--mod-alert-dialog-title-font-family,var(--spectrum-alert-dialog-title-font-family));font-weight:var(--mod-alert-dialog-title-font-weight,var(--spectrum-alert-dialog-title-font-weight));font-style:var(--mod-alert-dialog-title-font-style,var(--spectrum-alert-dialog-title-font-style));font-size:var(--mod-alert-dialog-title-font-size,var(--spectrum-alert-dialog-title-font-size));line-height:var(--mod-alert-dialog-title-line-height,var(--spectrum-alert-dialog-title-line-height));color:var(--mod-alert-dialog-title-color,var(--spectrum-alert-dialog-title-color));margin:0;margin-block-end:var(--mod-alert-dialog-title-to-divider,var(--spectrum-alert-dialog-title-to-divider))}.content{font-family:var(--mod-alert-dialog-body-font-family,var(--spectrum-alert-dialog-body-font-family));font-weight:var(--mod-alert-dialog-body-font-weight,var(--spectrum-alert-dialog-body-font-weight));font-style:var(--mod-alert-dialog-body-font-style,var(--spectrum-alert-dialog-body-font-style));font-size:var(--mod-alert-dialog-body-font-size,var(--spectrum-alert-dialog-body-font-size));line-height:var(--mod-alert-dialog-body-line-height,var(--spectrum-alert-dialog-body-line-height));color:var(--mod-alert-dialog-body-color,var(--spectrum-alert-dialog-body-color));-webkit-overflow-scrolling:touch;margin:0;margin-block-start:var(--mod-alert-dialog-divider-to-description,var(--spectrum-alert-dialog-divider-to-description));margin-block-end:var(--mod-alert-dialog-description-to-buttons,var(--spectrum-alert-dialog-description-to-buttons));overflow-y:auto}@media (forced-colors:active){:host{border:solid}}.divider{--spectrum-divider-background-color:var(--system-alert-dialog-divider-background-color);--spectrum-divider-background-color-static-white:var(--spectrum-alert-dialog-divider-background-color-static-white);--spectrum-divider-background-color-static-black:var(--spectrum-alert-dialog-divider-background-color-static-black)}
        `;var rr=Object.defineProperty,ir=Object.getOwnPropertyDescriptor,ze=(o,t,e,r)=>{for(var i=r>1?void 0:r?ir(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&rr(t,e,i),i};const sr=["confirmation","information","warning","error","destructive","secondary"];function Se(o,t){const e=o.assignedElements(),r=[];return e.forEach(i=>{if(i.id)r.push(i.id);else{const s=t+`-${to()}`;i.id=s,r.push(s)}}),r}const xt=class Ot extends Ge(dt){constructor(){super(...arguments),this.resizeController=new er(this,{callback:()=>{this.shouldManageTabOrderForScrolling()}}),this._variant="",this.labelledbyId=`sp-dialog-label-${Ot.instanceCount++}`,this.shouldManageTabOrderForScrolling=()=>{if(!this.contentElement)return;const{offsetHeight:t,scrollHeight:e}=this.contentElement;t<e?this.contentElement.tabIndex=0:this.contentElement.removeAttribute("tabindex")},this.describedbyId=`sp-dialog-description-${Ot.instanceCount++}`}static get styles(){return[or]}set variant(t){if(t===this.variant)return;const e=this.variant;sr.includes(t)?(this.setAttribute("variant",t),this._variant=t):(this.removeAttribute("variant"),this._variant=""),this.requestUpdate("variant",e)}get variant(){return this._variant}renderIcon(){switch(this.variant){case"warning":case"error":return n`
                    <sp-icon-alert class="icon"></sp-icon-alert>
                `;default:return n``}}renderHeading(){return n`
            <slot name="heading" @slotchange=${this.onHeadingSlotchange}></slot>
        `}renderContent(){return n`
            <div class="content">
                <slot @slotchange=${this.onContentSlotChange}></slot>
            </div>
        `}onHeadingSlotchange({target:t}){this.conditionLabelledby&&(this.conditionLabelledby(),delete this.conditionLabelledby);const e=Se(t,this.labelledbyId);e.length&&(this.conditionLabelledby=Mt(this,"aria-labelledby",e))}onContentSlotChange({target:t}){requestAnimationFrame(()=>{this.resizeController.unobserve(this.contentElement),this.resizeController.observe(this.contentElement)}),this.conditionDescribedby&&(this.conditionDescribedby(),delete this.conditionDescribedby);const e=Se(t,this.describedbyId);if(e.length&&e.length<4)this.conditionDescribedby=Mt(this,"aria-describedby",e);else if(!e.length){const r=!!this.id;r||(this.id=this.describedbyId);const i=Mt(this,"aria-describedby",this.id);this.conditionDescribedby=()=>{i(),r||this.removeAttribute("id")}}}renderButtons(){return n`
            <sp-button-group class="button-group">
                <slot name="button"></slot>
            </sp-button-group>
        `}render(){return n`
            <div class="grid">
                <div class="header">
                    ${this.renderHeading()} ${this.renderIcon()}
                </div>
                <sp-divider size="m" class="divider"></sp-divider>
                ${this.renderContent()} ${this.renderButtons()}
            </div>
        `}};xt.instanceCount=0,ze([ut(".content")],xt.prototype,"contentElement",2),ze([l({type:String,reflect:!0})],xt.prototype,"variant",1);let ar=xt;const nr=k`
    :host{box-sizing:border-box;inline-size:fit-content;min-inline-size:var(--mod-dialog-min-inline-size,var(--spectrum-dialog-min-inline-size));max-inline-size:100%;max-block-size:inherit;outline:none;display:flex}:host([size=s]){inline-size:var(--mod-dialog-confirm-small-width,var(--spectrum-dialog-confirm-small-width))}:host([size=m]){inline-size:var(--mod-dialog-confirm-medium-width,var(--spectrum-dialog-confirm-medium-width))}:host([size=l]){inline-size:var(--mod-dialog-confirm-large-width,var(--spectrum-dialog-confirm-large-width))}::slotted([slot=hero]){block-size:var(--mod-dialog-confirm-hero-height,var(--spectrum-dialog-confirm-hero-height));background-position:50%;background-size:cover;border-start-start-radius:var(--mod-dialog-confirm-border-radius,var(--spectrum-dialog-confirm-border-radius));border-start-end-radius:var(--mod-dialog-confirm-border-radius,var(--spectrum-dialog-confirm-border-radius));grid-area:hero;overflow:hidden}.grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto 1fr auto minmax(0,auto)var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:"hero hero hero hero hero hero"". . . . . ."".heading header header header."".divider divider divider divider."".content content content content."".footer footer buttonGroup buttonGroup."". . . . . .";grid-template-rows:auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto auto 1fr auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));inline-size:100%;display:grid}::slotted([slot=heading]){font-size:var(--mod-dialog-confirm-title-text-size,var(--spectrum-dialog-confirm-title-text-size));font-weight:var(--mod-dialog-heading-font-weight,var(--spectrum-dialog-heading-font-weight));line-height:var(--mod-dialog-confirm-title-text-line-height,var(--spectrum-dialog-confirm-title-text-line-height));color:var(--mod-dialog-confirm-title-text-color,var(--spectrum-dialog-confirm-title-text-color));outline:none;grid-area:heading;margin:0;padding-inline-end:var(--mod-dialog-confirm-gap-size,var(--spectrum-dialog-confirm-gap-size))}.no-header::slotted([slot=heading]){grid-area:heading-start/heading-start/header-end/header-end;padding-inline-end:0}.header{box-sizing:border-box;outline:none;grid-area:header;justify-content:flex-end;align-items:center;display:flex}.divider{inline-size:100%;grid-area:divider;margin-block-start:var(--mod-dialog-confirm-divider-block-spacing-end,var(--spectrum-dialog-confirm-divider-block-spacing-end));margin-block-end:var(--mod-dialog-confirm-divider-block-spacing-start,var(--spectrum-dialog-confirm-divider-block-spacing-start))}:host([mode=fullscreen]) [name=heading]+.divider{margin-block-end:calc(var(--mod-dialog-confirm-divider-block-spacing-start,var(--spectrum-dialog-confirm-divider-block-spacing-start)) - var(--mod-dialog-confirm-description-padding,var(--spectrum-dialog-confirm-description-padding))*2)}:host([no-divider]) .divider{display:none}:host([no-divider]) ::slotted([slot=heading]){padding-block-end:calc(var(--mod-dialog-confirm-divider-block-spacing-end,var(--spectrum-dialog-confirm-divider-block-spacing-end)) + var(--mod-dialog-confirm-divider-block-spacing-start,var(--spectrum-dialog-confirm-divider-block-spacing-start)) + var(--mod-dialog-confirm-divider-height,var(--spectrum-dialog-confirm-divider-height)))}.content{box-sizing:border-box;-webkit-overflow-scrolling:touch;font-size:var(--mod-dialog-confirm-description-text-size,var(--spectrum-dialog-confirm-description-text-size));font-weight:var(--mod-dialog-confirm-description-font-weight,var(--spectrum-regular-font-weight));line-height:var(--mod-dialog-confirm-description-text-line-height,var(--spectrum-dialog-confirm-description-text-line-height));color:var(--mod-dialog-confirm-description-text-color,var(--spectrum-dialog-confirm-description-text-color));padding:calc(var(--mod-dialog-confirm-description-padding,var(--spectrum-dialog-confirm-description-padding))*2);margin:0 var(--mod-dialog-confirm-description-margin,var(--spectrum-dialog-confirm-description-margin));outline:none;grid-area:content;overflow-y:auto}.footer{outline:none;flex-wrap:wrap;grid-area:footer;padding-block-start:var(--mod-dialog-confirm-footer-padding-top,var(--spectrum-dialog-confirm-footer-padding-top));display:flex}.footer>*,.footer>.spectrum-Button+.spectrum-Button{margin-block-end:0}.button-group{grid-area:buttonGroup;justify-content:flex-end;padding-block-start:var(--mod-dialog-confirm-buttongroup-padding-top,var(--spectrum-dialog-confirm-buttongroup-padding-top));padding-inline-start:var(--mod-dialog-confirm-gap-size,var(--spectrum-dialog-confirm-gap-size));display:flex}.button-group.button-group--noFooter{grid-area:footer-start/footer-start/buttonGroup-end/buttonGroup-end}:host([dismissable]) .grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto 1fr auto minmax(0,auto)minmax(0,var(--mod-dialog-confirm-close-button-size,var(--spectrum-dialog-confirm-close-button-size)))var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:"hero hero hero hero hero hero hero"". . . . .closeButton closeButton"".heading header header typeIcon closeButton closeButton"".divider divider divider divider divider."".content content content content content."".footer footer buttonGroup buttonGroup buttonGroup."". . . . . . .";grid-template-rows:auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto auto 1fr auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))}:host([dismissable]) .grid .button-group{display:none}:host([dismissable]) .grid .footer{color:var(--mod-dialog-confirm-description-text-color,var(--spectrum-dialog-confirm-description-text-color));grid-area:footer/footer/buttonGroup/buttonGroup}.close-button{grid-area:closeButton;place-self:start end;margin-block-start:var(--mod-dialog-confirm-close-button-padding,var(--spectrum-dialog-confirm-close-button-padding));margin-inline-end:var(--mod-dialog-confirm-close-button-padding,var(--spectrum-dialog-confirm-close-button-padding))}:host([mode=fullscreen]){block-size:100%;inline-size:100%}:host([mode=fullscreenTakeover]){border-radius:0;block-size:100%;inline-size:100%}:host([mode=fullscreen]),:host([mode=fullscreenTakeover]){max-block-size:none;max-inline-size:none}:host([mode=fullscreen]) .grid,:host([mode=fullscreenTakeover]) .grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))1fr auto auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-rows:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto auto 1fr var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:". . . . ."".heading header buttonGroup."".divider divider divider."".content content content."". . . . .";display:grid}:host([mode=fullscreen]) ::slotted([slot=heading]),:host([mode=fullscreenTakeover]) ::slotted([slot=heading]){font-size:var(--mod-dialog-fullscreen-header-text-size,var(--spectrum-dialog-fullscreen-header-text-size))}:host([mode=fullscreen]) .content,:host([mode=fullscreenTakeover]) .content{max-block-size:none}:host([mode=fullscreen]) .button-group,:host([mode=fullscreen]) .footer,:host([mode=fullscreenTakeover]) .button-group,:host([mode=fullscreenTakeover]) .footer{padding-block-start:0}:host([mode=fullscreen]) .footer,:host([mode=fullscreenTakeover]) .footer{display:none}:host([mode=fullscreen]) .button-group,:host([mode=fullscreenTakeover]) .button-group{grid-area:buttonGroup;align-self:start}@media screen and (width<=700px){.grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto 1fr auto minmax(0,auto)var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:"hero hero hero hero hero hero"". . . . . ."".heading heading heading heading."".header header header header."".divider divider divider divider."".content content content content."".footer footer buttonGroup buttonGroup."". . . . . ."}.grid,:host([dismissable]) .grid{grid-template-rows:auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto auto auto 1fr auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))}:host([dismissable]) .grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto 1fr auto minmax(0,auto)minmax(0,var(--mod-dialog-confirm-close-button-size,var(--spectrum-dialog-confirm-close-button-size)))var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:"hero hero hero hero hero hero hero"". . . . .closeButton closeButton"".heading heading heading heading closeButton closeButton"".header header header header header."".divider divider divider divider divider."".content content content content content."".footer footer buttonGroup buttonGroup buttonGroup."". . . . . . ."}.header{justify-content:flex-start}:host([mode=fullscreen]) .grid,:host([mode=fullscreenTakeover]) .grid{grid-template-columns:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))1fr var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-rows:var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid))auto auto auto 1fr auto var(--mod-dialog-confirm-padding-grid,var(--spectrum-dialog-confirm-padding-grid));grid-template-areas:". . ."".heading."".header."".divider."".content."".buttonGroup."". . .";display:grid}:host([mode=fullscreen]) .button-group,:host([mode=fullscreenTakeover]) .button-group{padding-block-start:var(--mod-dialog-confirm-buttongroup-padding-top,var(--spectrum-dialog-confirm-buttongroup-padding-top))}:host([mode=fullscreen]) ::slotted([slot=heading]),:host([mode=fullscreenTakeover]) ::slotted([slot=heading]){font-size:var(--mod-dialog-confirm-title-text-size,var(--spectrum-dialog-confirm-title-text-size))}}@media (forced-colors:active){:host{border:solid}}:host{--spectrum-dialog-fullscreen-header-text-size:var(--system-dialog-fullscreen-header-text-size);--spectrum-dialog-min-inline-size:var(--system-dialog-min-inline-size);--spectrum-dialog-confirm-small-width:var(--system-dialog-confirm-small-width);--spectrum-dialog-confirm-medium-width:var(--system-dialog-confirm-medium-width);--spectrum-dialog-confirm-large-width:var(--system-dialog-confirm-large-width);--spectrum-dialog-confirm-divider-block-spacing-start:var(--system-dialog-confirm-divider-block-spacing-start);--spectrum-dialog-confirm-divider-block-spacing-end:var(--system-dialog-confirm-divider-block-spacing-end);--spectrum-dialog-confirm-description-text-color:var(--system-dialog-confirm-description-text-color);--spectrum-dialog-confirm-title-text-color:var(--system-dialog-confirm-title-text-color);--spectrum-dialog-confirm-description-text-line-height:var(--system-dialog-confirm-description-text-line-height);--spectrum-dialog-confirm-title-text-line-height:var(--system-dialog-confirm-title-text-line-height);--spectrum-dialog-heading-font-weight:var(--system-dialog-heading-font-weight);--spectrum-dialog-confirm-description-padding:var(--system-dialog-confirm-description-padding);--spectrum-dialog-confirm-description-margin:var(--system-dialog-confirm-description-margin);--spectrum-dialog-confirm-footer-padding-top:var(--system-dialog-confirm-footer-padding-top);--spectrum-dialog-confirm-gap-size:var(--system-dialog-confirm-gap-size);--spectrum-dialog-confirm-buttongroup-padding-top:var(--system-dialog-confirm-buttongroup-padding-top);--spectrum-dialog-confirm-close-button-size:var(--system-dialog-confirm-close-button-size);--spectrum-dialog-confirm-close-button-padding:var(--system-dialog-confirm-close-button-padding);--spectrum-dialog-confirm-divider-height:var(--system-dialog-confirm-divider-height)}:host{--swc-alert-dialog-error-icon-color:var(--spectrum-negative-visual-color)}.content{overflow:hidden}.footer{color:var(--spectrum-dialog-confirm-description-text-color,var(--spectrum-gray-800))}.type-icon{color:var(--mod-alert-dialog-error-icon-color,var(--swc-alert-dialog-error-icon-color));grid-area:typeIcon}.content[tabindex]{overflow:auto}::slotted(img[slot=hero]){width:100%;height:auto}.grid{grid-template-areas:"hero hero hero hero hero hero"". . . . . ."".heading heading heading typeIcon."".divider divider divider divider."".content content content content."".footer footer buttonGroup buttonGroup."". . . . . .";inline-size:100%;display:grid}:host(:not([error],[dismissable],[mode])) .grid{grid-template-areas:"hero hero hero hero hero hero"". . . . . ."".heading heading heading heading."".divider divider divider divider."".content content content content."".footer footer buttonGroup buttonGroup."". . . . . .";inline-size:100%;display:grid}
`;var lr=Object.defineProperty,V=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&lr(t,e,i),i};class O extends eo(ar,['[slot="hero"]','[slot="footer"]','[slot="button"]']){constructor(){super(...arguments),this.error=!1,this.dismissable=!1,this.dismissLabel="Close",this.noDivider=!1}static get styles(){return[nr]}get hasFooter(){return this.getSlotContentPresence('[slot="footer"]')}get hasButtons(){return this.getSlotContentPresence('[slot="button"]')}get hasHero(){return this.getSlotContentPresence('[slot="hero"]')}close(){this.dispatchEvent(new Event("close",{bubbles:!0,composed:!0,cancelable:!0}))}renderHero(){return n`
            <slot name="hero"></slot>
        `}renderFooter(){return n`
            <div class="footer">
                <slot name="footer"></slot>
            </div>
        `}renderButtons(){const t={"button-group":!0,"button-group--noFooter":!this.hasFooter};return n`
            <sp-button-group class=${oo(t)}>
                <slot name="button"></slot>
            </sp-button-group>
        `}renderDismiss(){return n`
            <sp-close-button
                class="close-button"
                label=${this.dismissLabel}
                quiet
                size="m"
                @click=${this.close}
            ></sp-close-button>
        `}render(){return n`
            <div class="grid">
                ${this.renderHero()} ${this.renderHeading()}
                ${this.error?n`
                          <sp-icon-alert class="type-icon"></sp-icon-alert>
                      `:z}
                ${this.noDivider?z:n`
                          <sp-divider size="m" class="divider"></sp-divider>
                      `}
                ${this.renderContent()}
                ${this.hasFooter?this.renderFooter():z}
                ${this.hasButtons?this.renderButtons():z}
                ${this.dismissable?this.renderDismiss():z}
            </div>
        `}shouldUpdate(t){return t.has("mode")&&this.mode&&(this.dismissable=!1),t.has("dismissable")&&this.dismissable&&(this.dismissable=!this.mode),super.shouldUpdate(t)}firstUpdated(t){super.firstUpdated(t),this.setAttribute("role","dialog")}updated(t){super.updated(t)}}V([ut(".close-button")],O.prototype,"closeButton"),V([l({type:Boolean,reflect:!0})],O.prototype,"error"),V([l({type:Boolean,reflect:!0})],O.prototype,"dismissable"),V([l({type:String,reflect:!0,attribute:"dismiss-label"})],O.prototype,"dismissLabel"),V([l({type:Boolean,reflect:!0,attribute:"no-divider"})],O.prototype,"noDivider"),V([l({type:String,reflect:!0})],O.prototype,"mode"),V([l({type:String,reflect:!0})],O.prototype,"size");x("sp-dialog",O);const cr=k`
    :host{box-sizing:border-box;visibility:hidden;pointer-events:none;z-index:1;block-size:stretch;inline-size:100vw;transition:visibility 0s linear var(--mod-modal-transition-animation-duration,var(--spectrum-animation-duration-100));justify-content:center;align-items:center;display:flex;position:fixed;inset-block-start:0;inset-inline-start:0}:host([open]){visibility:visible}@media only screen and (device-height<=350px),only screen and (device-width<=400px){:host([responsive]){border-radius:0;block-size:100%;max-block-size:100%;inline-size:100%;max-inline-size:100%;margin-block-start:0}}
`;var dr=Object.defineProperty,it=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&dr(t,e,i),i};class X extends Ge(dt){constructor(){super(...arguments),this.dismissable=!1,this.open=!1,this.responsive=!1,this.transitionPromise=Promise.resolve(),this.resolveTransitionPromise=()=>{},this.underlay=!1,this.animating=!1}static get styles(){return[cr,uo]}get dialog(){return this.shadowRoot.querySelector("slot").assignedElements()[0]||this}async focus(){if(this.shadowRoot){const t=ho(this.dialog);t?(t.updateComplete&&await t.updateComplete,t.focus()):this.dialog.focus()}else super.focus()}overlayWillCloseCallback(){return this.open?(this.close(),!0):this.animating}dismiss(){this.dismissable&&this.close()}handleClose(t){t.stopPropagation(),this.close()}close(){this.open=!1}dispatchClosed(){this.dispatchEvent(new Event("close",{bubbles:!0}))}handleTransitionEvent(t){this.dispatchEvent(new TransitionEvent(t.type,{bubbles:!0,composed:!0,propertyName:t.propertyName}))}handleUnderlayTransitionend(t){!this.open&&t.propertyName==="visibility"&&this.resolveTransitionPromise(),this.handleTransitionEvent(t)}handleModalTransitionend(t){(this.open||!this.underlay)&&this.resolveTransitionPromise(),this.handleTransitionEvent(t)}get hasTransitionDuration(){const t=this.shadowRoot.querySelector(".modal"),e=window.getComputedStyle(t).transitionDuration;for(const i of e.split(","))if(parseFloat(i)>0)return!0;const r=this.shadowRoot.querySelector("sp-underlay");if(r){const i=window.getComputedStyle(r).transitionDuration;for(const s of i.split(","))if(parseFloat(s)>0)return!0}return!1}update(t){if(t.has("open")&&t.get("open")!==void 0){const e=this.hasTransitionDuration;this.animating=!0,this.transitionPromise=new Promise(r=>{this.resolveTransitionPromise=()=>{this.animating=!1,!this.open&&e&&this.dispatchClosed(),r()}}),!this.open&&!e&&this.dispatchClosed()}super.update(t)}renderDialog(){return n`
            <slot></slot>
        `}render(){return n`
            ${this.underlay?n`
                      <sp-underlay
                          ?open=${this.open}
                          @close=${this.dismiss}
                          @transitionrun=${this.handleTransitionEvent}
                          @transitionend=${this.handleUnderlayTransitionend}
                          @transitioncancel=${this.handleTransitionEvent}
                      ></sp-underlay>
                  `:z}
            <div
                class="modal ${this.mode}"
                @transitionrun=${this.handleTransitionEvent}
                @transitionend=${this.handleModalTransitionend}
                @transitioncancel=${this.handleTransitionEvent}
                @close=${this.handleClose}
            >
                ${this.renderDialog()}
            </div>
        `}updated(t){t.has("open")&&this.open&&"updateComplete"in this.dialog&&"shouldManageTabOrderForScrolling"in this.dialog&&this.dialog.updateComplete.then(()=>{this.dialog.shouldManageTabOrderForScrolling()})}async getUpdateComplete(){const t=await super.getUpdateComplete();return await this.transitionPromise,t}}it([l({type:Boolean,reflect:!0})],X.prototype,"dismissable"),it([l({type:Boolean,reflect:!0})],X.prototype,"open"),it([l({type:String,reflect:!0})],X.prototype,"mode"),it([l({type:Boolean})],X.prototype,"responsive"),it([l({type:Boolean})],X.prototype,"underlay");var ur=Object.defineProperty,D=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&ur(t,e,i),i};class P extends X{constructor(){super(...arguments),this.error=!1,this.cancelLabel="",this.confirmLabel="",this.dismissLabel="Close",this.footer="",this.hero="",this.heroLabel="",this.noDivider=!1,this.secondaryLabel="",this.headline=""}static get styles(){return[...super.styles]}get dialog(){return this.shadowRoot.querySelector("sp-dialog")}clickSecondary(){this.dispatchEvent(new Event("secondary",{bubbles:!0}))}clickCancel(){this.dispatchEvent(new Event("cancel",{bubbles:!0}))}clickConfirm(){this.dispatchEvent(new Event("confirm",{bubbles:!0}))}renderDialog(){const t=this.noDivider||!this.headline||this.headlineVisibility==="none";return n`
            <sp-dialog
                ?dismissable=${this.dismissable}
                dismiss-label=${this.dismissLabel}
                ?no-divider=${t}
                ?error=${this.error}
                mode=${nt(this.mode)}
                size=${nt(this.size)}
            >
                ${this.hero?n`
                          <img
                              src="${this.hero}"
                              slot="hero"
                              aria-hidden=${nt(this.heroLabel?void 0:"true")}
                              alt=${nt(this.heroLabel?this.heroLabel:void 0)}
                          />
                      `:z}
                ${this.headline?n`
                          <h2
                              slot="heading"
                              ?hidden=${this.headlineVisibility==="none"}
                          >
                              ${this.headline}
                          </h2>
                      `:z}
                <slot></slot>
                ${this.footer?n`
                          <div slot="footer">${this.footer}</div>
                      `:z}
                ${this.cancelLabel?n`
                          <sp-button
                              variant="secondary"
                              treatment="outline"
                              slot="button"
                              @click=${this.clickCancel}
                          >
                              ${this.cancelLabel}
                          </sp-button>
                      `:z}
                ${this.secondaryLabel?n`
                          <sp-button
                              variant="primary"
                              treatment="outline"
                              slot="button"
                              @click=${this.clickSecondary}
                          >
                              ${this.secondaryLabel}
                          </sp-button>
                      `:z}
                ${this.confirmLabel?n`
                          <sp-button
                              variant="accent"
                              slot="button"
                              @click=${this.clickConfirm}
                          >
                              ${this.confirmLabel}
                          </sp-button>
                      `:z}
            </sp-dialog>
        `}}D([l({type:Boolean,reflect:!0})],P.prototype,"error"),D([l({attribute:"cancel-label"})],P.prototype,"cancelLabel"),D([l({attribute:"confirm-label"})],P.prototype,"confirmLabel"),D([l({attribute:"dismiss-label"})],P.prototype,"dismissLabel"),D([l()],P.prototype,"footer"),D([l()],P.prototype,"hero"),D([l({attribute:"hero-label"})],P.prototype,"heroLabel"),D([l({type:Boolean,reflect:!0,attribute:"no-divider"})],P.prototype,"noDivider"),D([l({type:String,reflect:!0})],P.prototype,"size"),D([l({attribute:"secondary-label"})],P.prototype,"secondaryLabel"),D([l()],P.prototype,"headline"),D([l({type:String,attribute:"headline-visibility"})],P.prototype,"headlineVisibility");x("sp-dialog-wrapper",P);const hr=k`
    :host {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .controls-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px 16px;
    }

    .control-selector-top {
        display: flex;
        flex-direction: column;
        gap: 4px;
        grid-column: span 2;
    }

    .control-selector-label {
        font-size: 11px;
        color: var(--spectrum-gray-700);
        font-weight: 500;
    }

    .control-selector-top sp-picker {
        width: 100%;
    }

    .range-field {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .range-label {
        font-size: 11px;
        color: var(--spectrum-gray-700);
        font-weight: 500;
    }

    .range-field sp-number-field,
    .range-field sp-picker {
        width: 100%;
    }

    .graph-bg {
        fill: var(--spectrum-gray-75);
        stroke: var(--spectrum-gray-300);
        stroke-width: 1;
    }

    .axis {
        stroke: var(--spectrum-gray-500);
        stroke-width: 1.5;
    }

    .axis-label {
        font-size: 10px;
        fill: var(--spectrum-gray-700);
    }

    .curve-line {
        fill: none;
        stroke-linecap: round;
        stroke-linejoin: round;
    }
`;class pr{constructor(t){this.hosts=new Set,this._state={tabletPressed:!1,tabletX:0,tabletY:0,tiltPressed:!1,tiltX:0,tiltY:0,tiltXY:0,tiltPressure:0,primaryButtonPressed:!1,secondaryButtonPressed:!1,tabletButtons:Array(8).fill(!1),lastHoveredString:null,lastPressedButton:null},t&&this.addHost(t)}addHost(t){this.hosts.add(t),t.addController(this)}removeHost(t){this.hosts.delete(t)}notifyHosts(){this.hosts.forEach(t=>t.requestUpdate())}hostConnected(){}hostDisconnected(){}get state(){return this._state}setTabletPosition(t,e,r){this._state.tabletX=t,this._state.tabletY=e,this._state.tabletPressed=r,this.notifyHosts()}setTabletPressed(t){this._state.tabletPressed=t,this.notifyHosts()}setTiltPosition(t,e,r,i,s){if(this._state.tiltX=t,this._state.tiltY=e,this._state.tiltPressure=r,this._state.tiltPressed=i,s!==void 0)this._state.tiltXY=s;else{const a=Math.sqrt(t*t+e*e),c=t*e>=0?1:-1;this._state.tiltXY=Math.max(-1,Math.min(1,a*c))}this.notifyHosts()}setTiltPressed(t){this._state.tiltPressed=t,t||(this._state.tiltX=0,this._state.tiltY=0,this._state.tiltXY=0,this._state.tiltPressure=0),this.notifyHosts()}setPrimaryButton(t){this._state.primaryButtonPressed=t,this.notifyHosts()}setSecondaryButton(t){this._state.secondaryButtonPressed=t,this.notifyHosts()}setTabletButton(t,e){t>=0&&t<this._state.tabletButtons.length&&(this._state.tabletButtons[t]=e,e&&(this._state.lastPressedButton=t),this.notifyHosts())}setLastHoveredString(t){this._state.lastHoveredString=t,this.notifyHosts()}reset(){this._state={tabletPressed:!1,tabletX:0,tabletY:0,tiltPressed:!1,tiltX:0,tiltY:0,tiltXY:0,tiltPressure:0,primaryButtonPressed:!1,secondaryButtonPressed:!1,tabletButtons:Array(8).fill(!1),lastHoveredString:null,lastPressedButton:null},this.notifyHosts()}}const W=new pr;let Nt=new Map,Lt=!1;try{Lt=new Intl.NumberFormat("de-DE",{signDisplay:"exceptZero"}).resolvedOptions().signDisplay==="exceptZero"}catch{}let zt=!1;try{zt=new Intl.NumberFormat("de-DE",{style:"unit",unit:"degree"}).resolvedOptions().style==="unit"}catch{}const He={degree:{narrow:{default:"°","ja-JP":" 度","zh-TW":"度","sl-SI":" °"}}};class kt{format(t){let e="";if(!Lt&&this.options.signDisplay!=null?e=gr(this.numberFormatter,this.options.signDisplay,t):e=this.numberFormatter.format(t),this.options.style==="unit"&&!zt){var r;let{unit:i,unitDisplay:s="short",locale:a}=this.resolvedOptions();if(!i)return e;let c=(r=He[i])===null||r===void 0?void 0:r[s];e+=c[a]||c.default}return e}formatToParts(t){return this.numberFormatter.formatToParts(t)}formatRange(t,e){if(typeof this.numberFormatter.formatRange=="function")return this.numberFormatter.formatRange(t,e);if(e<t)throw new RangeError("End date must be >= start date");return`${this.format(t)} – ${this.format(e)}`}formatRangeToParts(t,e){if(typeof this.numberFormatter.formatRangeToParts=="function")return this.numberFormatter.formatRangeToParts(t,e);if(e<t)throw new RangeError("End date must be >= start date");let r=this.numberFormatter.formatToParts(t),i=this.numberFormatter.formatToParts(e);return[...r.map(s=>({...s,source:"startRange"})),{type:"literal",value:" – ",source:"shared"},...i.map(s=>({...s,source:"endRange"}))]}resolvedOptions(){let t=this.numberFormatter.resolvedOptions();return!Lt&&this.options.signDisplay!=null&&(t={...t,signDisplay:this.options.signDisplay}),!zt&&this.options.style==="unit"&&(t={...t,style:"unit",unit:this.options.unit,unitDisplay:this.options.unitDisplay}),t}constructor(t,e={}){this.numberFormatter=mr(t,e),this.options=e}}function mr(o,t={}){let{numberingSystem:e}=t;if(e&&o.includes("-nu-")&&(o.includes("-u-")||(o+="-u-"),o+=`-nu-${e}`),t.style==="unit"&&!zt){var r;let{unit:a,unitDisplay:c="short"}=t;if(!a)throw new Error('unit option must be provided with style: "unit"');if(!(!((r=He[a])===null||r===void 0)&&r[c]))throw new Error(`Unsupported unit ${a} with unitDisplay = ${c}`);t={...t,style:"decimal"}}let i=o+(t?Object.entries(t).sort((a,c)=>a[0]<c[0]?-1:1).join():"");if(Nt.has(i))return Nt.get(i);let s=new Intl.NumberFormat(o,t);return Nt.set(i,s),s}function gr(o,t,e){if(t==="auto")return o.format(e);if(t==="never")return o.format(Math.abs(e));{let r=!1;if(t==="always"?r=e>0||Object.is(e,0):t==="exceptZero"&&(Object.is(e,-0)||Object.is(e,0)?e=Math.abs(e):r=e>0),r){let i=o.format(-e),s=o.format(e),a=i.replace(s,"").replace(/\u200e|\u061C/,"");return[...a].length!==1&&console.warn("@react-aria/i18n polyfill for NumberFormat signDisplay: Unsupported case"),i.replace(s,"!!!").replace(a,"+").replace("!!!",s)}else return o.format(e)}}const br=new RegExp("^.*\\(.*\\).*$"),vr=["latn","arab","hanidec","deva","beng","fullwide"];class Vt{parse(t){return Ft(this.locale,this.options,t).parse(t)}isValidPartialNumber(t,e,r){return Ft(this.locale,this.options,t).isValidPartialNumber(t,e,r)}getNumberingSystem(t){return Ft(this.locale,this.options,t).options.numberingSystem}constructor(t,e={}){this.locale=t,this.options=e}}const Pe=new Map;function Ft(o,t,e){let r=De(o,t);if(!o.includes("-nu-")&&!r.isValidPartialNumber(e)){for(let i of vr)if(i!==r.options.numberingSystem){let s=De(o+(o.includes("-u-")?"-nu-":"-u-nu-")+i,t);if(s.isValidPartialNumber(e))return s}}return r}function De(o,t){let e=o+(t?Object.entries(t).sort((i,s)=>i[0]<s[0]?-1:1).join():""),r=Pe.get(e);return r||(r=new fr(o,t),Pe.set(e,r)),r}class fr{parse(t){let e=this.sanitize(t);if(this.symbols.group&&(e=Z(e,this.symbols.group,"")),this.symbols.decimal&&(e=e.replace(this.symbols.decimal,".")),this.symbols.minusSign&&(e=e.replace(this.symbols.minusSign,"-")),e=e.replace(this.symbols.numeral,this.symbols.index),this.options.style==="percent"){let a=e.indexOf("-");e=e.replace("-",""),e=e.replace("+","");let c=e.indexOf(".");c===-1&&(c=e.length),e=e.replace(".",""),c-2===0?e=`0.${e}`:c-2===-1?e=`0.0${e}`:c-2===-2?e="0.00":e=`${e.slice(0,c-2)}.${e.slice(c-2)}`,a>-1&&(e=`-${e}`)}let r=e?+e:NaN;if(isNaN(r))return NaN;if(this.options.style==="percent"){var i,s;let a={...this.options,style:"decimal",minimumFractionDigits:Math.min(((i=this.options.minimumFractionDigits)!==null&&i!==void 0?i:0)+2,20),maximumFractionDigits:Math.min(((s=this.options.maximumFractionDigits)!==null&&s!==void 0?s:0)+2,20)};return new Vt(this.locale,a).parse(new kt(this.locale,a).format(r))}return this.options.currencySign==="accounting"&&br.test(t)&&(r=-1*r),r}sanitize(t){return t=t.replace(this.symbols.literals,""),this.symbols.minusSign&&(t=t.replace("-",this.symbols.minusSign)),this.options.numberingSystem==="arab"&&(this.symbols.decimal&&(t=t.replace(",",this.symbols.decimal),t=t.replace("،",this.symbols.decimal)),this.symbols.group&&(t=Z(t,".",this.symbols.group))),this.symbols.group==="’"&&t.includes("'")&&(t=Z(t,"'",this.symbols.group)),this.options.locale==="fr-FR"&&this.symbols.group&&(t=Z(t," ",this.symbols.group),t=Z(t,/\u00A0/g,this.symbols.group)),t}isValidPartialNumber(t,e=-1/0,r=1/0){return t=this.sanitize(t),this.symbols.minusSign&&t.startsWith(this.symbols.minusSign)&&e<0?t=t.slice(this.symbols.minusSign.length):this.symbols.plusSign&&t.startsWith(this.symbols.plusSign)&&r>0&&(t=t.slice(this.symbols.plusSign.length)),this.symbols.group&&t.startsWith(this.symbols.group)||this.symbols.decimal&&t.indexOf(this.symbols.decimal)>-1&&this.options.maximumFractionDigits===0?!1:(this.symbols.group&&(t=Z(t,this.symbols.group,"")),t=t.replace(this.symbols.numeral,""),this.symbols.decimal&&(t=t.replace(this.symbols.decimal,"")),t.length===0)}constructor(t,e={}){this.locale=t,e.roundingIncrement!==1&&e.roundingIncrement!=null&&(e.maximumFractionDigits==null&&e.minimumFractionDigits==null?(e.maximumFractionDigits=0,e.minimumFractionDigits=0):e.maximumFractionDigits==null?e.maximumFractionDigits=e.minimumFractionDigits:e.minimumFractionDigits==null&&(e.minimumFractionDigits=e.maximumFractionDigits)),this.formatter=new Intl.NumberFormat(t,e),this.options=this.formatter.resolvedOptions(),this.symbols=wr(t,this.formatter,this.options,e);var r,i;this.options.style==="percent"&&(((r=this.options.minimumFractionDigits)!==null&&r!==void 0?r:0)>18||((i=this.options.maximumFractionDigits)!==null&&i!==void 0?i:0)>18)&&console.warn("NumberParser cannot handle percentages with greater than 18 decimal places, please reduce the number in your options.")}}const Ie=new Set(["decimal","fraction","integer","minusSign","plusSign","group"]),yr=[0,4,2,1,11,20,3,7,100,21,.1,1.1];function wr(o,t,e,r){var i,s,a,c;let u=new Intl.NumberFormat(o,{...e,minimumSignificantDigits:1,maximumSignificantDigits:21,roundingIncrement:1,roundingPriority:"auto",roundingMode:"halfExpand"}),d=u.formatToParts(-10000.111),m=u.formatToParts(10000.111),$=yr.map(v=>u.formatToParts(v));var w;let _=(w=(i=d.find(v=>v.type==="minusSign"))===null||i===void 0?void 0:i.value)!==null&&w!==void 0?w:"-",F=(s=m.find(v=>v.type==="plusSign"))===null||s===void 0?void 0:s.value;!F&&((r==null?void 0:r.signDisplay)==="exceptZero"||(r==null?void 0:r.signDisplay)==="always")&&(F="+");let Q=(a=new Intl.NumberFormat(o,{...e,minimumFractionDigits:2,maximumFractionDigits:2}).formatToParts(.001).find(v=>v.type==="decimal"))===null||a===void 0?void 0:a.value,tt=(c=d.find(v=>v.type==="group"))===null||c===void 0?void 0:c.value,et=d.filter(v=>!Ie.has(v.type)).map(v=>Be(v.value)),pt=$.flatMap(v=>v.filter(M=>!Ie.has(M.type)).map(M=>Be(M.value))),ot=[...new Set([...et,...pt])].sort((v,M)=>M.length-v.length),mt=ot.length===0?new RegExp("[\\p{White_Space}]","gu"):new RegExp(`${ot.join("|")}|[\\p{White_Space}]`,"gu"),rt=[...new Intl.NumberFormat(e.locale,{useGrouping:!1}).format(9876543210)].reverse(),gt=new Map(rt.map((v,M)=>[v,M])),bt=new RegExp(`[${rt.join("")}]`,"g");return{minusSign:_,plusSign:F,decimal:Q,group:tt,literals:mt,numeral:bt,index:v=>String(gt.get(v))}}function Z(o,t,e){return o.replaceAll?o.replaceAll(t,e):o.split(t).join(e)}function Be(o){return o.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const Y=["",()=>{}];class xr extends fo{constructor(){super(...arguments),this.start=Y,this.streamInside=Y,this.end=Y,this.streamOutside=Y,this.state="off",this.handleStart=t=>{this.clearStream(),this.callHandler(this.start[1],t),!t.defaultPrevented&&(this.removeListeners(),this.addListeners("on"))},this.handleInside=t=>{this.handleStream(this.streamInside[1],t)},this.handleEnd=t=>{this.clearStream(),this.callHandler(this.end[1],t),this.removeListeners(),this.addListeners("off")},this.handleOutside=t=>{this.handleStream(this.streamOutside[1],t)}}render(t){return z}update(t,[{start:e,end:r,streamInside:i=Y,streamOutside:s=Y}]){var a;this.element!==t.element&&(this.element=t.element,this.removeListeners()),this.host=((a=t.options)==null?void 0:a.host)||this.element,this.start=e,this.end=r,this.streamInside=i,this.streamOutside=s,this.addListeners()}addListeners(t){this.state=t||this.state,this.state==="off"?(this.addListener(this.streamOutside[0],this.handleOutside),this.addListener(this.start[0],this.handleStart)):this.state==="on"&&(this.addListener(this.streamInside[0],this.handleInside),this.addListener(this.end[0],this.handleEnd))}callHandler(t,e){typeof t=="function"?t.call(this.host,e):t.handleEvent(e)}handleStream(t,e){this.stream||(this.callHandler(t,e),this.stream=requestAnimationFrame(()=>{this.stream=void 0}))}clearStream(){this.stream!=null&&(cancelAnimationFrame(this.stream),this.stream=void 0)}addListener(t,e){Array.isArray(t)?t.map(r=>{this.element.addEventListener(r,e)}):this.element.addEventListener(t,e)}removeListener(t,e){Array.isArray(t)?t.map(r=>{this.element.removeEventListener(r,e)}):this.element.removeEventListener(t,e)}removeListeners(){this.removeListener(this.start[0],this.handleStart),this.removeListener(this.streamInside[0],this.handleInside),this.removeListener(this.end[0],this.handleEnd),this.removeListener(this.streamOutside[0],this.handleOutside)}disconnected(){this.removeListeners()}reconnected(){this.addListeners()}}const kr=ro(xr),Ue=Symbol("language resolver updated");class $r{constructor(t){this.language=document.documentElement.lang||navigator.language||"en-US",this.host=t,this.host.addController(this)}hostConnected(){this.resolveLanguage()}hostDisconnected(){var t;(t=this.unsubscribe)==null||t.call(this)}resolveLanguage(){try{Intl.DateTimeFormat.supportedLocalesOf([this.language])}catch{this.language="en-US"}const t=new CustomEvent("sp-language-context",{bubbles:!0,composed:!0,detail:{callback:(e,r)=>{const i=this.language;this.language=e,this.unsubscribe=r,this.host.requestUpdate(Ue,i)}},cancelable:!0});this.host.dispatchEvent(t)}}const Cr=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron200"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="M9.034 5.356 4.343.663a.911.911 0 0 0-1.29 1.289L7.102 6l-4.047 4.047a.911.911 0 1 0 1.289 1.29l4.691-4.692a.91.91 0 0 0 0-1.29z"
    />
  </svg>`,zr=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron200"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 12 12"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="M9.034 5.356 4.343.663a.911.911 0 0 0-1.29 1.289L7.102 6l-4.047 4.047a.911.911 0 1 0 1.289 1.29l4.691-4.692a.91.91 0 0 0 0-1.29z"
    />
  </svg>`;class Sr extends T{render(){return H(n),this.spectrumVersion===2?Cr({hidden:!this.label,title:this.label}):zr({hidden:!this.label,title:this.label})}}x("sp-icon-chevron200",Sr);const Pr=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron50"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="M1.985 5.961a.695.695 0 0 1-.7-.704.7.7 0 0 1 .209-.493L3.279 3 1.51 1.251A.7.7 0 0 1 1.3.757.696.696 0 0 1 2.492.255l2.275 2.247a.7.7 0 0 1 0 .996L2.477 5.76a.7.7 0 0 1-.492.201"
    />
  </svg>`,Dr=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron50"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="M1.985 5.961a.695.695 0 0 1-.7-.704.7.7 0 0 1 .209-.493L3.279 3 1.51 1.251A.7.7 0 0 1 1.3.757.696.696 0 0 1 2.492.255l2.275 2.247a.7.7 0 0 1 0 .996L2.477 5.76a.7.7 0 0 1-.492.201"
    />
  </svg>`;class Ir extends T{render(){return H(n),this.spectrumVersion===2?Pr({hidden:!this.label,title:this.label}):Dr({hidden:!this.label,title:this.label})}}x("sp-icon-chevron50",Ir);const Br=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron75"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 10 10"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.482 4.406-.001-.001L3.86.783a.84.84 0 0 0-1.188 1.188L5.702 5l-3.03 3.03A.84.84 0 0 0 3.86 9.216l3.621-3.622h.001a.84.84 0 0 0 0-1.19z"
    />
  </svg>`,Ar=({width:o=24,height:t=24,hidden:e=!1,title:r="Chevron75"}={})=>S`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 10 10"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
    width="${o}"
    height="${t}"
  >
    <path
      d="m7.482 4.406-.001-.001L3.86.783a.84.84 0 0 0-1.188 1.188L5.702 5l-3.03 3.03A.84.84 0 0 0 3.86 9.216l3.621-3.622h.001a.84.84 0 0 0 0-1.19z"
    />
  </svg>`;class Er extends T{render(){return H(n),this.spectrumVersion===2?Br({hidden:!this.label,title:this.label}):Ar({hidden:!this.label,title:this.label})}}x("sp-icon-chevron75",Er);const Tr=k`
    :host{--spectrum-infield-button-height:var(--spectrum-component-height-100);--spectrum-infield-button-width:var(--spectrum-component-height-100);--spectrum-infield-button-stacked-border-radius-reset:var(--spectrum-in-field-button-fill-stacked-inner-border-rounding);--spectrum-infield-button-edge-to-fill:var(--spectrum-in-field-button-edge-to-fill);--spectrum-infield-button-inner-edge-to-fill:var(--spectrum-in-field-button-stacked-inner-edge-to-fill);--spectrum-infield-button-fill-padding:0px;--spectrum-infield-button-stacked-fill-padding-inline:var(--spectrum-in-field-button-edge-to-disclosure-icon-stacked-medium);--spectrum-infield-button-stacked-fill-padding-outer:var(--spectrum-in-field-button-outer-edge-to-disclosure-icon-stacked-medium);--spectrum-infield-button-stacked-fill-padding-inner:var(--spectrum-in-field-button-inner-edge-to-disclosure-icon-stacked-medium);--spectrum-infield-button-icon-color:var(--spectrum-neutral-content-color-default);--spectrum-infield-button-icon-color-hover:var(--spectrum-neutral-content-color-hover);--spectrum-infield-button-icon-color-down:var(--spectrum-neutral-content-color-down);--spectrum-infield-button-icon-color-key-focus:var(--spectrum-neutral-content-color-key-focus);--spectrum-infield-button-fill-justify-content:center}:host([disabled]){--mod-infield-button-background-color:var(--mod-infield-button-background-color-disabled,var(--spectrum-disabled-background-color));--mod-infield-button-background-color-hover:var(--mod-infield-button-background-color-hover-disabled,var(--spectrum-disabled-background-color));--mod-infield-button-background-color-down:var(--mod-infield-button-background-color-down-disabled,var(--spectrum-disabled-background-color));--mod-infield-button-border-color:var(--mod-infield-button-border-color-disabled,var(--spectrum-infield-button-border-color));--mod-infield-button-icon-color:var(--mod-infield-button-icon-color-disabled,var(--spectrum-disabled-content-color));--mod-infield-button-icon-color-hover:var(--mod-infield-button-icon-color-hover-disabled,var(--spectrum-disabled-content-color));--mod-infield-button-icon-color-down:var(--mod-infield-button-icon-color-down-disabled,var(--spectrum-disabled-content-color));--mod-infield-button-icon-color-key-focus:var(--mod-infield-button-icon-color-key-focus-disabled,var(--spectrum-disabled-content-color))}:host([size=s]){--spectrum-infield-button-height:var(--spectrum-component-height-75);--spectrum-infield-button-width:var(--spectrum-component-height-75);--spectrum-infield-button-stacked-fill-padding-inline:var(--spectrum-in-field-button-edge-to-disclosure-icon-stacked-small);--spectrum-infield-button-stacked-fill-padding-outer:var(--spectrum-in-field-button-outer-edge-to-disclosure-icon-stacked-small);--spectrum-infield-button-stacked-fill-padding-inner:var(--spectrum-in-field-button-inner-edge-to-disclosure-icon-stacked-small)}:host([size=l]){--spectrum-infield-button-height:var(--spectrum-component-height-200);--spectrum-infield-button-width:var(--spectrum-component-height-200);--spectrum-infield-button-stacked-fill-padding-inline:var(--spectrum-in-field-button-edge-to-disclosure-icon-stacked-large);--spectrum-infield-button-stacked-fill-padding-outer:var(--spectrum-in-field-button-outer-edge-to-disclosure-icon-stacked-large);--spectrum-infield-button-stacked-fill-padding-inner:var(--spectrum-in-field-button-inner-edge-to-disclosure-icon-stacked-large)}:host([size=xl]){--spectrum-infield-button-height:var(--spectrum-component-height-300);--spectrum-infield-button-width:var(--spectrum-component-height-300);--spectrum-infield-button-stacked-fill-padding-inline:var(--spectrum-in-field-button-edge-to-disclosure-icon-stacked-extra-large);--spectrum-infield-button-stacked-fill-padding-outer:var(--spectrum-in-field-button-outer-edge-to-disclosure-icon-stacked-extra-large);--spectrum-infield-button-stacked-fill-padding-inner:var(--spectrum-in-field-button-inner-edge-to-disclosure-icon-stacked-extra-large)}:host([block=end]),:host([block=start]){--mod-infield-button-width:var(--mod-infield-button-width-stacked,var(--spectrum-in-field-button-width-stacked-medium))}:host([block=end][size=s]),:host([block=start][size=s]){--mod-infield-button-width:var(--mod-infield-button-width-stacked,var(--spectrum-in-field-button-width-stacked-small))}:host([block=end][size=l]),:host([block=start][size=l]){--mod-infield-button-width:var(--mod-infield-button-width-stacked,var(--spectrum-in-field-button-width-stacked-large))}:host([block=end][size=xl]),:host([block=start][size=xl]){--mod-infield-button-width:var(--mod-infield-button-width-stacked,var(--spectrum-in-field-button-width-stacked-extra-large))}:host([quiet]){--mod-infield-button-background-color:var(--mod-infield-button-background-color-quiet,transparent);--mod-infield-button-background-color-hover:var(--mod-infield-button-background-color-hover-quiet,transparent);--mod-infield-button-background-color-down:var(--mod-infield-button-background-color-down-quiet,transparent);--mod-infield-button-background-color-key-focus:var(--mod-infield-button-background-color-key-focus-quiet,transparent);--mod-infield-border-color:var(--mod-infield-border-color-quiet,transparent);--mod-infield-button-border-width:var(--mod-infield-button-border-width-quiet,0)}:host([quiet][disabled]){--mod-infield-button-background-color:var(--mod-infield-button-background-color-quiet-disabled,transparent);--mod-infield-button-border-color:var(--mod-infield-button-border-color-quiet-disabled,transparent)}@media (hover:hover){:host(:hover){--mod-infield-button-background-color:var(--mod-infield-button-background-color-hover,var(--spectrum-infield-button-background-color-hover));--mod-infield-button-icon-color:var(--mod-infield-button-icon-color-hover,var(--spectrum-infield-button-icon-color-hover))}}:host(:is(:active,[active])){--mod-infield-button-background-color:var(--mod-infield-button-background-color-down,var(--spectrum-infield-button-background-color-down));--mod-infield-button-icon-color:var(--mod-infield-button-icon-color-down,var(--spectrum-infield-button-icon-color-down))}:host(:focus-visible){--mod-infield-button-background-color:var(--mod-infield-button-background-color-key-focus,var(--spectrum-infield-button-background-color-key-focus));--mod-infield-button-icon-color:var(--mod-infield-button-icon-color-key-focus,var(--spectrum-infield-button-icon-color-key-focus))}@media (forced-colors:active){:host{--highcontrast-infield-button-border-color:ButtonText;--highcontrast-infield-button-border-color-active:Highlight}:host([disabled]){--highcontrast-infield-button-border-color:inherit}:host(:is(:active,[active])):not(:disabled),:host:not(:disabled):focus-visible{--highcontrast-infield-button-border-color:var(--highcontrast-infield-button-border-color-active)}@media (hover:hover){:host:not(:disabled):hover{--highcontrast-infield-button-border-color:var(--highcontrast-infield-button-border-color-active)}}}:host{background-color:initial;cursor:pointer;block-size:var(--mod-infield-button-height,var(--spectrum-infield-button-height));inline-size:var(--mod-infield-button-width,var(--spectrum-infield-button-width));padding:var(--mod-infield-button-edge-to-fill,var(--spectrum-infield-button-edge-to-fill));border-style:none;justify-content:center;align-items:center;display:flex}:host([disabled]){cursor:auto}:host(:focus-visible){outline:none}:host([block=end]),:host([block=start]){block-size:calc(var(--mod-infield-button-height,var(--spectrum-infield-button-height))/2)}:host([block=start]){padding-block-end:var(--mod-infield-button-inner-edge-to-fill,var(--spectrum-infield-button-inner-edge-to-fill))}:host([block=end]){padding-block-start:var(--mod-infield-button-inner-edge-to-fill,var(--spectrum-infield-button-inner-edge-to-fill))}.fill{background-color:var(--mod-infield-button-background-color,var(--spectrum-infield-button-background-color));border-width:var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width));border-style:solid;border-color:var(--highcontrast-infield-button-border-color,var(--mod-infield-button-border-color,var(--spectrum-infield-button-border-color)));block-size:100%;inline-size:100%;padding:var(--mod-infield-button-fill-padding,var(--spectrum-infield-button-fill-padding));align-items:center;justify-content:var(--mod-infield-button-fill-justify-content,var(--spectrum-infield-button-fill-justify-content));transition:border-color var(--spectrum-animation-duration-100)ease-in-out;border-start-start-radius:var(--mod-infield-button-border-radius,var(--spectrum-infield-button-border-radius));border-start-end-radius:var(--mod-infield-button-border-radius,var(--spectrum-infield-button-border-radius));border-end-end-radius:var(--mod-infield-button-border-radius,var(--spectrum-infield-button-border-radius));border-end-start-radius:var(--mod-infield-button-border-radius,var(--spectrum-infield-button-border-radius));display:flex}:host([inline=end]) .fill{border-start-start-radius:var(--mod-infield-button-border-radius-reset,var(--spectrum-infield-button-border-radius-reset));border-end-start-radius:var(--mod-infield-button-border-radius-reset,var(--spectrum-infield-button-border-radius-reset))}:host([inline=start]) .fill{border-start-end-radius:var(--mod-infield-button-border-radius-reset,var(--spectrum-infield-button-border-radius-reset));border-end-end-radius:var(--mod-infield-button-border-radius-reset,var(--spectrum-infield-button-border-radius-reset))}:host([block=end]) .fill,:host([block=start]) .fill{box-sizing:border-box;padding-inline-start:calc(var(--mod-infield-button-stacked-fill-padding-inline,var(--spectrum-infield-button-stacked-fill-padding-inline)) - var(--mod-infield-button-edge-to-fill,var(--spectrum-infield-button-edge-to-fill)) - var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)));padding-inline-end:calc(var(--mod-infield-button-stacked-fill-padding-inline,var(--spectrum-infield-button-stacked-fill-padding-inline)) - var(--mod-infield-button-edge-to-fill,var(--spectrum-infield-button-edge-to-fill)) - var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)))}:host([block=start]) .fill{border-block-end:none;border-start-start-radius:var(--mod-infield-button-stacked-top-border-radius-start-start,var(--spectrum-infield-button-stacked-top-border-radius-start-start));border-end-end-radius:var(--mod-infield-button-stacked-border-radius-reset,var(--spectrum-infield-button-stacked-border-radius-reset));border-end-start-radius:var(--mod-infield-button-stacked-border-radius-reset,var(--spectrum-infield-button-stacked-border-radius-reset));padding-block-start:calc(var(--mod-infield-button-stacked-fill-padding-outer,var(--spectrum-infield-button-stacked-fill-padding-outer)) - var(--mod-infield-button-edge-to-fill,var(--spectrum-infield-button-edge-to-fill)) - var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)));padding-block-end:calc(var(--mod-infield-button-stacked-fill-padding-inner,var(--spectrum-infield-button-stacked-fill-padding-inner)) - var(--mod-infield-button-inner-edge-to-fill,var(--spectrum-infield-button-inner-edge-to-fill)))}:host([block=end]) .fill{border-block-end-width:var(--mod-infield-button-stacked-bottom-border-block-end-width,var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)));border-start-start-radius:var(--mod-infield-button-stacked-border-radius-reset,var(--spectrum-infield-button-stacked-border-radius-reset));border-start-end-radius:var(--mod-infield-button-stacked-border-radius-reset,var(--spectrum-infield-button-stacked-border-radius-reset));border-end-end-radius:var(--mod-infield-button-stacked-bottom-border-radius-end-end,var(--mod-infield-button-border-radius,var(--spectrum-infield-button-border-radius)));border-end-start-radius:var(--mod-infield-button-stacked-bottom-border-radius-end-start,var(--spectrum-infield-button-stacked-bottom-border-radius-end-start));padding-block-start:calc(var(--mod-infield-button-stacked-fill-padding-inner,var(--spectrum-infield-button-stacked-fill-padding-inner)) - var(--mod-infield-button-edge-to-fill,var(--spectrum-infield-button-edge-to-fill)) - var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)));padding-block-end:calc(var(--mod-infield-button-stacked-fill-padding-outer,var(--spectrum-infield-button-stacked-fill-padding-outer)) - var(--mod-infield-button-inner-edge-to-fill,var(--spectrum-infield-button-inner-edge-to-fill)) - var(--mod-infield-button-border-width,var(--spectrum-infield-button-border-width)))}::slotted(*){display:initial;color:var(--mod-infield-button-icon-color,var(--spectrum-infield-button-icon-color));flex-shrink:0;margin:0!important}:host{--spectrum-infield-button-border-width:var(--system-infield-button-border-width);--spectrum-infield-button-border-color:var(--system-infield-button-border-color);--spectrum-infield-button-border-radius:var(--system-infield-button-border-radius);--spectrum-infield-button-border-radius-reset:var(--system-infield-button-border-radius-reset);--spectrum-infield-button-stacked-top-border-radius-start-start:var(--system-infield-button-stacked-top-border-radius-start-start);--spectrum-infield-button-stacked-bottom-border-radius-end-start:var(--system-infield-button-stacked-bottom-border-radius-end-start);--spectrum-infield-button-background-color:var(--system-infield-button-background-color);--spectrum-infield-button-background-color-hover:var(--system-infield-button-background-color-hover);--spectrum-infield-button-background-color-down:var(--system-infield-button-background-color-down);--spectrum-infield-button-background-color-key-focus:var(--system-infield-button-background-color-key-focus)}:host([disabled]){--spectrum-infield-button-border-color:var(--system-infield-button-disabled-border-color)}:host{box-sizing:border-box;user-select:none}::slotted(*){--spectrum-icon-size:inherit}
`;var Mr=Object.defineProperty,Rt=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Mr(t,e,i),i};class $t extends K(Re,{noDefaultSize:!0,validSizes:["s","m","l","xl"]}){constructor(){super(...arguments),this.quiet=!1}static get styles(){return[...super.styles,Tr]}get buttonContent(){return[n`
            <div class="fill">
                <slot></slot>
            </div>
        `]}}Rt([l()],$t.prototype,"block"),Rt([l()],$t.prototype,"inline"),Rt([l({type:Boolean,reflect:!0})],$t.prototype,"quiet");customElements.define("sp-infield-button",$t);const Nr=k`
    @media (forced-colors:active){:host{--highcontrast-stepper-border-color:CanvasText;--highcontrast-stepper-border-color-hover:Highlight;--highcontrast-stepper-border-color-focus:Highlight;--highcontrast-stepper-border-color-focus-hover:Highlight;--highcontrast-stepper-border-color-keyboard-focus:CanvasText;--highcontrast-stepper-focus-indicator-color:Highlight}:host([invalid]) #textfield{--highcontrast-stepper-border-color:Highlight;--highcontrast-stepper-border-color-hover:Highlight;--highcontrast-stepper-border-color-focus:Highlight;--highcontrast-stepper-border-color-focus-hover:Highlight;--highcontrast-stepper-border-color-keyboard-focus:Highlight}:host([disabled]) #textfield{--highcontrast-stepper-border-color:GrayText;--highcontrast-stepper-buttons-border-width:var(--mod-stepper-border-width,var(--spectrum-stepper-border-width))}:host([focused]:not([disabled])) #textfield,:host(:not([disabled])) #textfield:focus{--highcontrast-stepper-border-color:var(--highcontrast-stepper-border-color-focus)}@media (hover:hover){:host(:not([disabled]):hover) #textfield{--highcontrast-stepper-border-color:var(--highcontrast-stepper-border-color-hover)}:host([focused]:not([disabled]):hover) #textfield,:host(:not([disabled]):hover) #textfield:focus{--highcontrast-stepper-border-color:var(--highcontrast-stepper-border-color-focus-hover)}}:host([keyboard-focused]:not([disabled])) #textfield,:host(:not([disabled])) #textfield:focus-visible{--highcontrast-stepper-border-color:var(--highcontrast-stepper-border-color-keyboard-focus)}.input{--highcontrast-textfield-border-color:var(--highcontrast-stepper-border-color)}.button{--highcontrast-infield-button-border-color:var(--highcontrast-stepper-border-color);--highcontrast-infield-button-border-color-active:var(--highcontrast-stepper-border-color)}}:host{--spectrum-stepper-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color,var(--spectrum-stepper-border-color-default)));--spectrum-stepper-border-radius:var(--mod-stepper-border-radius,var(--spectrum-corner-radius-100));--spectrum-stepper-focus-indicator-width:var(--mod-stepper-focus-indicator-width,var(--spectrum-focus-indicator-thickness));--spectrum-stepper-focus-indicator-gap:var(--mod-stepper-focus-indicator-gap,var(--spectrum-focus-indicator-gap));--spectrum-stepper-focus-indicator-color:var(--highcontrast-stepper-focus-indicator-color,var(--mod-stepper-focus-indicator-color,var(--spectrum-focus-indicator-color)));--spectrum-stepper-animation-duration:var(--mod-stepper-animation-duration,var(--spectrum-animation-duration-100))}#textfield,:host([size=m]) #textfield{--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-medium));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-100))}:host([size=s]) #textfield{--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-small));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-75))}:host([size=l]) #textfield{--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-large));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-200))}:host([size=xl]) #textfield{--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-extra-large));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-300))}:host([disabled]) #textfield{--spectrum-stepper-buttons-border-width:var(--spectrum-stepper-button-border-width-disabled);--spectrum-stepper-buttons-background-color:var(--spectrum-stepper-buttons-background-color-disabled)}:host([invalid]) #textfield{--mod-stepper-border-color:var(--mod-stepper-border-color-invalid,var(--spectrum-negative-border-color-default));--mod-stepper-border-color-hover:var(--mod-stepper-border-color-hover-invalid,var(--spectrum-negative-border-color-hover));--mod-stepper-border-color-focus:var(--mod-stepper-border-color-focus-invalid,var(--spectrum-negative-border-color-focus));--mod-stepper-border-color-focus-hover:var(--mod-stepper-border-color-focus-hover-invalid,var(--spectrum-negative-border-color-focus-hover));--mod-stepper-border-color-keyboard-focus:var(--mod-stepper-border-color-keyboard-focus-invalid,var(--spectrum-negative-border-color-key-focus))}:host([focused]:not([disabled])) #textfield,:host(:not([disabled])) #textfield:focus{--mod-stepper-border-color:var(--highcontrast-stepper-border-color-focus,var(--mod-stepper-border-color-focus,var(--spectrum-stepper-border-color-focus)));--mod-stepper-buttons-border-color:var(--highcontrast-stepper-border-color-focus,var(--mod-stepper-border-color-focus,var(--spectrum-stepper-border-color-focus)))}:host([keyboard-focused]:not([disabled])) #textfield{--mod-stepper-border-color:var(--highcontrast-stepper-border-color-focus,var(--mod-stepper-border-color-focus,var(--spectrum-stepper-border-color-keyboard-focus)))}:host([quiet]) #textfield{--mod-stepper-buttons-background-color:transparent}:host([quiet][keyboard-focused]:not([disabled])) #textfield{--mod-stepper-focus-indicator-visibility:visible}:host([quiet][invalid]) #textfield{--mod-stepper-border-color:var(--mod-stepper-border-color-invalid,var(--spectrum-negative-border-color-default))}:host{--mod-infield-button-border-color:var(--mod-stepper-buttons-border-color,var(--spectrum-stepper-buttons-border-color));--mod-infield-button-border-color-quiet-disabled:var(--spectrum-disabled-border-color);--mod-infield-button-border-width:var(--mod-stepper-button-border-width,var(--spectrum-stepper-button-border-width));--mod-textfield-border-width:var(--mod-stepper-border-width,var(--spectrum-stepper-border-width));--mod-textfield-border-color:var(--spectrum-stepper-border-color)}#textfield:not(.spectrum-Stepper--quiet){--mod-textfield-border-color-disabled:var(--spectrum-stepper-border-color-disabled)}:host(:not([disabled])[focused]) #textfield,:host(:not([disabled])) #textfield:focus{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color-focus,var(--mod-stepper-buttons-border-color-focus,var(--spectrum-stepper-buttons-border-color-focus)));--mod-textfield-focus-indicator-width:0}:host([keyboard-focused]:not([disabled])) #textfield,:host(:not([disabled])) #textfield:focus-visible{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color-keyboard-focus,var(--mod-stepper-buttons-border-color-keyboard-focus,var(--spectrum-stepper-buttons-border-color-keyboard-focus)));--mod-textfield-focus-indicator-width:0;--mod-textfield-border-color:var(--highcontrast-stepper-border-color-keyboard-focus,var(--mod-stepper-border-color-keyboard-focus,var(--spectrum-stepper-border-color-keyboard-focus)));outline:var(--spectrum-stepper-focus-indicator-width)solid;outline-color:var(--spectrum-stepper-focus-indicator-color);outline-offset:var(--spectrum-stepper-focus-indicator-gap)}:host([invalid]) #textfield{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-invalid,var(--spectrum-stepper-border-color-invalid)));--mod-textfield-icon-spacing-inline-start-invalid:0}:host([invalid][focused]) #textfield,:host([invalid]) #textfield:focus{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-focus-invalid,var(--spectrum-stepper-border-color-focus-invalid)))}:host([invalid][keyboard-focused]) #textfield,:host([invalid]) #textfield:focus-visible{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-keyboard-focus-invalid,var(--spectrum-stepper-border-color-keyboard-focus-invalid)))}:host([quiet]) #textfield{--mod-infield-button-width-stacked:var(--mod-stepper-button-width-quiet,var(--spectrum-stepper-button-width));--mod-infield-button-border-color:var(--spectrum-stepper-border-color);--mod-infield-button-border-color-quiet:var(--spectrum-stepper-border-color);--mod-infield-button-border-block-end-width:var(--mod-stepper-border-width,var(--spectrum-stepper-border-width));--mod-infield-button-stacked-bottom-border-block-end-width:var(--mod-stepper-border-width,var(--spectrum-stepper-border-width));--mod-infield-button-stacked-bottom-border-radius-end-end:0;--mod-infield-button-stacked-bottom-border-radius-end-start:0;--mod-infield-button-fill-justify-content:flex-end;--mod-infield-button-inner-edge-to-fill:var(--spectrum-stepper-button-edge-to-fill);--mod-infield-button-edge-to-fill:var(--spectrum-stepper-button-edge-to-fill);--mod-textfield-focus-indicator-color:transparent;--mod-textfield-background-color:transparent;--mod-textfield-border-color-hover:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-hover,var(--spectrum-stepper-border-color-hover)))}:host([quiet][focused]:not([disabled])) #textfield,:host([quiet]:not([disabled])) #textfield:focus{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-focus,var(--spectrum-stepper-border-color-focus)))}:host([quiet][keyboard-focused]:not([disabled])) #textfield{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-keyboard-focus,var(--spectrum-stepper-border-color-keyboard-focus)))}@media (hover:hover){:host(:not([disabled]):hover) #textfield{--mod-stepper-border-color:var(--highcontrast-stepper-border-color-hover,var(--mod-stepper-border-color-hover,var(--spectrum-stepper-border-color-hover)))}:host([focused]:not([disabled]):hover) #textfield,:host(:not([disabled]):hover) #textfield:focus{--mod-stepper-border-color:var(--highcontrast-stepper-border-color-focus-hover,var(--mod-stepper-border-color-focus-hover,var(--spectrum-stepper-border-color-focus-hover)));--mod-stepper-buttons-border-color:var(--highcontrast-stepper-border-color-focus-hover,var(--mod-stepper-border-color-focus-hover,var(--spectrum-stepper-border-color-focus-hover)))}:host([quiet]:not([disabled]):hover) #textfield{--mod-stepper-buttons-background-color:transparent}:host(:hover) #textfield:not(.is-invalid,.is-disabled,.is-focused){--mod-infield-button-border-color:var(--mod-stepper-buttons-border-color-hover,var(--spectrum-stepper-buttons-border-color-hover))}:host(:not([disabled])[focused]:hover) #textfield,:host(:not([disabled]):hover) #textfield:focus{--mod-infield-button-border-color:var(--mod-stepper-buttons-border-color-focus-hover,var(--spectrum-stepper-buttons-border-color-focus-hover));--mod-textfield-focus-indicator-width:0;--mod-textfield-border-color:var(--highcontrast-stepper-border-color-focus-hover,var(--mod-stepper-border-color-focus-hover,var(--spectrum-stepper-border-color-focus-hover)))}:host([invalid]:hover) #textfield{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-hover-invalid,var(--spectrum-negative-border-color-hover)))}:host([invalid][focused]:hover) #textfield,:host([invalid]:hover) #textfield:focus{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-focus-hover-invalid,var(--spectrum-stepper-border-color-focus-hover-invalid)))}:host([quiet]:not([disabled]):hover) #textfield{--mod-textfield-border-color-hover:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-hover,var(--spectrum-stepper-border-color-hover)));--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-hover,var(--spectrum-stepper-border-color-hover)))}:host([quiet][focused]:not([disabled]):hover) #textfield,:host([quiet]:not([disabled]):hover) #textfield:focus{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-focus-hover,var(--spectrum-stepper-border-color-focus-hover)))}:host([quiet][keyboard-focused]:not([disabled]):hover) #textfield{--mod-infield-button-border-color:var(--highcontrast-stepper-border-color,var(--mod-stepper-border-color-hover,var(--spectrum-stepper-border-color-hover)))}}#textfield{--spectrum-stepper-width:var(--mod-stepper-width,calc(var(--spectrum-stepper-height)*var(--mod-stepper-min-width-multiplier,var(--spectrum-text-field-minimum-width-multiplier)) + var(--spectrum-stepper-button-width) + var(--mod-stepper-border-width,var(--spectrum-stepper-border-width))*2));inline-size:var(--spectrum-stepper-width);block-size:var(--spectrum-stepper-height);border-radius:var(--spectrum-stepper-border-radius);flex-flow:row;display:inline-flex;position:relative}#textfield:before{content:""}.input{border-inline-end-width:0;border-start-end-radius:0;border-end-end-radius:0}.buttons{box-sizing:border-box;block-size:var(--spectrum-stepper-height);inline-size:var(--spectrum-stepper-button-width);border-color:var(--spectrum-stepper-border-color);border-style:var(--mod-stepper-buttons-border-style,var(--spectrum-stepper-buttons-border-style));border-width:var(--highcontrast-stepper-buttons-border-width,var(--mod-stepper-buttons-border-width,var(--spectrum-stepper-buttons-border-width)));background-color:var(--mod-stepper-buttons-background-color,var(--spectrum-stepper-buttons-background-color));transition:border-color var(--spectrum-stepper-animation-duration)ease-in-out;border-inline-start-width:0;flex-direction:column;justify-content:center;display:flex}.buttons,#textfield.hide-stepper .input{border-start-end-radius:var(--spectrum-stepper-border-radius);border-end-end-radius:var(--spectrum-stepper-border-radius)}#textfield.hide-stepper .input{border-inline-end-width:var(--mod-stepper-border-width,var(--spectrum-stepper-border-width))}:host([quiet]) #textfield{border-start-start-radius:0;border-start-end-radius:0;border-end-end-radius:0;border-end-start-radius:0}:host([quiet]) .hide-stepper .input{border-inline-end-width:0;border-end-end-radius:0}:host([quiet]):after{visibility:hidden;visibility:var(--mod-stepper-focus-indicator-visibility,hidden);content:"";inline-size:100%;block-size:var(--spectrum-stepper-focus-indicator-width);background-color:var(--spectrum-stepper-focus-indicator-color);position:absolute;inset-block-end:calc((var(--spectrum-stepper-focus-indicator-gap) + var(--spectrum-stepper-focus-indicator-width))*-1);inset-inline-start:0}:host([quiet][keyboard-focused]:not([disabled])){outline:none}:host{--spectrum-stepper-border-width:var(--system-stepper-border-width);--spectrum-stepper-border-color-default:var(--system-stepper-border-color-default);--spectrum-stepper-border-color-hover:var(--system-stepper-border-color-hover);--spectrum-stepper-border-color-focus:var(--system-stepper-border-color-focus);--spectrum-stepper-border-color-focus-hover:var(--system-stepper-border-color-focus-hover);--spectrum-stepper-border-color-keyboard-focus:var(--system-stepper-border-color-keyboard-focus);--spectrum-stepper-buttons-border-style:var(--system-stepper-buttons-border-style);--spectrum-stepper-buttons-border-width:var(--system-stepper-buttons-border-width);--spectrum-stepper-buttons-border-color:var(--system-stepper-buttons-border-color);--spectrum-stepper-buttons-background-color:var(--system-stepper-buttons-background-color);--spectrum-stepper-buttons-border-color-hover:var(--system-stepper-buttons-border-color-hover);--spectrum-stepper-buttons-border-color-focus:var(--system-stepper-buttons-border-color-focus);--spectrum-stepper-buttons-border-color-keyboard-focus:var(--system-stepper-buttons-border-color-keyboard-focus);--spectrum-stepper-button-border-width:var(--system-stepper-button-border-width);--spectrum-stepper-border-color-invalid:var(--system-stepper-border-color-invalid);--spectrum-stepper-border-color-focus-invalid:var(--system-stepper-border-color-focus-invalid);--spectrum-stepper-border-color-focus-hover-invalid:var(--system-stepper-border-color-focus-hover-invalid);--spectrum-stepper-border-color-keyboard-focus-invalid:var(--system-stepper-border-color-keyboard-focus-invalid);--spectrum-stepper-border-color-disabled:var(--system-stepper-border-color-disabled);--spectrum-stepper-button-border-width-disabled:var(--system-stepper-button-border-width-disabled);--spectrum-stepper-buttons-background-color-disabled:var(--system-stepper-buttons-background-color-disabled)}:host([quiet]) #textfield{--spectrum-stepper-buttons-border-style:var(--system-stepper-quiet-buttons-border-style);--spectrum-stepper-button-edge-to-fill:var(--system-stepper-quiet-button-edge-to-fill)}:host,:host([size=m]){--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-medium));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-100))}:host([size=s]){--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-small));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-75))}:host([size=l]){--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-large));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-200))}:host([size=xl]){--spectrum-stepper-button-width:var(--mod-stepper-button-width,var(--spectrum-in-field-button-width-stacked-extra-large));--spectrum-stepper-height:var(--mod-stepper-height,var(--spectrum-component-height-300))}:host{--spectrum-stepper-width:calc(var(--mod-stepper-height,var(--spectrum-stepper-height))*var(--mod-stepper-min-width-multiplier,var(--spectrum-text-field-minimum-width-multiplier)) + var(--mod-stepper-button-width,var(--spectrum-stepper-button-width))*2 + var(--mod-stepper-border-width,var(--spectrum-stepper-border-width))*2);inline-size:var(--mod-stepper-width,var(--spectrum-stepper-width))}:host([hide-stepper]){--spectrum-stepper-width:calc(var(--mod-stepper-height,var(--spectrum-stepper-height))*var(--mod-stepper-min-width-multiplier,var(--spectrum-text-field-minimum-width-multiplier)) + var(--mod-stepper-button-width,var(--spectrum-stepper-button-width)) + var(--mod-stepper-border-width,var(--spectrum-stepper-border-width))*2)}#textfield{inline-size:100%}.input{font-variant-numeric:tabular-nums}:host([readonly]) .buttons{pointer-events:none;visibility:hidden}:host([readonly]:not([disabled],[invalid],[focused],[keyboard-focused])) #textfield:hover .input{border-color:#0000}:host([hide-stepper]:not([quiet])) #textfield input{border:var(--mod-textfield-border-width,var(--spectrum-textfield-border-width))solid var(--mod-textfield-border-color,var(--spectrum-textfield-border-color));border-radius:var(--spectrum-textfield-corner-radius)}:host([quiet]) #textfield .button{--mod-infield-button-border-color:var(--mod-infield-border-color-quiet,transparent);--mod-infield-button-edge-to-fill:0;--mod-infield-button-border-width:var(--mod-infield-button-border-width-quiet,0)}:host([focused]:not([disabled])) #textfield:hover{--mod-stepper-buttons-border-color-focus-hover:var(--mod-stepper-border-color-focus-hover,var(--spectrum-stepper-border-color-focus-hover))}:host([invalid]:not([hide-stepper])) #textfield .icon,:host([valid]:not([hide-stepper])) #textfield .icon{inset-inline-end:calc(var(--spectrum-stepper-button-width) + var(--spectrum-textfield-icon-spacing-inline-end-invalid))}:host([invalid]) .input{padding-inline-end:calc(var(--mod-textfield-icon-spacing-inline-start-valid,var(--spectrum-textfield-icon-spacing-inline-start-valid)) + var(--mod-textfield-icon-size-valid,var(--spectrum-textfield-icon-size-valid)) + var(--mod-textfield-icon-spacing-inline-end-valid,var(--spectrum-textfield-icon-spacing-inline-end-valid)) - var(--mod-textfield-border-width,var(--spectrum-textfield-border-width)))}
`;var Fr=Object.defineProperty,Rr=Object.getOwnPropertyDescriptor,A=(o,t,e,r)=>{for(var i=r>1?void 0:r?Rr(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&Fr(t,e,i),i};const Gr=5,_r=100,ft="-",Ae={"１":"1","２":"2","３":"3","４":"4","５":"5","６":"6","７":"7","８":"8","９":"9","０":"0","、":",","，":",","。":".","．":".","％":"%","＋":"+",ー:"-",一:"1",二:"2",三:"3",四:"4",五:"5",六:"6",七:"7",八:"8",九:"9",零:"0"},Ee={s:o=>n`
        <sp-icon-chevron50
            class="stepper-icon spectrum-UIIcon-Chevron${o}50"
        ></sp-icon-chevron50>
    `,m:o=>n`
        <sp-icon-chevron75
            class="stepper-icon spectrum-UIIcon-Chevron${o}75"
        ></sp-icon-chevron75>
    `,l:o=>n`
        <sp-icon-chevron100
            class="stepper-icon spectrum-UIIcon-Chevron${o}100"
        ></sp-icon-chevron100>
    `,xl:o=>n`
        <sp-icon-chevron200
            class="stepper-icon spectrum-UIIcon-Chevron${o}200"
        ></sp-icon-chevron200>
    `};class I extends io{constructor(){super(...arguments),this.focused=!1,this._forcedUnit="",this.formatOptions={},this.hideStepper=!1,this.indeterminate=!1,this.keyboardFocused=!1,this.managedInput=!1,this.stepModifier=10,this._value=NaN,this._trackingValue="",this.decimalsChars=new Set([".",","]),this.valueBeforeFocus="",this.isIntentDecimal=!1,this.changeCount=0,this.languageResolver=new $r(this),this.wasIndeterminate=!1,this.hasRecentlyReceivedPointerDown=!1,this.applyFocusElementLabel=t=>{this.appliedLabel=t},this.isComposing=!1}static get styles(){return[...super.styles,Nr,so]}set value(t){const e=this.validateInput(t);if(e===this.value)return;this.lastCommitedValue=e;const r=this._value;this._value=e,this.requestUpdate("value",r)}get value(){return this._value}get inputValue(){return this.indeterminate?this.formattedValue:this.inputElement.value}setValue(t=this.value){const e=this.lastCommitedValue;this.value=t,!(typeof e>"u"||e===this.value)&&(this.lastCommitedValue=this.value,this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})))}get valueAsString(){return this._value.toString()}set valueAsString(t){this.value=this.numberParser.parse(t)}get formattedValue(){return isNaN(this.value)?"":this.numberFormatter.format(this.value)+(this.focused?"":this._forcedUnit)}convertValueToNumber(t){let e=t.split("").map(s=>Ae[s]||s).join("");const r=this.valueBeforeFocus.split("").filter(s=>this.decimalsChars.has(s)),i=new Set(r);if(xe()&&this.inputElement.inputMode==="decimal"&&e!==this.valueBeforeFocus){const s=this.numberFormatter.formatToParts(1000.1).find(u=>u.type==="decimal").value;for(const u of i)u!==s&&!this.isIntentDecimal&&(e=e.replace(new RegExp(u,"g"),""));let a=!1;const c=e.split("");for(let u=c.length-1;u>=0;u--){const d=c[u];this.decimalsChars.has(d)&&(a?c[u]="":(c[u]=s,a=!0))}e=c.join("")}return this.numberParser.parse(e)}get _step(){var t;return typeof this.step<"u"?this.step:((t=this.formatOptions)==null?void 0:t.style)==="percent"?.01:1}handlePointerdown(t){if(t.button!==0){t.preventDefault();return}this.managedInput=!0,this.buttons.setPointerCapture(t.pointerId);const e=this.buttons.children[0].getBoundingClientRect(),r=this.buttons.children[1].getBoundingClientRect();this.findChange=i=>{i.clientX>=e.x&&i.clientY>=e.y&&i.clientX<=e.x+e.width&&i.clientY<=e.y+e.height?this.change=s=>this.increment(s.shiftKey?this.stepModifier:1):i.clientX>=r.x&&i.clientY>=r.y&&i.clientX<=r.x+r.width&&i.clientY<=r.y+r.height&&(this.change=s=>this.decrement(s.shiftKey?this.stepModifier:1))},this.findChange(t),this.startChange(t)}startChange(t){this.changeCount=0,this.doChange(t),this.safty=setTimeout(()=>{this.doNextChange(t)},400)}doChange(t){this.change(t)}handlePointermove(t){this.findChange(t)}handlePointerup(t){this.buttons.releasePointerCapture(t.pointerId),cancelAnimationFrame(this.nextChange),clearTimeout(this.safty),this.managedInput=!1,this.setValue()}doNextChange(t){return this.changeCount+=1,this.changeCount%Gr===0&&this.doChange(t),requestAnimationFrame(()=>{this.nextChange=this.doNextChange(t)})}stepBy(t){if(this.disabled||this.readonly)return;const e=typeof this.min<"u"?this.min:0;let r=this.value;r+=t*this._step,isNaN(this.value)&&(r=e),r=this.valueWithLimits(r),this.requestUpdate(),this._value=this.validateInput(r),this.inputElement.value=this.numberFormatter.format(r);const i=new Event("input",{bubbles:!0,composed:!0});this.inputElement.readOnly=!0,this.inputElement.dispatchEvent(i),this.indeterminate=!1,this.focus(),this.inputElement.readOnly=!1}increment(t=1){this.stepBy(1*t)}decrement(t=1){this.stepBy(-1*t)}handleKeydown(t){if(!this.isComposing)switch(t.code){case"ArrowUp":t.preventDefault(),this.increment(t.shiftKey?this.stepModifier:1),this.setValue();break;case"ArrowDown":t.preventDefault(),this.decrement(t.shiftKey?this.stepModifier:1),this.setValue();break}}onScroll(t){t.preventDefault(),this.managedInput=!0;const e=t.shiftKey?t.deltaX/Math.abs(t.deltaX):t.deltaY/Math.abs(t.deltaY);e!==0&&!isNaN(e)&&(this.stepBy(e*(t.shiftKey?this.stepModifier:1)),clearTimeout(this.queuedChangeEvent),this.queuedChangeEvent=setTimeout(()=>{this.setValue()},_r)),this.managedInput=!1}onFocus(){super.onFocus(),this._trackingValue=this.inputValue,this.keyboardFocused=!this.readonly&&!0,this.addEventListener("wheel",this.onScroll,{passive:!1}),this.valueBeforeFocus=this.inputElement.value}onBlur(t){super.onBlur(t),this.keyboardFocused=!this.readonly&&!1,this.removeEventListener("wheel",this.onScroll),this.isIntentDecimal=!1}handleFocusin(){this.focused=!this.readonly&&!0,this.keyboardFocused=!this.readonly&&!0}handleFocusout(){this.focused=!this.readonly&&!1,this.keyboardFocused=!this.readonly&&!1}handleChange(){const t=this.convertValueToNumber(this.inputValue);if(this.wasIndeterminate&&(this.wasIndeterminate=!1,this.indeterminateValue=void 0,isNaN(t))){this.indeterminate=!0;return}this.setValue(t),this.inputElement.value=this.formattedValue}handleCompositionStart(){this.isComposing=!0}handleCompositionEnd(){this.isComposing=!1,requestAnimationFrame(()=>{this.inputElement.dispatchEvent(new Event("input",{composed:!0,bubbles:!0}))})}handleInputElementPointerdown(){this.hasRecentlyReceivedPointerDown=!0,this.updateComplete.then(()=>{requestAnimationFrame(()=>{this.hasRecentlyReceivedPointerDown=!1})})}handleInput(t){var e;if(this.isComposing){if(t.data){const d=this.convertValueToNumber(t.data);Number.isNaN(d)&&(this.inputElement.value=this.indeterminate?ft:this._trackingValue,this.isComposing=!1)}t.stopPropagation();return}this.indeterminate&&(this.wasIndeterminate=!0,this.indeterminateValue=this.value,this.inputElement.value=this.inputElement.value.replace(ft,"")),t.data&&this.decimalsChars.has(t.data)&&(this.isIntentDecimal=!0);const{value:r,selectionStart:i}=this.inputElement,s=r.split("").map(d=>Ae[d]||d).join("");if(this.numberParser.isValidPartialNumber(s)){this.lastCommitedValue=(e=this.lastCommitedValue)!=null?e:this.value;const d=this.convertValueToNumber(s);!s&&this.indeterminateValue?(this.indeterminate=!0,this._value=this.indeterminateValue):(this.indeterminate=!1,this._value=this.validateInput(d)),this._trackingValue=s,this.inputElement.value=s,this.inputElement.setSelectionRange(i,i);return}else this.inputElement.value=this.indeterminate?ft:this._trackingValue,t.stopPropagation();const a=s.length,c=this._trackingValue.length,u=(i||a)-(a-c);this.inputElement.setSelectionRange(u,u)}valueWithLimits(t){let e=t;return typeof this.min<"u"&&(e=Math.max(this.min,e)),typeof this.max<"u"&&(e=Math.min(this.max,e)),e}validateInput(t){t=this.valueWithLimits(t);const e=t<0?-1:1;if(t*=e,this.step){const r=typeof this.min<"u"?this.min:0,i=parseFloat(this.valueFormatter.format((t-r)%this.step));if(i===0||(Math.round(i/this.step)===1?t+=this.step-i:t-=i),typeof this.max<"u")for(;t>this.max;)t-=this.step;t=parseFloat(this.valueFormatter.format(t))}return t*=e,t}get displayValue(){const t=this.focused?"":ft;return this.indeterminate?t:this.formattedValue}clearNumberFormatterCache(){this._numberFormatter=void 0,this._numberParser=void 0}get numberFormatter(){if(!this._numberFormatter||!this._numberFormatterFocused){const{style:t,unit:e,unitDisplay:r,...i}=this.formatOptions;t!=="unit"&&(i.style=t),this._numberFormatterFocused=new kt(this.languageResolver.language,i);try{this._numberFormatter=new kt(this.languageResolver.language,this.formatOptions),this._forcedUnit="",this._numberFormatter.format(1)}catch{t==="unit"&&(this._forcedUnit=e),this._numberFormatter=this._numberFormatterFocused}}return this.focused?this._numberFormatterFocused:this._numberFormatter}clearValueFormatterCache(){this._valueFormatter=void 0}get valueFormatter(){if(!this._valueFormatter){const t=this.step&&this.step!=Math.floor(this.step)?this.step.toString().split(".")[1].length:0;this._valueFormatter=new kt("en",{useGrouping:!1,maximumFractionDigits:t})}return this._valueFormatter}get numberParser(){if(!this._numberParser||!this._numberParserFocused){const{style:t,unit:e,unitDisplay:r,...i}=this.formatOptions;t!=="unit"&&(i.style=t),this._numberParserFocused=new Vt(this.languageResolver.language,i);try{this._numberParser=new Vt(this.languageResolver.language,this.formatOptions),this._forcedUnit="",this._numberParser.parse("0")}catch{t==="unit"&&(this._forcedUnit=e),this._numberParser=this._numberParserFocused}}return this.focused?this._numberParserFocused:this._numberParser}renderField(){return this.autocomplete="off",n`
            ${super.renderField()}
            ${this.hideStepper?z:n`
                      <span
                          class="buttons"
                          @focusin=${this.handleFocusin}
                          @focusout=${this.handleFocusout}
                          ${kr({start:["pointerdown",this.handlePointerdown],streamInside:[["pointermove","pointerenter","pointerleave","pointerover","pointerout"],this.handlePointermove],end:[["pointerup","pointercancel","pointerleave"],this.handlePointerup]})}
                      >
                          <sp-infield-button
                              inline="end"
                              block="start"
                              class="button step-up"
                              aria-hidden="true"
                              label=${"Increase "+this.appliedLabel}
                              size=${this.size}
                              tabindex="-1"
                              ?focused=${this.focused}
                              ?disabled=${this.disabled||this.readonly||typeof this.max<"u"&&this.value===this.max}
                              ?quiet=${this.quiet}
                          >
                              ${Ee[this.size]("Up")}
                          </sp-infield-button>
                          <sp-infield-button
                              inline="end"
                              block="end"
                              class="button step-down"
                              aria-hidden="true"
                              label=${"Decrease "+this.appliedLabel}
                              size=${this.size}
                              tabindex="-1"
                              ?focused=${this.focused}
                              ?disabled=${this.disabled||this.readonly||typeof this.min<"u"&&this.value===this.min}
                              ?quiet=${this.quiet}
                          >
                              ${Ee[this.size]("Down")}
                          </sp-infield-button>
                      </span>
                  `}
        `}update(t){if((t.has("formatOptions")||t.has("resolvedLanguage"))&&this.clearNumberFormatterCache(),t.has("value")||t.has("max")||t.has("min")||t.has("step")){const e=this.numberParser.parse(this.formattedValue.replace(this._forcedUnit,""));this.value=e,this.clearValueFormatterCache()}super.update(t)}willUpdate(t){this.multiline=!1,t.has(Ue)&&this.clearNumberFormatterCache()}firstUpdated(t){super.firstUpdated(t),this.addEventListener("keydown",this.handleKeydown),this.addEventListener("compositionstart",this.handleCompositionStart),this.addEventListener("compositionend",this.handleCompositionEnd)}updated(t){if(!(!this.inputElement||!this.isConnected)){if(t.has("min")||t.has("formatOptions")){const e=typeof this.min<"u"&&this.min>=0,{maximumFractionDigits:r}=this.numberFormatter.resolvedOptions(),i=r&&r>0;let s="numeric";ao()&&!e?s="text":(xe()&&i||no()&&i&&e)&&(s="decimal"),this.inputElement.inputMode=s}t.has("focused")&&this.focused&&!this.hasRecentlyReceivedPointerDown&&this.formatOptions.unit&&this.setSelectionRange(0,this.displayValue.length)}}}A([ut(".buttons")],I.prototype,"buttons",2),A([l({type:Boolean,reflect:!0})],I.prototype,"focused",2),A([l({type:Object,attribute:"format-options"})],I.prototype,"formatOptions",2),A([l({type:Boolean,reflect:!0,attribute:"hide-stepper"})],I.prototype,"hideStepper",2),A([l({type:Boolean,reflect:!0})],I.prototype,"indeterminate",2),A([l({type:Boolean,reflect:!0,attribute:"keyboard-focused"})],I.prototype,"keyboardFocused",2),A([l({type:Number})],I.prototype,"max",2),A([l({type:Number})],I.prototype,"min",2),A([l({type:Number})],I.prototype,"step",2),A([l({type:Number,reflect:!0,attribute:"step-modifier"})],I.prototype,"stepModifier",2),A([l({type:Number})],I.prototype,"value",1);x("sp-number-field",I);var Or=Object.defineProperty,q=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Or(t,e,i),i};const jt=class jt extends U{constructor(){super(),this.label="",this.parameterKey="",this.control="yaxis",this.outputLabel="Output",this.config={min:0,max:1,curve:1,spread:"direct",multiplier:1},this.color="#51cf66",this.hoverPosition=null,W.addHost(this)}getHoverPositionFromController(){const t=W.state;switch(this.control){case"yaxis":return t.tabletY;case"pressure":return t.tiltPressed?t.tiltPressure:null;case"tiltX":return t.tiltPressed?(t.tiltX+1)/2:null;case"tiltY":return t.tiltPressed?(t.tiltY+1)/2:null;case"tiltXY":return t.tiltPressed?(t.tiltXY+1)/2:null;default:return null}}handleControlChange(t){const e=t.target;e!=null&&e.value&&this.dispatchEvent(new CustomEvent("control-change",{detail:{parameterKey:this.parameterKey,control:e.value},bubbles:!0,composed:!0}))}handleConfigChange(t,e){this.dispatchEvent(new CustomEvent("config-change",{detail:{[`${this.parameterKey}.${t}`]:e},bubbles:!0,composed:!0}))}calculateOutputValue(t,e){if(t.spread==="central"){const r=Math.abs(e-.5)*2,i=Math.pow(r,t.curve);return t.max-i*(t.max-t.min)}else if(t.spread==="inverse"){const r=Math.pow(e,t.curve);return t.max-r*(t.max-t.min)}else{const r=Math.pow(e,t.curve);return t.min+r*(t.max-t.min)}}generateCurvePath(t,e,r){const i=[];for(let a=0;a<=50;a++){const c=a/50,d=(this.calculateOutputValue(t,c)-t.min)/(t.max-t.min),m=c*e,$=r-d*r;i.push(`${m.toFixed(2)},${$.toFixed(2)}`)}return i.join(" ")}render(){const d=this.generateCurvePath(this.config,124,74),m=this.getHoverPositionFromController(),$=m!==null?this.calculateOutputValue(this.config,m):null;return n`
                    <svg viewBox="0 0 ${200} ${150}" style="width: 100%; height: auto; display: block;">
                        <rect x="${35}" y="${35}"
                              width="${130}" height="${80}"
                              fill="var(--spectrum-gray-100)" stroke="var(--spectrum-gray-300)" stroke-width="1" />

                        <line x1="${35}" y1="${35}"
                              x2="${35}" y2="${115}"
                              stroke="var(--spectrum-gray-600)" stroke-width="1.5" />
                        <line x1="${35}" y1="${115}"
                              x2="${165}" y2="${115}"
                              stroke="var(--spectrum-gray-600)" stroke-width="1.5" />

                        <text x="${27}" y="${119}"
                              font-size="10" fill="var(--spectrum-gray-800)" text-anchor="end">${this.config.min.toFixed(1)}</text>
                        <text x="${27}" y="${39}"
                              font-size="10" fill="var(--spectrum-gray-800)" text-anchor="end">${this.config.max.toFixed(1)}</text>
                        <text x="${23}" y="${35+80/2}"
                              font-size="10" fill="var(--spectrum-gray-800)" text-anchor="middle"
                              transform="rotate(-90, ${23}, ${35+80/2})">${this.outputLabel}</text>

                        <!-- Center line for central spread -->
                        ${this.config.spread==="central"?G`
                            <line x1="${38+124/2}"
                                  y1="${35}"
                                  x2="${38+124/2}"
                                  y2="${115}"
                                  stroke="var(--spectrum-notice-color-900)"
                                  stroke-width="1"
                                  stroke-dasharray="3,3"
                                  opacity="0.5" />
                        `:""}

                        <polyline points="${d}"
                            fill="none" stroke="${this.color}" stroke-width="2.5" stroke-linecap="round"
                            transform="translate(${38}, ${38})" />

                        <!-- Hover position indicator -->
                        ${m!==null&&$!==null?G`
                            <line x1="${38+m*124}"
                                  y1="${35}"
                                  x2="${38+m*124}"
                                  y2="${115}"
                                  stroke="var(--spectrum-positive-color-900)"
                                  stroke-width="2"
                                  opacity="0.6"
                                  stroke-dasharray="4,4" />

                            <!-- Output value label -->
                            <text x="${38+m*124}"
                                  y="${27}"
                                  text-anchor="middle"
                                  font-size="11"
                                  fill="var(--spectrum-positive-color-900)"
                                  font-weight="600">
                                ${$.toFixed(3)}
                            </text>
                        `:""}
                    </svg>
                <p style="font-size: 12px; color: var(--spectrum-gray-700);">Label: ${this.label} | Control: ${this.control}</p>
                
                <div class="controls-grid">
                    <div class="control-selector-top">
                        <label class="control-selector-label">Controlled by:</label>
                        <sp-picker data-spectrum-pattern="picker-s" size="s" value="${this.control}" @change=${this.handleControlChange}>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="yaxis">Y-Axis Position</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="pressure">Stylus Pressure</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="tiltX">Tilt X</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="tiltY">Tilt Y</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="tiltXY">Tilt X+Y</sp-menu-item>
                        </sp-picker>
                    </div>
                    
                    <div class="range-field">
                        <label class="range-label">Spread</label>
                        <sp-picker data-spectrum-pattern="picker-s" size="s" value="${this.config.spread}"
                            @change=${w=>this.handleConfigChange("spread",w.target.value)}>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="direct">Direct</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="inverse">Inverse</sp-menu-item>
                            <sp-menu-item data-spectrum-pattern="menu-item" value="central">Central</sp-menu-item>
                        </sp-picker>
                    </div>
                    
                    <div class="range-field">
                        <label class="range-label">Min</label>
                        <sp-number-field data-spectrum-pattern="number-field-s" size="s" value="${this.config.min}" step="0.1"
                            @change=${w=>this.handleConfigChange("min",parseFloat(w.target.value))}>
                        </sp-number-field>
                    </div>
                    
                    <div class="range-field">
                        <label class="range-label">Max</label>
                        <sp-number-field data-spectrum-pattern="number-field-s" size="s" value="${this.config.max}" step="0.1"
                            @change=${w=>this.handleConfigChange("max",parseFloat(w.target.value))}>
                        </sp-number-field>
                    </div>
                    
                    <div class="range-field">
                        <label class="range-label">Curve</label>
                        <sp-number-field data-spectrum-pattern="number-field-s" size="s" value="${this.config.curve}" step="0.1" min="0.1"
                            @change=${w=>this.handleConfigChange("curve",parseFloat(w.target.value))}>
                        </sp-number-field>
                    </div>
                    
                    <div class="range-field">
                        <label class="range-label">Multiplier</label>
                        <sp-number-field data-spectrum-pattern="number-field-s" size="s" value="${this.config.multiplier}" step="0.1" min="0" max="2"
                            @change=${w=>this.handleConfigChange("multiplier",parseFloat(w.target.value))}>
                        </sp-number-field>
                    </div>
                </div>
        `}};jt.styles=hr;let N=jt;q([l({type:String})],N.prototype,"label");q([l({type:String})],N.prototype,"parameterKey");q([l({type:String})],N.prototype,"control");q([l({type:String})],N.prototype,"outputLabel");q([l({type:Object,hasChanged:()=>!0})],N.prototype,"config");q([l({type:String})],N.prototype,"color");q([l({type:Number,hasChanged:()=>!0})],N.prototype,"hoverPosition");customElements.get("curve-visualizer")||customElements.define("curve-visualizer",N);const Lr=k`
    :host {
        display: block;
        min-width: 0;
        max-width: 100%;
    }

    .panel {
        display: flex;
        flex-direction: column;
        background-color: var(--spectrum-gray-100);
        border: 1px solid var(--spectrum-gray-200);
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.2s ease;
        height: 100%;
        max-width: 100%;
    }
    
    .panel:hover {
        border-color: var(--spectrum-gray-300);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    }


    .panel.minimized {
        height: auto;
    }
    
    .panel.minimized .panel-content {
        display: none;
    }

    .panel.dragging {
        opacity: 0.5;
        cursor: grabbing;
    }
    
    .panel-header {
        padding: 12px 16px;
        background: var(--spectrum-gray-200);
        border-bottom: 1px solid var(--spectrum-gray-300);
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        min-height: 48px;
    }
    
    .drag-handle {
        cursor: grab;
        user-select: none;
        color: var(--spectrum-gray-500);
        font-size: 14px;
        padding: 0 4px;
        transition: color 0.2s ease;
        line-height: 1;
        letter-spacing: -2px;
    }

    .drag-handle:hover {
        color: var(--spectrum-gray-700);
    }

    .drag-handle:active {
        cursor: grabbing;
    }

    .header-left {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
        min-width: 0;
    }
    
    .header-controls {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
    }
    
    .panel-title {
        margin: 0;
        font-size: 13px;
        font-weight: 600;
        color: var(--spectrum-gray-900);
        letter-spacing: 0.3px;
        text-transform: uppercase;
        opacity: 0.9;
        white-space: nowrap;
    }
    
    :host([hasActiveControl]:not([active])) .panel-title {
        opacity: 0.4;
    }

    :host([hasActiveControl]:not([active])) .panel {
        background-color: var(--spectrum-gray-75);
        border-color: var(--spectrum-gray-200);
    }

    :host([hasActiveControl]:not([active])) .panel-header {
        background: var(--spectrum-gray-100);
        border-bottom-color: var(--spectrum-gray-200);
    }

    :host([hasActiveControl]:not([active])) .panel-content {
        opacity: 0.3;
        pointer-events: none;
        user-select: none;
        filter: grayscale(0.5);
    }

    .header-switch {
        flex-shrink: 0;
        margin: 0;
        --spectrum-switch-control-width: 26px;
        --spectrum-switch-control-height: 14px;
    }
    
    .header-controls sp-action-button {
        --spectrum-actionbutton-min-width: 24px;
        font-size: 11px;
    }
    
    .panel-content {
        padding: 20px;
        flex: 1;
        overflow: auto;
        min-width: 0;
        max-width: 100%;
        box-sizing: border-box;
    }

    @media (max-width: 640px) {
        .panel-content {
            padding: 12px;
        }
    }
`;var Vr=Object.defineProperty,B=(o,t,e,r)=>{for(var i=void 0,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=a(t,e,i)||i);return i&&Vr(t,e,i),i};const Ht=class Ht extends U{constructor(){super(...arguments),this.title="",this.size="medium",this.hasActiveControl=!1,this.active=!1,this.closable=!1,this.minimizable=!0,this.draggable=!0,this.panelId="",this.minimized=!1,this.isMinimized=!1,this.isVisible=!0,this.isDragging=!1}updated(t){t.has("minimized")&&(this.isMinimized=this.minimized)}handleActiveChange(t){const e=t.target.checked;this.dispatchEvent(new CustomEvent("active-change",{detail:{active:e},bubbles:!0,composed:!0}))}toggleMinimize(){this.isMinimized=!this.isMinimized}handleClose(){this.isVisible=!1,this.dispatchEvent(new CustomEvent("panel-close",{bubbles:!0,composed:!0}))}handleDragStart(t){this.draggable&&(this.isDragging=!0,t.dataTransfer.effectAllowed="move",t.dataTransfer.setData("text/plain",this.panelId),this.dispatchEvent(new CustomEvent("panel-drag-start",{detail:{panelId:this.panelId},bubbles:!0,composed:!0})))}handleDragEnd(){this.isDragging=!1,this.dispatchEvent(new CustomEvent("panel-drag-end",{bubbles:!0,composed:!0}))}handleDragOver(t){this.draggable&&(t.preventDefault(),t.dataTransfer.dropEffect="move")}handleDrop(t){if(!this.draggable)return;t.preventDefault();const e=t.dataTransfer.getData("text/plain");e&&e!==this.panelId&&this.dispatchEvent(new CustomEvent("panel-drop",{detail:{draggedPanelId:e,targetPanelId:this.panelId},bubbles:!0,composed:!0}))}render(){return this.isVisible?n`
            <div 
                class="panel ${this.isMinimized?"minimized":""} ${this.isDragging?"dragging":""}" 
                data-size="${this.size}"
                @dragover="${this.handleDragOver}"
                @drop="${this.handleDrop}">
                ${this.title?n`
                    <div class="panel-header">
                        <div class="header-left">
                            ${this.draggable?n`
                                <div class="drag-handle" draggable="true"
                                    @dragstart="${this.handleDragStart}"
                                    @dragend="${this.handleDragEnd}"
                                    title="Drag to reorder">⋮⋮</div>
                            `:""}
                            ${this.hasActiveControl?n`
                                <sp-switch
                                    data-spectrum-pattern="switch-s"
                                    ?checked="${this.active}"
                                    @change="${this.handleActiveChange}"
                                    class="header-switch"
                                    size="s"
                                    title="${this.active?"Active":"Inactive"}">
                                </sp-switch>
                            `:""}
                            <h3 class="panel-title">${this.title}</h3>
                        </div>
                        <div class="header-controls">
                            <slot name="header-actions"></slot>
                            ${this.minimizable?n`
                                <sp-action-button data-spectrum-pattern="action-button-quiet-xs" size="xs" quiet
                                    @click="${this.toggleMinimize}"
                                    title="${this.isMinimized?"Maximize":"Minimize"}">
                                    ${this.isMinimized?"▼":"▲"}
                                </sp-action-button>
                            `:""}
                            ${this.closable?n`
                                <sp-action-button data-spectrum-pattern="action-button-quiet-xs" size="xs" quiet
                                    @click="${this.handleClose}" title="Close">✕</sp-action-button>
                            `:""}
                        </div>
                    </div>
                `:""}
                <div class="panel-content">
                    <slot></slot>
                </div>
            </div>
        `:n``}};Ht.styles=Lr;let C=Ht;B([l({type:String})],C.prototype,"title");B([l({type:String})],C.prototype,"size");B([l({type:Boolean,reflect:!0})],C.prototype,"hasActiveControl");B([l({type:Boolean,reflect:!0})],C.prototype,"active");B([l({type:Boolean})],C.prototype,"closable");B([l({type:Boolean})],C.prototype,"minimizable");B([l({type:Boolean})],C.prototype,"draggable");B([l({type:String})],C.prototype,"panelId");B([l({type:Boolean})],C.prototype,"minimized");B([p()],C.prototype,"isMinimized");B([p()],C.prototype,"isVisible");B([p()],C.prototype,"isDragging");customElements.get("dashboard-panel")||customElements.define("dashboard-panel",C);var jr=Object.defineProperty,Hr=Object.getOwnPropertyDescriptor,Et=(o,t,e,r)=>{for(var i=r>1?void 0:r?Hr(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&jr(t,e,i),i};let ct=class extends lo{constructor(){super(...arguments),this.stringCount=6,this.notes=[],this.externalLastPluckedString=null}renderStrings(o,t,e,r){if(this.stringCount===0)return G``;const i=o/(this.stringCount+1),a=r+5,u=r+t-18,d=this.socketMode?this.externalLastPluckedString:null;return G`
            ${Array.from({length:this.stringCount},(m,$)=>{const w=e+i*($+1),_=this.notes[$],F=_?`${_.notation}${_.octave}`:"",R=d===$;return G`
                    <!-- Visible string - non-interactive -->
                    <line
                        x1="${w}"
                        y1="${a}"
                        x2="${w}"
                        y2="${u}"
                        stroke="${R?"#4ade80":"var(--svg-gray-700)"}"
                        stroke-width="${R?2:1}"
                        opacity="${R?1:.5}"
                        pointer-events="none" />

                    <!-- Note label at bottom of string -->
                    ${F?G`
                        <text
                            x="${w}"
                            y="${r+t-5}"
                            text-anchor="middle"
                            font-size="10"
                            fill="${R?"#4ade80":"var(--svg-gray-500)"}"
                            font-weight="${R?"700":"500"}"
                            pointer-events="none">
                            ${F}
                        </text>
                    `:""}
                `})}
        `}renderTablet(){return n`
            <div class="tablet-container">
                <svg width="100%" height="100%"
                     viewBox="0 0 ${280} ${240}"
                     preserveAspectRatio="xMidYMid meet"
                     xmlns="http://www.w3.org/2000/svg"
                     class="tablet-svg">

                <!-- Tablet body -->
                <rect x="${20}" y="${20}" width="${240}" height="${200}"
                    class="tablet-body" rx="15"
                    pointer-events="${this.socketMode?"none":"auto"}" />

                <!-- Active area -->
                <rect x="${40}" y="${40}" width="${200}" height="${160}"
                    class="tablet-surface" rx="8"
                    pointer-events="none" />

                <!-- Strings (vertical lines) -->
                ${this.renderStrings(200,160,40,40)}

                <!-- Position indicator -->
                ${this.renderPositionIndicator(40,40,200,160)}
                </svg>
            </div>
        `}renderPositionIndicator(o,t,e,r){if(this.socketMode){if(!(this.externalTabletData.x>0||this.externalTabletData.y>0))return G``;const s=this.externalTabletData.pressure>0,a=o+this.externalTabletData.x*e,c=t+this.externalTabletData.y*r,u=s?"#ff6b6b":"#74c0fc",d=s?Math.max(.3,this.externalTabletData.pressure):.6;return G`
                <circle cx="${a}" cy="${c}" r="${s?12:8}" 
                    fill="${u}" opacity="${d}" pointer-events="none" />
            `}return G``}render(){return this.mode==="both"||this.mode==="tablet"?n`<div class="tablet-container">${this.renderTablet()}</div>`:super.render()}};Et([l({type:Number})],ct.prototype,"stringCount",2);Et([l({type:Array,hasChanged:()=>!0})],ct.prototype,"notes",2);Et([l({type:Number})],ct.prototype,"externalLastPluckedString",2);ct=Et([J("strum-visualizer")],ct);var Ur=Object.defineProperty,qr=Object.getOwnPropertyDescriptor,ht=(o,t,e,r)=>{for(var i=r>1?void 0:r?qr(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&Ur(t,e,i),i};let j=class extends U{constructor(){super(...arguments),this.events=[],this.isEmpty=!1,this.lastStrumEvent=null}_formatValue(o,t=3){return o===void 0?"—":o.toFixed(t)}_getPressedTabletButton(o){return o.button1?1:o.button2?2:o.button3?3:o.button4?4:o.button5?5:o.button6?6:o.button7?7:o.button8?8:null}_renderStrumSection(){const o=this.events.length>0?this.events[this.events.length-1]:null,t=(o==null?void 0:o.strum)||this.lastStrumEvent;return n`
      <div class="strum-section">
        <div class="strum-header">
          <span class="strum-label">Strum</span>
          ${t?n`
            <span class="strum-type ${t.type}">${t.type}</span>
          `:""}
        </div>

        ${t&&t.type==="strum"&&t.notes.length>0?n`
          <div class="strum-notes">
            ${t.notes.map(e=>n`
              <div class="note-chip">
                <span class="note-name">${e.note.notation}${e.note.octave}</span>
                <span class="note-velocity">v${e.velocity}</span>
              </div>
            `)}
          </div>
          <div class="strum-velocity">Velocity: ${t.velocity}</div>
        `:t&&t.type==="release"?n`
          <div class="no-strum">Released</div>
        `:n`
          <div class="no-strum">No strum</div>
        `}
      </div>
    `}render(){var t,e,r;if(this.isEmpty||this.events.length===0)return n`
        <div class="events-container empty">
          <div class="empty-state">
            <div class="empty-icon">—</div>
            <p>No events yet</p>
          </div>
        </div>
      `;const o=this.events[this.events.length-1];return n`
      <div class="events-container">
        <div class="event-header">
          <span class="event-count">${((t=this.deviceInfo)==null?void 0:t.packetCount)??this.events.length}</span>
          <span class="event-label">events</span>
          <div class="header-badges">
            ${(e=this.deviceInfo)!=null&&e.isMock?n`<span class="source-badge mock">mock</span>`:""}
            ${(r=this.deviceInfo)!=null&&r.isTranslated?n`<span class="source-badge translated">translated</span>`:""}
          </div>
        </div>
        
        <div class="event-grid">
          <div class="event-field">
            <span class="field-label">X</span>
            <span class="field-value">${this._formatValue(o.x)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Y</span>
            <span class="field-value">${this._formatValue(o.y)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Pressure</span>
            <span class="field-value">${this._formatValue(o.pressure)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Tilt X</span>
            <span class="field-value">${this._formatValue(o.tiltX)}</span>
          </div>
          <div class="event-field">
            <span class="field-label">Tilt Y</span>
            <span class="field-value">${this._formatValue(o.tiltY)}</span>
          </div>
        </div>

        <div class="button-status">
          <div class="button-indicator ${o.primaryButtonPressed?"active":""}">
            <span class="button-label">Primary</span>
          </div>
          <div class="button-indicator ${o.secondaryButtonPressed?"active":""}">
            <span class="button-label">Secondary</span>
          </div>
          <div class="button-indicator tablet-btn ${this._getPressedTabletButton(o)?"active":""}">
            <span class="button-label">Tablet ${this._getPressedTabletButton(o)??"—"}</span>
          </div>
        </div>

        ${this._renderStrumSection()}
      </div>
    `}};j.styles=k`
    :host {
      display: block;
      height: 100%;
    }

    .events-container {
      display: flex;
      flex-direction: column;
      height: 100%;
      gap: 10px;
    }

    .events-container.empty {
      justify-content: center;
      align-items: center;
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--spectrum-gray-500);
      text-align: center;
    }

    .empty-icon {
      font-size: 2rem;
      margin-bottom: 8px;
      opacity: 0.5;
    }

    .empty-state p {
      margin: 0;
      font-size: 0.85rem;
    }

    .event-header {
      display: flex;
      align-items: baseline;
      gap: 6px;
    }

    .event-count {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--spectrum-gray-900);
      font-family: 'JetBrains Mono', 'Fira Code', monospace;
    }

    .event-label {
      font-size: 0.75rem;
      color: var(--spectrum-gray-600);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .header-badges {
      display: flex;
      gap: 6px;
      margin-left: auto;
    }

    .source-badge {
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 0.65rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .source-badge.mock {
      background: var(--spectrum-gray-300);
      color: var(--spectrum-gray-800);
    }

    .source-badge.translated {
      background: var(--spectrum-notice-background-color-default);
      color: var(--spectrum-notice-content-color-default);
    }

    .event-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 6px 8px;
    }

    .event-field {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .field-label {
      font-size: 0.65rem;
      color: var(--spectrum-gray-600);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      font-weight: 500;
    }

    .field-value {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--spectrum-gray-900);
      font-family: 'JetBrains Mono', 'Fira Code', monospace;
    }

    .button-status {
      display: flex;
      gap: 8px;
      padding-top: 8px;
      border-top: 1px solid var(--spectrum-gray-200);
    }

    .button-indicator {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
      border-radius: 6px;
      background: var(--spectrum-gray-200);
      transition: all 0.15s ease;
    }

    .button-indicator.active {
      background: var(--spectrum-positive-color-900);
    }

    .button-indicator.active .button-label {
      color: var(--spectrum-gray-50);
    }

    .button-label {
      font-size: 0.7rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--spectrum-gray-700);
    }

    /* Strum-specific styles */
    .strum-section {
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px solid var(--spectrum-gray-300);
    }

    .strum-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
    }

    .strum-label {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--spectrum-gray-600);
    }

    .strum-type {
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 600;
    }

    .strum-type.strum {
      background: var(--spectrum-positive-background-color-default);
      color: var(--spectrum-positive-content-color-default);
    }

    .strum-type.release {
      background: var(--spectrum-notice-background-color-default);
      color: var(--spectrum-notice-content-color-default);
    }

    .strum-notes {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }

    .note-chip {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      background: var(--spectrum-gray-100);
      border: 1px solid var(--spectrum-gray-300);
      border-radius: 6px;
      font-size: 12px;
    }

    .note-name {
      font-weight: 600;
      color: var(--spectrum-gray-900);
    }

    .note-velocity {
      font-size: 10px;
      color: var(--spectrum-gray-600);
    }

    .no-strum {
      font-size: 12px;
      color: var(--spectrum-gray-500);
      font-style: italic;
    }

    .strum-velocity {
      margin-top: 6px;
      font-size: 11px;
      color: var(--spectrum-gray-600);
    }
  `;ht([l({type:Array})],j.prototype,"events",2);ht([l({type:Boolean})],j.prototype,"isEmpty",2);ht([l({type:Object})],j.prototype,"deviceInfo",2);ht([l({type:Object})],j.prototype,"lastStrumEvent",2);j=ht([J("strum-events-display")],j);const Zr=k`
  :host {
    display: block;
    width: 100%;
  }

  .config-section {
    display: flex;
    flex-direction: column;
    gap: 24px;
  }

  /* Single panel mode - panel takes full width without wrapper */
  .config-section.single-panel .panel {
    width: 100%;
  }

  /* Two-column layout for panels */
  .panels-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }

  @media (max-width: 900px) {
    .panels-row {
      grid-template-columns: 1fr;
    }
  }

  /* Unified panel container */
  .panel {
    background: var(--spectrum-gray-100);
    border-radius: 12px;
    border: 1px solid var(--spectrum-gray-200);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease;
  }

  .panel:hover {
    border-color: var(--spectrum-gray-300);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
  }

  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: var(--spectrum-gray-200);
    border-bottom: 1px solid var(--spectrum-gray-300);
  }

  .section-title {
    font-weight: 600;
    color: var(--spectrum-gray-900);
    font-size: 0.9em;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }

  .rules-list {
    display: flex;
    flex-direction: column;
    flex: 1;
    overflow-y: auto;
    max-height: 400px;
  }

  .rule-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--spectrum-gray-200);
  }

  .rule-item:last-child {
    border-bottom: none;
  }

  .rule-item:hover {
    background: var(--spectrum-gray-100);
  }

  /* Status dot for triggered actions */
  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--spectrum-gray-300);
    flex-shrink: 0;
    transition: background-color 0.3s ease, box-shadow 0.3s ease, opacity 1s ease;
  }

  .status-dot.active {
    background: var(--spectrum-green-500);
    box-shadow: 0 0 6px var(--spectrum-green-500);
  }

  .status-dot.permanent {
    /* Startup rules stay lit permanently - no fade transition */
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
  }

  .rule-button-id {
    min-width: 80px;
    font-weight: 500;
    color: var(--spectrum-gray-900);
    font-size: 0.85em;
  }

  .rule-arrow {
    color: var(--spectrum-gray-500);
  }

  .rule-action {
    flex: 1;
    color: var(--spectrum-gray-800);
    font-size: 0.85em;
  }

  .rule-trigger {
    padding: 2px 8px;
    background: var(--spectrum-gray-200);
    border-radius: 4px;
    font-size: 0.75em;
    color: var(--spectrum-gray-700);
  }

  .rule-type-badge {
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.7em;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    flex-shrink: 0;
  }

  .rule-type-badge.button {
    background: var(--spectrum-blue-100);
    color: var(--spectrum-blue-900);
  }

  .rule-type-badge.group {
    background: var(--spectrum-purple-100);
    color: var(--spectrum-purple-900);
  }

  .rule-type-badge.startup {
    background: var(--spectrum-yellow-100);
    color: var(--spectrum-yellow-900);
  }

  .rule-name {
    color: var(--spectrum-gray-600);
    font-size: 0.8em;
    font-style: italic;
  }

  .rule-actions {
    display: flex;
    gap: 2px;
    flex-shrink: 0;
  }

  .group-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 12px 16px;
    border-bottom: 1px solid var(--spectrum-gray-200);
  }

  .group-item:last-child {
    border-bottom: none;
  }

  .group-item:hover {
    background: var(--spectrum-gray-100);
  }

  .group-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .group-name {
    font-weight: 600;
    color: var(--spectrum-gray-900);
    font-size: 0.9em;
  }

  .group-details {
    display: flex;
    gap: 16px;
    color: var(--spectrum-gray-700);
    font-size: 0.85em;
  }

  .group-buttons {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
  }

  .button-chip {
    padding: 4px 10px;
    background: var(--spectrum-gray-200);
    border-radius: 4px;
    font-size: 0.8em;
    color: var(--spectrum-gray-800);
    transition: background-color 0.15s ease, box-shadow 0.15s ease;
  }

  /* Legacy class for backwards compatibility (used in group list display) */
  .button-chip.pressed {
    background: var(--spectrum-blue-400);
    color: white;
  }

  /* Selected state (button is in the group) */
  .button-chip.selected {
    background: var(--spectrum-blue-400);
    color: white;
  }

  /* Detected state (button is currently pressed on device) */
  .button-chip.detected {
    background: var(--spectrum-orange-400);
    color: white;
    box-shadow: 0 0 8px var(--spectrum-orange-400);
  }

  /* Both selected and detected */
  .button-chip.selected.detected {
    background: var(--spectrum-green-500);
    color: white;
    box-shadow: 0 0 8px var(--spectrum-green-500);
  }

  .startup-icon {
    color: var(--spectrum-gray-600);
  }

  .empty-state {
    padding: 24px 16px;
    text-align: center;
    color: var(--spectrum-gray-600);
    font-style: italic;
    font-size: 0.9em;
  }

  /* Add/Edit Form Styles */
  .form-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    /* Use z-index below Spectrum's overlay base (1000) so picker dropdowns appear above */
    z-index: 999;
  }

  .form-dialog {
    background: var(--spectrum-gray-100);
    border-radius: 12px;
    padding: 24px;
    min-width: 400px;
    max-width: 500px;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    /* Prevent scroll events from interfering with picker dropdowns */
    overscroll-behavior: contain;
  }

  .form-title {
    font-size: 1.1em;
    font-weight: 600;
    margin-bottom: 20px;
    color: var(--spectrum-gray-900);
  }

  .form-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin-bottom: 16px;
  }

  .form-row {
    display: flex;
    gap: 12px;
  }

  .form-row .form-field {
    flex: 1;
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 24px;
  }

  .detect-button {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .detecting {
    animation: pulse 1s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  sp-picker, sp-textfield, sp-number-field {
    width: 100%;
  }

  sp-action-button {
    --spectrum-actionbutton-m-min-width: 28px;
  }

  /* Native select styling to match Spectrum picker */
  .native-select {
    width: 100%;
    box-sizing: border-box;
    height: var(--spectrum-component-height-100, 32px);
    padding-inline-start: var(--spectrum-component-edge-to-text-100, 12px);
    padding-inline-end: 28px; /* Space for dropdown arrow */
    font-family: var(--spectrum-sans-font-family-stack, adobe-clean, 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif);
    font-size: var(--spectrum-font-size-100, 14px);
    font-weight: var(--spectrum-regular-font-weight, 400);
    line-height: var(--spectrum-line-height-100, 1.3);
    border: 1px solid var(--spectrum-gray-400, #b3b3b3);
    border-radius: var(--spectrum-corner-radius-100, 4px);
    background-color: var(--spectrum-gray-75, #ffffff);
    color: var(--spectrum-gray-800, #4b4b4b);
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%236e6e6e' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 10px center;
    transition: border-color 130ms ease-in-out, box-shadow 130ms ease-in-out, background-color 130ms ease-in-out;
  }

  .native-select:hover {
    border-color: var(--spectrum-gray-500, #959595);
    background-color: var(--spectrum-gray-100, #f5f5f5);
  }

  .native-select:focus {
    outline: none;
    border-color: var(--spectrum-blue-900, #0054b6);
    box-shadow: 0 0 0 1px var(--spectrum-blue-900, #0054b6);
  }

  .native-select:focus-visible {
    outline: 2px solid var(--spectrum-focus-indicator-color, #0054b6);
    outline-offset: 2px;
  }

  /* Dark mode support */
  @media (prefers-color-scheme: dark) {
    .native-select {
      background-color: var(--spectrum-gray-100, #323232);
      border-color: var(--spectrum-gray-400, #5c5c5c);
      color: var(--spectrum-gray-800, #e1e1e1);
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath fill='%23b3b3b3' d='M5 6L0 0h10z'/%3E%3C/svg%3E");
    }

    .native-select:hover {
      background-color: var(--spectrum-gray-200, #3e3e3e);
      border-color: var(--spectrum-gray-500, #6e6e6e);
    }
  }
`,Yr={buttonNames:{}};function yt(o="rule"){return`${o}-${Date.now()}-${Math.random().toString(36).substr(2,9)}`}function Xr(o){const t=o.split(":");if(t.length!==2||t[0]!=="button")throw new Error(`Invalid button ID: ${o}`);const e=t[1];if(e==="primary"||e==="secondary")return{type:"stylus",identifier:e};const r=parseInt(e,10);if(isNaN(r)||r<1)throw new Error(`Invalid button ID: ${o}`);return{type:"tablet",identifier:e}}function wt(o,t){if(t&&t[o])return t[o];const{type:e,identifier:r}=Xr(o);return e==="stylus"?r==="primary"?"Primary Stylus":"Secondary Stylus":`Button ${r}`}class St{constructor(t={}){this.buttonNames={...Yr.buttonNames,...t.buttonNames},this.rules=t.rules?[...t.rules]:[],this.groups=t.groups?[...t.groups]:[],this.groupRules=t.groupRules?[...t.groupRules]:[],this.startupRules=t.startupRules?[...t.startupRules]:[]}static fromDict(t){if(!t)return new St;const e=t.groupRules??t.group_rules,r=(e==null?void 0:e.map(i=>({id:i.id,name:i.name,groupId:i.groupId??i.group_id,action:i.action,trigger:i.trigger})))??[];return new St({buttonNames:t.buttonNames??t.button_names,rules:t.rules??[],groups:t.groups??[],groupRules:r,startupRules:t.startupRules??t.startup_rules})}toDict(){return{buttonNames:{...this.buttonNames},rules:[...this.rules],groups:[...this.groups],groupRules:[...this.groupRules],startupRules:[...this.startupRules]}}addRule(t){const e={...t,id:t.id??yt("rule"),trigger:t.trigger??"release"};return this.rules.push(e),e}removeRule(t){const e=this.rules.findIndex(r=>r.id===t);return e>=0?(this.rules.splice(e,1),!0):!1}updateRule(t,e){const r=this.rules.find(i=>i.id===t);return r?(Object.assign(r,e),!0):!1}addGroup(t){const e={...t,id:t.id??yt("group")};return this.groups.push(e),e}removeGroup(t){const e=this.groups.findIndex(r=>r.id===t);return e>=0?(this.groups.splice(e,1),!0):!1}updateGroup(t,e){const r=this.groups.find(i=>i.id===t);return r?(Object.assign(r,e),!0):!1}addGroupRule(t){const e={...t,id:t.id??yt("grouprule")};return this.groupRules.push(e),e}removeGroupRule(t){const e=this.groupRules.findIndex(r=>r.id===t);return e>=0?(this.groupRules.splice(e,1),!0):!1}updateGroupRule(t,e){const r=this.groupRules.find(i=>i.id===t);return r?(Object.assign(r,e),!0):!1}getGroupRuleForGroup(t){return this.groupRules.find(e=>e.groupId===t)}addStartupRule(t){const e={...t,id:t.id??yt("startup")};return this.startupRules.push(e),e}removeStartupRule(t){const e=this.startupRules.findIndex(r=>r.id===t);return e>=0?(this.startupRules.splice(e,1),!0):!1}setButtonName(t,e){e?this.buttonNames[t]=e:delete this.buttonNames[t]}getRulesForButton(t){return this.rules.filter(e=>e.button===t)}getGroupForButton(t){return this.groups.find(e=>e.buttons.includes(t))}getActionForButtonEvent(t,e){const r=this.getRuleForButtonEvent(t,e);return(r==null?void 0:r.action)??null}getRuleForButtonEvent(t,e){const r=this.rules.find(s=>s.button===t&&(s.trigger??"release")===e);if(r)return{action:r.action,ruleId:r.id};const i=this.getGroupForButton(t);if(i){const s=i.buttons.indexOf(t);if(s>=0){const a=this.getGroupRuleForGroup(i.id);if(a&&(a.trigger??"release")===e&&a.action.type==="chord-progression")return{action:["set-chord-in-progression",a.action.progression,s,a.action.octave],ruleId:a.id}}}return null}}const Wr={"c-major-basic":["C","F","G","Am"],"c-major-pop":["C","G","Am","F"],"c-major-jazz":["Cmaj7","Dm7","Em7","Fmaj7","G7","Am7","Bm7"],"c-major-50s":["C","Am","F","G"],"g-major-basic":["G","C","D","Em"],"g-major-pop":["G","D","Em","C"],"g-major-jazz":["Gmaj7","Am7","Bm7","Cmaj7","D7","Em7","F#m7"],"d-major-basic":["D","G","A","Bm"],"d-major-pop":["D","A","Bm","G"],"d-major-jazz":["Dmaj7","Em7","F#m7","Gmaj7","A7","Bm7","C#m7"],"a-major-basic":["A","D","E","F#m"],"a-major-pop":["A","E","F#m","D"],"e-major-basic":["E","A","B","C#m"],"e-major-pop":["E","B","C#m","A"],"f-major-basic":["F","Bb","C","Dm"],"f-major-pop":["F","C","Dm","Bb"],"a-minor-basic":["Am","Dm","Em","F","E"],"a-minor-pop":["Am","F","C","G","E"],"a-minor-sad":["Am","Em","F","C","G","Dm","E"],"e-minor-basic":["Em","Am","Bm","C","B"],"e-minor-pop":["Em","C","G","D","B"],"d-minor-basic":["Dm","Gm","Am","Bb","A"],"d-minor-pop":["Dm","Bb","F","C","A"],"blues-e":["E7","A7","B7"],"blues-a":["A7","D7","E7"],"blues-g":["G7","C7","D7"],"rock-classic":["E","A","D","B"],"rock-power":["E5","G5","A5","C5","D5"],"jazz-251-c":["Dm7","G7","Cmaj7","Em7","A7"],"jazz-251-f":["Gm7","C7","Fmaj7","Am7","D7"],"gospel-c":["C","Am7","Dm7","G7","F"],"gospel-g":["G","Em7","Am7","D7","C"]};function Te(){return Object.keys(Wr)}const Kr=({width:o=24,height:t=24,hidden:e=!1,title:r="Add"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    viewBox="0 0 20 20"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="m16.25,9.25h-5.5V3.75c0-.41406-.33594-.75-.75-.75s-.75.33594-.75.75v5.5H3.75c-.41406,0-.75.33594-.75.75s.33594.75.75.75h5.5v5.5c0,.41406.33594.75.75.75s.75-.33594.75-.75v-5.5h5.5c.41406,0,.75-.33594.75-.75s-.33594-.75-.75-.75Z"
      fill="currentColor"
    />
  </svg>`,Jr=({width:o=24,height:t=24,hidden:e=!1,title:r="Add"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${t}"
    viewBox="0 0 36 36"
    width="${o}"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="M29 16h-9V7a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v9H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h9v9a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-9h9a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1Z"
    />
  </svg>`;class Qr extends T{render(){return Bt(n),this.spectrumVersion===2?Kr({hidden:!this.label,title:this.label}):Jr({hidden:!this.label,title:this.label})}}x("sp-icon-add",Qr);const ti=({width:o=24,height:t=24,hidden:e=!1,title:r="Delete"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="${o}"
    height="${t}"
    viewBox="0 0 20 20"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="m8.24902,15.02148c-.40039,0-.7334-.31738-.74805-.7207l-.25-6.5c-.0166-.41406.30664-.7627.71973-.77832.01074-.00098.02051-.00098.03027-.00098.40039,0,.7334.31738.74805.7207l.25,6.5c.0166.41406-.30664.7627-.71973.77832-.01074.00098-.02051.00098-.03027.00098Z"
      fill="currentColor"
    />
    <path
      d="m11.75098,15.02148c-.00977,0-.01953,0-.03027-.00098-.41309-.01562-.73633-.36426-.71973-.77832l.25-6.5c.01465-.40332.34766-.7207.74805-.7207.00977,0,.01953,0,.03027.00098.41309.01562.73633.36426.71973.77832l-.25,6.5c-.01465.40332-.34766.7207-.74805.7207Z"
      fill="currentColor"
    />
    <path
      d="m17,4h-3.5v-.75c0-1.24023-1.00977-2.25-2.25-2.25h-2.5c-1.24023,0-2.25,1.00977-2.25,2.25v.75h-3.5c-.41406,0-.75.33594-.75.75s.33594.75.75.75h.52002l.42236,10.3418c.04785,1.20996,1.03613,2.1582,2.24805,2.1582h7.61914c1.21191,0,2.2002-.94824,2.24805-2.1582l.42236-10.3418h.52002c.41406,0,.75-.33594.75-.75s-.33594-.75-.75-.75Zm-9-.75c0-.41309.33691-.75.75-.75h2.5c.41309,0,.75.33691.75.75v.75h-4v-.75Zm6.55957,12.53125c-.0166.40332-.3457.71875-.75.71875h-7.61914c-.4043,0-.7334-.31543-.75-.71875l-.41968-10.28125h9.9585l-.41968,10.28125Z"
      fill="currentColor"
    />
  </svg>`,ei=({width:o=24,height:t=24,hidden:e=!1,title:r="Delete"}={})=>L`<svg
    xmlns="http://www.w3.org/2000/svg"
    height="${t}"
    viewBox="0 0 36 36"
    width="${o}"
    aria-hidden=${e?"true":"false"}
    role="img"
    fill="currentColor"
    aria-label="${r}"
  >
    <path
      d="M31.5 6H24V4a2 2 0 0 0-2-2H12a2 2 0 0 0-2 2v2H2.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h2l2.413 25.1a1 1 0 0 0 1 .9h18.179a1 1 0 0 0 1-.9L29.5 8h2a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5ZM11.065 29A1 1 0 0 1 10 28.068l-1.071-16a1 1 0 1 1 2-.134l1.071 16A1 1 0 0 1 11.065 29ZM18 28a1 1 0 0 1-2 0V12a1 1 0 0 1 2 0Zm4-22H12V4h10Zm2 22.068a1 1 0 1 1-2-.134l1.071-16a1 1 0 1 1 2 .134Z"
    />
  </svg>`;class oi extends T{render(){return Bt(n),this.spectrumVersion===2?ti({hidden:!this.label,title:this.label}):ei({hidden:!this.label,title:this.label})}}x("sp-icon-delete",oi);var ri=Object.defineProperty,ii=Object.getOwnPropertyDescriptor,f=(o,t,e,r)=>{for(var i=r>1?void 0:r?ii(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&ri(t,e,i),i};let g=class extends U{constructor(){super(...arguments),this.mode="all",this.pressedButtons=new Set,this.buttonCount=8,this.hasPrimaryButton=!0,this.hasSecondaryButton=!0,this.triggeredActions=new Map,this.formMode="none",this.editingId=null,this.detecting=!1,this.overlayMouseDownTarget=null,this.formTargetType="button",this.formButton="button:1",this.formGroupId="",this.formAction="none",this.formTrigger="release",this.formName="",this.formParams=[],this.formGroupActionType="chord-progression",this.formGroupProgression="c-major-pop",this.formGroupOctave=4,this.formGroupTrigger="release",this.formGroupName="",this.formGroupButtons=[],this.progressionNames=Te(),this.actions=[{value:"none",label:"None"},{value:"toggle-repeater",label:"Toggle Note Repeater",params:[{key:"pressureMultiplier",label:"Pressure Multiplier",type:"number",min:.1,max:10,step:.1,defaultValue:2},{key:"frequencyMultiplier",label:"Frequency Multiplier",type:"number",min:.1,max:10,step:.1,defaultValue:1.5}]},{value:"toggle-transpose",label:"Toggle Transpose",params:[{key:"semitones",label:"Semitones",type:"number",min:-24,max:24,step:1,defaultValue:12}]},{value:"transpose",label:"Transpose",params:[{key:"semitones",label:"Semitones",type:"number",min:-24,max:24,step:1,defaultValue:12}]},{value:"set-strum-chord",label:"Set Strum Chord",params:[{key:"chord",label:"Chord",type:"text",defaultValue:"C"},{key:"octave",label:"Octave",type:"number",min:0,max:8,step:1,defaultValue:4}]},{value:"set-group-progression",label:"Set Group Progression",params:[{key:"groupId",label:"Group ID",type:"text",defaultValue:""},{key:"progression",label:"Progression",type:"select",defaultValue:"c-major-pop",options:Te().map(o=>({value:o,label:o}))}]}]}updated(o){if(super.updated(o),o.has("pressedButtons")&&this.detecting){const t=Array.from(this.pressedButtons);t.length>0&&(this.formButton=t[0],this.detecting=!1)}}getAvailableButtons(){const o=[];this.hasPrimaryButton&&o.push("button:primary"),this.hasSecondaryButton&&o.push("button:secondary");for(let t=1;t<=this.buttonCount;t++)o.push(`button:${t}`);return o}formatAction(o){if(!o||o==="none")return"None";if(typeof o=="string")return o;if(Array.isArray(o)){const[t,...e]=o;return e.length>0?`${t}(${e.join(", ")})`:t}return String(o)}buildActionDefinition(o,t){return o==="none"||!o?null:t.length===0?o:[o,...t]}dispatchConfigChange(){this.config&&this.dispatchEvent(new CustomEvent("config-change",{detail:{actionRules:this.config.toDict()},bubbles:!0,composed:!0}))}openAddActionForm(o="button"){var t,e;this.formMode="add-action",this.editingId=null,this.formTargetType=o,this.formButton="button:1",this.formGroupId=((e=(t=this.config)==null?void 0:t.groups[0])==null?void 0:e.id)??"",this.formAction="none",this.formTrigger="release",this.formName="",this.formParams=[],this.formGroupActionType="chord-progression",this.formGroupProgression="c-major-pop",this.formGroupOctave=4,this.formGroupTrigger="release"}openEditButtonRuleForm(o){this.formMode="edit-action",this.editingId=o.id,this.formTargetType="button",this.formButton=o.button,this.formTrigger=o.trigger??"release",this.formName=o.name??"",typeof o.action=="string"?(this.formAction=o.action,this.formParams=[]):Array.isArray(o.action)?(this.formAction=o.action[0],this.formParams=o.action.slice(1)):(this.formAction="none",this.formParams=[])}openEditGroupRuleForm(o){this.formMode="edit-action",this.editingId=o.id,this.formTargetType="group",this.formGroupId=o.groupId,this.formName=o.name??"",this.formGroupActionType=o.action.type,this.formGroupProgression=o.action.progression,this.formGroupOctave=o.action.octave,this.formGroupTrigger=o.trigger??"release"}openEditStartupRuleForm(o){this.formMode="edit-action",this.editingId=o.id,this.formTargetType="startup",this.formName=o.name,typeof o.action=="string"?(this.formAction=o.action,this.formParams=[]):Array.isArray(o.action)?(this.formAction=o.action[0],this.formParams=o.action.slice(1)):(this.formAction="none",this.formParams=[])}openAddGroupForm(){this.formMode="add-group",this.editingId=null,this.formGroupName="",this.formGroupButtons=[]}openEditGroupForm(o){this.formMode="edit-group",this.editingId=o.id,this.formGroupName=o.name,this.formGroupButtons=[...o.buttons]}closeForm(){this.formMode="none",this.editingId=null,this.detecting=!1}handleOverlayMouseDown(o){this.overlayMouseDownTarget=o.target}handleOverlayMouseUp(o){if(document.querySelector("sp-overlay[open]")){this.overlayMouseDownTarget=null;return}o.target===o.currentTarget&&this.overlayMouseDownTarget===o.currentTarget&&this.closeForm(),this.overlayMouseDownTarget=null}startDetecting(){this.detecting=!0}handleActionChange(o){const t=o.target;this.formAction=t.value;const e=this.actions.find(r=>r.value===this.formAction);e!=null&&e.params?this.formParams=e.params.map(r=>r.defaultValue):this.formParams=[]}handleParamChange(o,t){const e=[...this.formParams];e[o]=t,this.formParams=e}toggleGroupButton(o){this.formGroupButtons.indexOf(o)>=0?this.formGroupButtons=this.formGroupButtons.filter(e=>e!==o):this.formGroupButtons=[...this.formGroupButtons,o]}saveRule(){this.config&&(this.formTargetType==="button"?this.saveButtonRule():this.formTargetType==="group"?this.saveGroupRule():this.formTargetType==="startup"&&this.saveStartupRule())}saveButtonRule(){if(!this.config)return;const o=this.buildActionDefinition(this.formAction,this.formParams);this.formMode==="add-action"?this.config.addRule({button:this.formButton,action:o,trigger:this.formTrigger,name:this.formName||void 0}):this.formMode==="edit-action"&&this.editingId&&this.config.updateRule(this.editingId,{button:this.formButton,action:o,trigger:this.formTrigger,name:this.formName||void 0}),this.dispatchConfigChange(),this.closeForm()}saveGroupRule(){if(!this.config)return;const o={type:this.formGroupActionType,progression:this.formGroupProgression,octave:this.formGroupOctave};this.formMode==="add-action"?this.config.addGroupRule({groupId:this.formGroupId,name:this.formName||void 0,action:o,trigger:this.formGroupTrigger}):this.formMode==="edit-action"&&this.editingId&&this.config.updateGroupRule(this.editingId,{groupId:this.formGroupId,name:this.formName||void 0,action:o,trigger:this.formGroupTrigger}),this.dispatchConfigChange(),this.closeForm()}saveStartupRule(){if(!this.config)return;const o=this.buildActionDefinition(this.formAction,this.formParams);if(this.formMode==="add-action")this.config.addStartupRule({name:this.formName||"Unnamed Startup Rule",action:o});else if(this.formMode==="edit-action"&&this.editingId){const t=this.config.startupRules.find(e=>e.id===this.editingId);t&&(t.name=this.formName||"Unnamed Startup Rule",t.action=o)}this.dispatchConfigChange(),this.closeForm()}saveGroup(){this.config&&(this.formMode==="add-group"?this.config.addGroup({name:this.formGroupName||"Unnamed Group",buttons:this.formGroupButtons}):this.formMode==="edit-group"&&this.editingId&&this.config.updateGroup(this.editingId,{name:this.formGroupName||"Unnamed Group",buttons:this.formGroupButtons}),this.dispatchConfigChange(),this.closeForm())}deleteRule(o){this.config&&(this.config.removeRule(o),this.dispatchConfigChange())}deleteGroup(o){if(!this.config)return;const t=this.config.getGroupRuleForGroup(o);t&&this.config.removeGroupRule(t.id),this.config.removeGroup(o),this.dispatchConfigChange()}deleteGroupRule(o){this.config&&(this.config.removeGroupRule(o),this.dispatchConfigChange())}deleteStartupRule(o){this.config&&(this.config.removeStartupRule(o),this.dispatchConfigChange())}openAddAction(){this.openAddActionForm()}openAddGroup(){this.openAddGroupForm()}isRuleTriggered(o){return this.triggeredActions.has(o)}renderActionsListContent(){var s,a,c,u;const o=((s=this.config)==null?void 0:s.rules)??[],t=((a=this.config)==null?void 0:a.groupRules)??[],e=((c=this.config)==null?void 0:c.startupRules)??[],r=((u=this.config)==null?void 0:u.groups)??[],i=o.length>0||t.length>0||e.length>0;return n`
      <div class="rules-list">
        ${i?n`
              ${o.map(d=>{var m;return n`
                  <div class="rule-item">
                    <span class="status-dot ${this.isRuleTriggered(d.id)?"active":""}"></span>
                    <span class="rule-type-badge button">Button</span>
                    <span class="rule-button-id">${wt(d.button,(m=this.config)==null?void 0:m.buttonNames)}</span>
                    <span class="rule-arrow">→</span>
                    <span class="rule-action">${this.formatAction(d.action)}</span>
                    <span class="rule-trigger">${d.trigger??"release"}</span>
                    ${d.name?n`<span class="rule-name">${d.name}</span>`:""}
                    <div class="rule-actions">
                      <sp-action-button size="s" quiet @click=${()=>this.openEditButtonRuleForm(d)}>
                        <sp-icon-edit slot="icon"></sp-icon-edit>
                      </sp-action-button>
                      <sp-action-button size="s" quiet @click=${()=>this.deleteRule(d.id)}>
                        <sp-icon-delete slot="icon"></sp-icon-delete>
                      </sp-action-button>
                    </div>
                  </div>
                `})}
              ${t.map(d=>{const m=r.find($=>$.id===d.groupId);return n`
                  <div class="rule-item">
                    <span class="status-dot ${this.isRuleTriggered(d.id)?"active":""}"></span>
                    <span class="rule-type-badge group">Group</span>
                    <span class="rule-button-id">${(m==null?void 0:m.name)??"Unknown Group"}</span>
                    <span class="rule-arrow">→</span>
                    <span class="rule-action">${d.action.type}: ${d.action.progression} (Oct ${d.action.octave})</span>
                    ${d.name?n`<span class="rule-name">${d.name}</span>`:""}
                    <div class="rule-actions">
                      <sp-action-button size="s" quiet @click=${()=>this.openEditGroupRuleForm(d)}>
                        <sp-icon-edit slot="icon"></sp-icon-edit>
                      </sp-action-button>
                      <sp-action-button size="s" quiet @click=${()=>this.deleteGroupRule(d.id)}>
                        <sp-icon-delete slot="icon"></sp-icon-delete>
                      </sp-action-button>
                    </div>
                  </div>
                `})}
              ${e.map(d=>n`
                  <div class="rule-item">
                    <span class="status-dot active permanent"></span>
                    <span class="rule-type-badge startup">Startup</span>
                    <span class="startup-icon">⚡</span>
                    <span class="rule-action">${d.name}: ${this.formatAction(d.action)}</span>
                    <div class="rule-actions">
                      <sp-action-button size="s" quiet @click=${()=>this.openEditStartupRuleForm(d)}>
                        <sp-icon-edit slot="icon"></sp-icon-edit>
                      </sp-action-button>
                      <sp-action-button size="s" quiet @click=${()=>this.deleteStartupRule(d.id)}>
                        <sp-icon-delete slot="icon"></sp-icon-delete>
                      </sp-action-button>
                    </div>
                  </div>
                `)}
            `:n`<div class="empty-state">No actions configured</div>`}
      </div>
    `}renderActionsList(){return n`
      <div class="panel">
        <div class="section-header">
          <span class="section-title">Actions</span>
          <sp-action-button size="s" quiet @click=${()=>this.openAddActionForm()}>
            <sp-icon-add slot="icon"></sp-icon-add>
            Add Action
          </sp-action-button>
        </div>
        ${this.renderActionsListContent()}
      </div>
    `}renderGroupsListContent(){var t;const o=((t=this.config)==null?void 0:t.groups)??[];return n`
      <div class="rules-list">
        ${o.length===0?n`<div class="empty-state">No button groups configured</div>`:o.map(e=>n`
                <div class="group-item">
                  <div class="group-header">
                    <span class="group-name">${e.name}</span>
                    <div class="rule-actions">
                      <sp-action-button size="s" quiet @click=${()=>this.openEditGroupForm(e)}>
                        <sp-icon-edit slot="icon"></sp-icon-edit>
                      </sp-action-button>
                      <sp-action-button size="s" quiet @click=${()=>this.deleteGroup(e.id)}>
                        <sp-icon-delete slot="icon"></sp-icon-delete>
                      </sp-action-button>
                    </div>
                  </div>
                  <div class="group-buttons">
                    ${e.buttons.map(r=>{var s;const i=this.pressedButtons.has(r);return n`<span class="button-chip ${i?"pressed":""}"
                        >${wt(r,(s=this.config)==null?void 0:s.buttonNames)}</span
                      >`})}
                  </div>
                </div>
              `)}
      </div>
    `}renderGroupsList(){return n`
      <div class="panel">
        <div class="section-header">
          <span class="section-title">Button Groups</span>
          <sp-action-button size="s" quiet @click=${this.openAddGroupForm}>
            <sp-icon-add slot="icon"></sp-icon-add>
            Add Group
          </sp-action-button>
        </div>
        ${this.renderGroupsListContent()}
      </div>
    `}renderParamFields(){const o=this.actions.find(t=>t.value===this.formAction);return o!=null&&o.params?o.params.map((t,e)=>{const r=this.formParams[e]??t.defaultValue;return t.type==="select"&&t.options?n`
          <div class="form-field">
            <sp-field-label>${t.label}</sp-field-label>
            <sp-picker value="${r}" @change=${i=>this.handleParamChange(e,i.target.value)}>
              ${t.options.map(i=>n`<sp-menu-item value="${i.value}">${i.label}</sp-menu-item>`)}
            </sp-picker>
          </div>
        `:t.type==="number"?n`
          <div class="form-field">
            <sp-field-label>${t.label}</sp-field-label>
            <sp-number-field
              value="${r}"
              min="${t.min}"
              max="${t.max}"
              step="${t.step}"
              @change=${i=>this.handleParamChange(e,Number(i.target.value))}
            ></sp-number-field>
          </div>
        `:n`
        <div class="form-field">
          <sp-field-label>${t.label}</sp-field-label>
          <sp-textfield value="${r}" @change=${i=>this.handleParamChange(e,i.target.value)}></sp-textfield>
        </div>
      `}):""}handleTargetTypeChange(o){const t=o.target.value;this.formTargetType=t,this.formAction="none",this.formParams=[],this.formGroupActionType="chord-progression",this.formGroupProgression="c-major-pop",this.formGroupOctave=4,this.formGroupTrigger="release"}renderActionForm(){var i;const o=this.formMode==="edit-action",t=this.getAvailableButtons(),e=((i=this.config)==null?void 0:i.groups)??[],r=()=>{if(o)switch(this.formTargetType){case"button":return"Edit Button Action";case"group":return"Edit Group Action";case"startup":return"Edit Startup Action"}return"Add Action"};return n`
      <div class="form-overlay" @mousedown=${this.handleOverlayMouseDown} @mouseup=${this.handleOverlayMouseUp}>
        <div class="form-dialog" @scroll=${s=>s.stopPropagation()}>
          <div class="form-title">${r()}</div>

          <!-- Target Type Selector (only show when adding, not editing) -->
          ${o?"":n`
            <div class="form-field">
              <sp-field-label>Target Type</sp-field-label>
              <sp-picker value="${this.formTargetType}" @change=${this.handleTargetTypeChange}>
                <sp-menu-item value="button">Button</sp-menu-item>
                <sp-menu-item value="group" ?disabled=${e.length===0}>Group${e.length===0?" (create a group first)":""}</sp-menu-item>
                <sp-menu-item value="startup">Startup</sp-menu-item>
              </sp-picker>
            </div>
          `}

          <!-- Button-specific fields -->
          ${this.formTargetType==="button"?n`
            <div class="form-field">
              <sp-field-label>Button</sp-field-label>
              <div class="form-row">
                <sp-picker value="${this.formButton}" @change=${s=>this.formButton=s.target.value}>
                  ${t.map(s=>{var a;return n`<sp-menu-item value="${s}">${wt(s,(a=this.config)==null?void 0:a.buttonNames)}</sp-menu-item>`})}
                </sp-picker>
                <sp-button size="s" variant="secondary" class="${this.detecting?"detecting":""}" @click=${this.startDetecting}>
                  ${this.detecting?"Press a button...":"Detect"}
                </sp-button>
              </div>
            </div>

            <div class="form-field">
              <sp-field-label>Action</sp-field-label>
              <sp-picker value="${this.formAction}" @change=${this.handleActionChange}>
                ${this.actions.map(s=>n`<sp-menu-item value="${s.value}">${s.label}</sp-menu-item>`)}
              </sp-picker>
            </div>

            ${this.renderParamFields()}

            <div class="form-field">
              <sp-field-label>Trigger</sp-field-label>
              <sp-picker value="${this.formTrigger}" @change=${s=>this.formTrigger=s.target.value}>
                <sp-menu-item value="release">On Release (default)</sp-menu-item>
                <sp-menu-item value="press">On Press</sp-menu-item>
                <sp-menu-item value="hold">While Held</sp-menu-item>
              </sp-picker>
            </div>
          `:""}

          <!-- Group-specific fields -->
          ${this.formTargetType==="group"?n`
            <div class="form-field">
              <sp-field-label>Group</sp-field-label>
              <sp-picker value="${this.formGroupId}" @change=${s=>this.formGroupId=s.target.value}>
                ${e.map(s=>n`<sp-menu-item value="${s.id}">${s.name}</sp-menu-item>`)}
              </sp-picker>
            </div>

            <div class="form-field">
              <sp-field-label>Action Type</sp-field-label>
              <sp-picker value="${this.formGroupActionType}" @change=${s=>this.formGroupActionType=s.target.value}>
                <sp-menu-item value="chord-progression">Chord Progression</sp-menu-item>
              </sp-picker>
            </div>

            <div class="form-field">
              <sp-field-label>Chord Progression</sp-field-label>
              <select
                class="native-select"
                .value=${co(this.formGroupProgression)}
                @change=${s=>{this.formGroupProgression=s.target.value}}
              >
                ${this.progressionNames.map(s=>n`<option value="${s}" ?selected=${s===this.formGroupProgression}>${s}</option>`)}
              </select>
            </div>

            <div class="form-field">
              <sp-field-label>Octave</sp-field-label>
              <sp-number-field value="${this.formGroupOctave}" min="0" max="8" step="1" @change=${s=>this.formGroupOctave=Number(s.target.value)}></sp-number-field>
            </div>

            <div class="form-field">
              <sp-field-label>Trigger</sp-field-label>
              <sp-picker value="${this.formGroupTrigger}" @change=${s=>this.formGroupTrigger=s.target.value}>
                <sp-menu-item value="release">On Release (default)</sp-menu-item>
                <sp-menu-item value="press">On Press</sp-menu-item>
                <sp-menu-item value="hold">While Held</sp-menu-item>
              </sp-picker>
            </div>
          `:""}

          <!-- Startup-specific fields -->
          ${this.formTargetType==="startup"?n`
            <div class="form-field">
              <sp-field-label>Action</sp-field-label>
              <sp-picker value="${this.formAction}" @change=${this.handleActionChange}>
                ${this.actions.map(s=>n`<sp-menu-item value="${s.value}">${s.label}</sp-menu-item>`)}
              </sp-picker>
            </div>

            ${this.renderParamFields()}
          `:""}

          <!-- Common name field -->
          <div class="form-field">
            <sp-field-label>Name (optional)</sp-field-label>
            <sp-textfield placeholder="e.g., My Action" value="${this.formName}" @input=${s=>this.formName=s.target.value}></sp-textfield>
          </div>

          <div class="form-actions">
            <sp-button variant="secondary" @click=${this.closeForm}>Cancel</sp-button>
            <sp-button variant="accent" @click=${this.saveRule}>Save</sp-button>
          </div>
        </div>
      </div>
    `}renderGroupForm(){const o=this.formMode==="edit-group",t=this.getAvailableButtons();return n`
      <div class="form-overlay" @mousedown=${this.handleOverlayMouseDown} @mouseup=${this.handleOverlayMouseUp}>
        <div class="form-dialog">
          <div class="form-title">${o?"Edit Group":"Add Group"}</div>

          <div class="form-field">
            <sp-field-label>Group Name</sp-field-label>
            <sp-textfield placeholder="e.g., Main Chords" value="${this.formGroupName}" @input=${e=>this.formGroupName=e.target.value}></sp-textfield>
          </div>

          <div class="form-field">
            <sp-field-label>Buttons (click to toggle, or press on device)</sp-field-label>
            <div class="group-buttons">
              ${t.map(e=>{var s;const r=this.formGroupButtons.includes(e),i=this.pressedButtons.has(e);return n`
                  <span class="button-chip ${r?"selected":""} ${i?"detected":""}" @click=${()=>this.toggleGroupButton(e)} style="cursor: pointer">
                    ${wt(e,(s=this.config)==null?void 0:s.buttonNames)}
                  </span>
                `})}
            </div>
          </div>

          <div class="form-actions">
            <sp-button variant="secondary" @click=${this.closeForm}>Cancel</sp-button>
            <sp-button variant="accent" @click=${this.saveGroup}>Save</sp-button>
          </div>
        </div>
      </div>
    `}render(){const o=this.mode==="all"||this.mode==="actions",t=this.mode==="all"||this.mode==="groups";return n`
      <div class="config-section ${this.mode!=="all"?"single-panel":""}">
        ${this.mode==="all"?n`
          <div class="panels-row">
            ${this.renderActionsList()}
            ${this.renderGroupsList()}
          </div>
        `:n`
          ${o?this.renderActionsListContent():""}
          ${t?this.renderGroupsListContent():""}
        `}
        ${this.formMode==="add-action"||this.formMode==="edit-action"?this.renderActionForm():""}
        ${this.formMode==="add-group"||this.formMode==="edit-group"?this.renderGroupForm():""}
      </div>
    `}};g.styles=Zr;f([l({type:Object})],g.prototype,"config",2);f([l({type:String})],g.prototype,"mode",2);f([l({type:Object})],g.prototype,"pressedButtons",2);f([l({type:Number})],g.prototype,"buttonCount",2);f([l({type:Boolean})],g.prototype,"hasPrimaryButton",2);f([l({type:Boolean})],g.prototype,"hasSecondaryButton",2);f([l({type:Object})],g.prototype,"triggeredActions",2);f([p()],g.prototype,"formMode",2);f([p()],g.prototype,"editingId",2);f([p()],g.prototype,"detecting",2);f([p()],g.prototype,"formTargetType",2);f([p()],g.prototype,"formButton",2);f([p()],g.prototype,"formGroupId",2);f([p()],g.prototype,"formAction",2);f([p()],g.prototype,"formTrigger",2);f([p()],g.prototype,"formName",2);f([p()],g.prototype,"formParams",2);f([p()],g.prototype,"formGroupActionType",2);f([p()],g.prototype,"formGroupProgression",2);f([p()],g.prototype,"formGroupOctave",2);f([p()],g.prototype,"formGroupTrigger",2);f([p()],g.prototype,"formGroupName",2);f([p()],g.prototype,"formGroupButtons",2);g=f([J("action-rules-config")],g);const si=[{id:"tabletVisualizer",label:"Tablet",icon:"📱"},{id:"stylusVisualizer",label:"Stylus",icon:"✏️"},{id:"midiInput",label:"MIDI In",icon:"🎹"},{id:"events",label:"Events",icon:"📋"},{id:"noteVelocity",label:"Velocity",icon:"🎚️"},{id:"noteDuration",label:"Duration",icon:"⏱️"},{id:"pitchBend",label:"Pitch",icon:"🎵"},{id:"strummingSettings",label:"Strumming",icon:"🎸"},{id:"strumRelease",label:"Release",icon:"🔔"},{id:"actions",label:"Actions",icon:"⚡"},{id:"groups",label:"Groups",icon:"📦"}],qe="sketchatone-panel-visibility",Me={tabletVisualizer:!0,stylusVisualizer:!0,midiInput:!0,events:!0,noteVelocity:!0,noteDuration:!0,pitchBend:!0,strummingSettings:!0,strumRelease:!0,actions:!0,groups:!0};function ai(){try{const o=localStorage.getItem(qe);if(o){const t=JSON.parse(o);return{...Me,...t}}}catch(o){console.warn("Failed to load panel visibility:",o)}return{...Me}}function Ne(o){try{localStorage.setItem(qe,JSON.stringify(o))}catch(t){console.warn("Failed to save panel visibility:",t)}}var ni=Object.defineProperty,li=Object.getOwnPropertyDescriptor,Ze=(o,t,e,r)=>{for(var i=r>1?void 0:r?li(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&ni(t,e,i),i};let Pt=class extends U{constructor(){super(...arguments),this.visibility={}}handleToggle(o){this.dispatchEvent(new CustomEvent("panel-toggle",{detail:{panelId:o,visible:!this.visibility[o]},bubbles:!0,composed:!0}))}render(){return n`
      <div class="toggle-bar">
        ${si.map(o=>n`
          <button
            class="toggle-item ${this.visibility[o.id]?"visible":""}"
            @click=${()=>this.handleToggle(o.id)}
            title="${o.label}: ${this.visibility[o.id]?"Visible":"Hidden"}"
          >
            <span class="toggle-label">${o.label}</span>
            <span class="visibility-indicator"></span>
          </button>
        `)}
      </div>
    `}};Pt.styles=k`
    :host {
      display: block;
      width: 100%;
    }

    .toggle-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      padding: 12px 16px;
      background: var(--spectrum-gray-100);
      border-radius: 12px;
      border: 1px solid var(--spectrum-gray-200);
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      justify-content: center;
    }

    @media (max-width: 640px) {
      .toggle-bar {
        gap: 4px;
        padding: 8px;
      }
    }

    .toggle-item {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      border-radius: 6px;
      border: 1px solid var(--spectrum-gray-300);
      background: var(--spectrum-gray-75);
      cursor: pointer;
      transition: all 0.15s ease;
      font-size: 0.8rem;
      font-weight: 500;
      color: var(--spectrum-gray-700);
      user-select: none;
    }

    @media (max-width: 640px) {
      .toggle-item {
        padding: 4px 8px;
        font-size: 0.7rem;
        gap: 4px;
      }
    }

    .toggle-item:hover {
      background: var(--spectrum-gray-100);
      border-color: var(--spectrum-gray-400);
    }

    .toggle-item.visible {
      background: var(--spectrum-gray-200);
      border-color: var(--spectrum-gray-400);
      color: var(--spectrum-gray-900);
    }

    .toggle-item:not(.visible) {
      opacity: 0.6;
    }

    .toggle-label {
      white-space: nowrap;
    }

    .visibility-indicator {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--spectrum-gray-400);
      transition: background 0.15s ease;
    }

    .toggle-item.visible .visibility-indicator {
      background: var(--spectrum-positive-color-900);
    }
  `;Ze([l({type:Object})],Pt.prototype,"visibility",2);Pt=Ze([J("panel-toggle-bar")],Pt);function ci(o){const t=typeof o.x=="number"?o.x:0,e=typeof o.y=="number"?o.y:0,r=typeof o.pressure=="number"?o.pressure:0,i=typeof o.tiltX=="number"?o.tiltX:0,s=typeof o.tiltY=="number"?o.tiltY:0,a=Math.sqrt(i*i+s*s)*Math.sign(i*s||1);return{x:t,y:e,pressure:r,tiltX:i,tiltY:s,tiltXY:Math.min(1,Math.max(-1,a)),primaryButtonPressed:o.primaryButtonPressed??!1,secondaryButtonPressed:o.secondaryButtonPressed??!1,button:o.button,state:o.state}}function st(o,t=2){return o.toFixed(t)}class di{constructor(){this.callbacks=new Map}on(t,e){return this.callbacks.has(t)||this.callbacks.set(t,new Set),this.callbacks.get(t).add(e),e}once(t,e){const r=i=>{this.off(t,r),e(i)};return this.on(t,r),e}off(t,e){const r=this.callbacks.get(t);r&&r.delete(e)}emit(t,e){const r=this.callbacks.get(t);if(r)for(const i of r)i(e)}clear(t){t?this.callbacks.delete(t):this.callbacks.clear()}listenerCount(t){var e;return((e=this.callbacks.get(t))==null?void 0:e.size)??0}}class Fe extends di{constructor(t={}){super(),this.ws=null,this.reconnectAttempts=0,this.reconnectTimer=null,this._connectionState="disconnected",this._deviceStatus=null,this._config=null,this._lastTabletData={x:0,y:0,pressure:0,tiltX:0,tiltY:0,tiltXY:0,primaryButtonPressed:!1,secondaryButtonPressed:!1},this.url=t.url??"ws://localhost:8081",this.autoReconnect=t.autoReconnect??!0,this.reconnectDelay=t.reconnectDelay??2e3,this.maxReconnectAttempts=t.maxReconnectAttempts??10}get connectionState(){return this._connectionState}get config(){return this._config}get lastTabletData(){return this._lastTabletData}get isConnected(){return this._connectionState==="connected"}get deviceStatus(){return this._deviceStatus}get isDeviceConnected(){var t;return((t=this._deviceStatus)==null?void 0:t.deviceConnected)??!1}setUrl(t){this.url=t}connect(t){if(t&&(this.url=t),!(this.ws&&(this.ws.readyState===WebSocket.CONNECTING||this.ws.readyState===WebSocket.OPEN))){this.setConnectionState("connecting");try{this.ws=new WebSocket(this.url),this.ws.onopen=()=>{this.reconnectAttempts=0,this.setConnectionState("connected")},this.ws.onclose=()=>{this.setConnectionState("disconnected"),this.scheduleReconnect()},this.ws.onerror=e=>{const r=new Error("WebSocket error");this.emit("error",r),this.setConnectionState("error")},this.ws.onmessage=e=>{this.handleMessage(e.data)}}catch(e){this.setConnectionState("error"),this.emit("error",e instanceof Error?e:new Error(String(e))),this.scheduleReconnect()}}}disconnect(){this.autoReconnect=!1,this.cancelReconnect(),this.ws&&(this.ws.close(),this.ws=null),this.setConnectionState("disconnected")}setThrottle(t){this.send({type:"set-throttle",throttleMs:t})}setMode(t){this.send({type:"set-mode",mode:t})}updateConfig(t,e){this.send({type:"update-config",path:t,value:e})}saveConfig(){this.send({type:"save-config"})}loadConfig(t){this.send({type:"load-config",configName:t})}createConfig(t){this.send({type:"create-config",configName:t})}renameConfig(t,e){this.send({type:"rename-config",oldName:t,newName:e})}uploadConfig(t,e){this.send({type:"upload-config",configName:t,configData:e})}deleteConfig(t){this.send({type:"delete-config",configName:t})}onCombinedEvent(t){return this.on("combined",t),()=>this.off("combined",t)}onTabletEvent(t){return this.on("tablet",t),()=>this.off("tablet",t)}onStrumEvent(t){return this.on("strum",t),()=>this.off("strum",t)}onConnectionStateChange(t){return this.on("connection-state",t),()=>this.off("connection-state",t)}onConfig(t){return this.on("config",t),()=>this.off("config",t)}onModeChange(t){return this.on("mode-change",t),()=>this.off("mode-change",t)}onDeviceStatus(t){return this.on("device-status",t),()=>this.off("device-status",t)}onMidiInput(t){return this.on("midi-input",t),()=>this.off("midi-input",t)}onMidiInputStatus(t){return this.on("midi-input-status",t),()=>this.off("midi-input-status",t)}onActionEvent(t){return this.on("action-event",t),()=>this.off("action-event",t)}setConnectionState(t){this._connectionState!==t&&(this._connectionState=t,this.emit("connection-state",t))}send(t){this.ws&&this.ws.readyState===WebSocket.OPEN&&this.ws.send(JSON.stringify(t))}handleMessage(t){try{const e=JSON.parse(t);switch(e.type){case"tablet-data":this.handleCombinedEvent(e);break;case"tablet":e.data&&(this._lastTabletData=e.data,this.emit("tablet",e.data));break;case"strum":e.data&&this.emit("strum",e.data);break;case"mode-change":e.data&&e.data.mode&&this.emit("mode-change",e.data.mode);break;case"config":this._config=e.data,this.emit("config",e.data);break;case"status":this._deviceStatus={status:e.status,deviceConnected:e.deviceConnected,message:e.message,timestamp:e.timestamp},this.emit("device-status",this._deviceStatus);break;case"midi-input":this.emit("midi-input",{notes:e.notes??[],added:e.added,removed:e.removed,portName:e.portName,availablePorts:e.availablePorts??[],connectedPort:e.connectedPort??null});break;case"midi-input-status":this.emit("midi-input-status",{connected:e.connected??!1,availablePorts:e.availablePorts??[],connectedPort:e.connectedPort??null,currentNotes:e.currentNotes??[]});break;case"action-event":this.emit("action-event",{action:e.action??"",params:e.params??[],button:e.button,trigger:e.trigger,timestamp:e.timestamp??Date.now(),ruleId:e.ruleId,isStartup:e.isStartup});break}}catch(e){console.error("Failed to parse WebSocket message:",e)}}handleCombinedEvent(t){this._lastTabletData={x:t.x,y:t.y,pressure:t.pressure,tiltX:t.tiltX,tiltY:t.tiltY,tiltXY:t.tiltXY,primaryButtonPressed:t.primaryButtonPressed,secondaryButtonPressed:t.secondaryButtonPressed},this.emit("combined",t),this.emit("tablet",t),t.strum&&this.emit("strum",t.strum)}scheduleReconnect(){if(this.autoReconnect){if(this.maxReconnectAttempts>0&&this.reconnectAttempts>=this.maxReconnectAttempts){console.warn("Max reconnect attempts reached");return}this.cancelReconnect(),this.reconnectTimer=setTimeout(()=>{this.reconnectAttempts++,console.log(`Reconnecting... (attempt ${this.reconnectAttempts})`),this.connect()},this.reconnectDelay)}}cancelReconnect(){this.reconnectTimer&&(clearTimeout(this.reconnectTimer),this.reconnectTimer=null)}cleanup(){this.disconnect(),this.clear()}}function at(o,t,e=!1){return{notation:o,octave:t,secondary:e}}const E=class E{static indexOfNotation(t){let e=this.sharpNotations.indexOf(t);return e===-1&&(e=this.flatNotations.indexOf(t)),e}static notationAtIndex(t,e=!1){const r=t%this.sharpNotations.length;return e?this.flatNotations[r]:this.sharpNotations[r]}static midiToNotation(t){const e=t%this.sharpNotations.length;return this.sharpNotations[e]}static notationToMidi(t){const e=this.parseNotation(t);let r=this.sharpNotations.indexOf(e.notation);return r===-1&&(r=this.flatNotations.indexOf(e.notation),r===-1&&(r=0)),e.octave*this.sharpNotations.length+r}static sort(t){return[...t].sort((e,r)=>{const i=e.slice(-1).match(/\d/)?parseInt(e.slice(-1)):4,s=r.slice(-1).match(/\d/)?parseInt(r.slice(-1)):4,a=e.slice(-1).match(/\d/)?e.slice(0,-1):e,c=r.slice(-1).match(/\d/)?r.slice(0,-1):r;let u=this.sharpNotations.indexOf(a);u===-1&&(u=0);let d=this.sharpNotations.indexOf(c);return d===-1&&(d=0),i!==s?i-s:u-d})}static parseNotation(t){const e=t.slice(-1);let r,i;return/\d/.test(e)?(r=parseInt(e),t.length===3?i=t.slice(0,2):i=t[0]):(r=4,i=t),at(i,r)}static parseChord(t,e=4){let r,i;t.length>=2&&["#","b"].includes(t[1])?(r=t.slice(0,2),i=t.slice(2)):(r=t[0],i=t.slice(1)),i||(i="maj");let s=this.chordIntervals[i];s||(s=this.chordIntervals.maj);const a=this.parseNotation(r+e),c=this.indexOfNotation(a.notation),u=[];for(const d of s){const m=(c+d)%12,$=e+Math.floor((c+d)/12),w=this.sharpNotations[m];u.push(at(w,$))}return u}static fillNoteSpread(t,e=0,r=0){if(!t.length)return[];const i=[];for(let c=0;c<r;c++){const u=c%t.length,d=Math.floor(c/t.length);i.push(at(t[u].notation,t[u].octave+d+1,!0))}const s=[];for(let c=0;c<e;c++){const u=c%t.length,d=Math.floor(c/t.length),m=t.length-1-u;s.push(at(t[m].notation,t[m].octave-d-1,!0))}const a=[...s,...t,...i];return a.sort((c,u)=>E.noteToMidi(c)-E.noteToMidi(u)),a}static transpose(t,e){if(e===0)return{...t};let r=this.sharpNotations.indexOf(t.notation);r===-1&&(r=this.flatNotations.indexOf(t.notation),r===-1&&(r=0));const s=t.octave*12+r+e,a=Math.floor(s/12),c=s%12;let u;return t.notation.includes("#")?u=this.sharpNotations[c]:t.notation.includes("b")?u=this.flatNotations[c]:u=this.sharpNotations[c],at(u,a,t.secondary)}static noteToMidi(t){let e=this.sharpNotations.indexOf(t.notation);return e===-1&&(e=this.flatNotations.indexOf(t.notation),e===-1&&(e=0)),t.octave*12+e}static noteToString(t){return`${t.notation}${t.octave}`}};E.keys={},E.commonNotations=["C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"],E.sharpNotations=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"],E.flatNotations=["C","Db","D","Eb","E","F","Gb","G","Ab","A","Bb","B"],E.oddNotations=["B#","Cb","E#","Fb"],E.correctedNotations=["C","C","F","F"],E.chordIntervals={maj:[0,4,7],min:[0,3,7],m:[0,3,7],dim:[0,3,6],aug:[0,4,8],sus2:[0,2,7],sus4:[0,5,7],5:[0,7],7:[0,4,7,10],maj7:[0,4,7,11],min7:[0,3,7,10],m7:[0,3,7,10],dim7:[0,3,6,9],aug7:[0,4,8,10],maj9:[0,4,7,11,14],min9:[0,3,7,10,14],m9:[0,3,7,10,14],9:[0,4,7,10,14],add9:[0,4,7,14],6:[0,4,7,9],min6:[0,3,7,9],m6:[0,3,7,9]};let Dt=E;var ui=Object.defineProperty,hi=Object.getOwnPropertyDescriptor,y=(o,t,e,r)=>{for(var i=r>1?void 0:r?hi(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&ui(t,e,i),i};let b=class extends U{constructor(){super(),this.appTitle="Sketchatone Dashboard",this.themeColor="light",this.websocketConnected=!1,this.websocketUrl=typeof window<"u"?`ws://${window.location.hostname}:8081`:"ws://localhost:8081",this.websocketServerInfo="",this.tabletData={x:0,y:0,pressure:0,tiltX:0,tiltY:0,tiltXY:0,primaryButtonPressed:!1,secondaryButtonPressed:!1},this.pressedButtons=new Set,this.lastPressedButton=null,this.tabletEvents=[],this.lastStrumEvent=null,this.packetCount=0,this.strummerConfig=null,this.availableConfigs=[],this.showNewConfigDialog=!1,this.showRenameConfigDialog=!1,this.newConfigName="",this.savedConfigSnapshot=null,this.panelVisibility=ai(),this.serverMidiConnected=!1,this.serverMidiNotes=[],this.lastMidiPortName=null,this.serverVersion=null,this.triggeredActions=new Map,this.uiVersion="0.1.0",this.client=new Fe}get actionsConfigRef(){return this.renderRoot.querySelector("#actions-config")}get groupsConfigRef(){return this.renderRoot.querySelector("#groups-config")}connectedCallback(){super.connectedCallback(),this.setupClient()}disconnectedCallback(){super.disconnectedCallback(),this.client.cleanup()}setupClient(){this.client.onConnectionStateChange(o=>{this.websocketConnected=o==="connected",o==="disconnected"&&(this.websocketServerInfo="",this.strummerConfig=null,this.serverVersion=null)}),this.client.onConfig(o=>{var t;this.websocketServerInfo=`${((t=o.notes)==null?void 0:t.length)??0} strings`,this.strummerConfig=o,this.serverVersion=o.serverVersion??null,this.currentConfigName=o.currentConfigName,this.availableConfigs=o.availableConfigs??[],o.isSavedState&&(this.savedConfigSnapshot=o.config?JSON.stringify(o.config):null)}),this.client.onCombinedEvent(o=>{this.handleTabletData(o)}),this.client.onMidiInputStatus(o=>{this.serverMidiConnected=o.connected,this.serverMidiNotes=o.currentNotes.map(t=>Dt.parseNotation(t))}),this.client.onMidiInput(o=>{this.serverMidiNotes=o.notes.map(t=>Dt.parseNotation(t)),this.lastMidiPortName=o.portName??null,this.serverMidiConnected=!0}),this.client.onActionEvent(o=>{if(o.ruleId){const t=new Map(this.triggeredActions);t.set(o.ruleId,o.timestamp),this.triggeredActions=t,o.isStartup||setTimeout(()=>{if(this.triggeredActions.get(o.ruleId)===o.timestamp){const r=new Map(this.triggeredActions);r.delete(o.ruleId),this.triggeredActions=r}},1e3)}})}handleTabletData(o){this.packetCount++,this.tabletData=ci(o),this.pressedButtons=this.extractButtonsFromData(o),this.pressedButtons.size>0&&(this.lastPressedButton=Array.from(this.pressedButtons)[0]);const t=this.tabletData.pressure>0;W.setTabletPosition(this.tabletData.x,this.tabletData.y,t),W.setTiltPosition(this.tabletData.tiltX,this.tabletData.tiltY,this.tabletData.pressure,t,this.tabletData.tiltXY),W.setPrimaryButton(this.tabletData.primaryButtonPressed),W.setSecondaryButton(this.tabletData.secondaryButtonPressed);const e={timestamp:Date.now(),x:this.tabletData.x,y:this.tabletData.y,pressure:this.tabletData.pressure,tiltX:this.tabletData.tiltX,tiltY:this.tabletData.tiltY,tiltXY:this.tabletData.tiltXY,primaryButtonPressed:this.tabletData.primaryButtonPressed,secondaryButtonPressed:this.tabletData.secondaryButtonPressed,state:o.state};for(let r=1;r<=30;r++){const i=`button${r}`;o[i]!==void 0&&(e[`button${r}`]=o[i])}o.strum&&(e.strum=o.strum,this.lastStrumEvent=o.strum),this.tabletEvents=[...this.tabletEvents,e].slice(-50)}handleWebSocketUrlChange(o){const t=o.target;this.websocketUrl=t.value}connectWebSocket(){this.client instanceof Fe&&this.client.connect(this.websocketUrl)}disconnectWebSocket(){this.client.disconnect(),this.resetData()}renderConnectionStatus(){return this.websocketConnected?n`
        <div class="connection-group">
          <div class="status-badge connected">
            <span class="status-dot"></span>
            ${this.websocketServerInfo||"Connected"}
          </div>
          <sp-button data-spectrum-pattern="button-secondary-s" size="s" variant="secondary" @click=${this.disconnectWebSocket}>
            Disconnect
          </sp-button>
        </div>
      `:n`
      <div class="connection-group">
        <sp-textfield
          data-spectrum-pattern="textfield-s"
          size="s"
          placeholder="ws://localhost:8081"
          value=${this.websocketUrl}
          @input=${this.handleWebSocketUrlChange}
          style="width: 250px;">
        </sp-textfield>
        <sp-button data-spectrum-pattern="button-primary-s" size="s" variant="primary" @click=${this.connectWebSocket}>
          Connect
        </sp-button>
      </div>
    `}renderConfigDialogs(){return n`
      ${this.showNewConfigDialog?n`
        <sp-dialog-wrapper
          headline="New Configuration"
          dismissable
          underlay
          open
          @close=${()=>this.showNewConfigDialog=!1}>
          <div style="padding: 16px;">
            <sp-textfield
              label="Config Name"
              placeholder="my-config"
              value=${this.newConfigName}
              @input=${o=>this.newConfigName=o.target.value}
              @keydown=${o=>{o.key==="Enter"&&this.handleCreateConfig()}}>
            </sp-textfield>
            <div style="margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
              <sp-button variant="secondary" @click=${()=>this.showNewConfigDialog=!1}>Cancel</sp-button>
              <sp-button variant="primary" @click=${this.handleCreateConfig} ?disabled=${!this.newConfigName.trim()}>Create</sp-button>
            </div>
          </div>
        </sp-dialog-wrapper>
      `:""}
      ${this.showRenameConfigDialog?n`
        <sp-dialog-wrapper
          headline="Rename Configuration"
          dismissable
          underlay
          open
          @close=${()=>this.showRenameConfigDialog=!1}>
          <div style="padding: 16px;">
            <sp-textfield
              label="New Name"
              placeholder="my-config"
              value=${this.newConfigName}
              @input=${o=>this.newConfigName=o.target.value}
              @keydown=${o=>{o.key==="Enter"&&this.handleRenameConfig()}}>
            </sp-textfield>
            <div style="margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
              <sp-button variant="secondary" @click=${()=>this.showRenameConfigDialog=!1}>Cancel</sp-button>
              <sp-button variant="primary" @click=${this.handleRenameConfig} ?disabled=${!this.newConfigName.trim()}>Rename</sp-button>
            </div>
          </div>
        </sp-dialog-wrapper>
      `:""}
    `}handleExportConfig(){if(!this.fullConfig)return;const o=JSON.stringify(this.fullConfig,null,2),t=new Blob([o],{type:"application/json"}),e=URL.createObjectURL(t),r=document.createElement("a");r.href=e,r.download="strummer-config.json",r.click(),URL.revokeObjectURL(e)}handleSaveConfig(){this.client.saveConfig()}handleLoadConfig(o){this.client.loadConfig(o)}handleCreateConfig(){this.newConfigName.trim()&&(this.client.createConfig(this.newConfigName.trim()),this.newConfigName="",this.showNewConfigDialog=!1)}handleRenameConfig(){!this.currentConfigName||!this.newConfigName.trim()||(this.client.renameConfig(this.currentConfigName,this.newConfigName.trim()),this.newConfigName="",this.showRenameConfigDialog=!1)}handleConfigUpload(o){var i;const t=o.target,e=(i=t.files)==null?void 0:i[0];if(!e)return;const r=new FileReader;r.onload=s=>{var a;try{const c=JSON.parse((a=s.target)==null?void 0:a.result),u=e.name.replace(/\.json$/i,"")+".json";this.client.uploadConfig(u,c)}catch(c){console.error("[Dashboard] Failed to parse uploaded config:",c),alert("Failed to parse configuration file")}},r.readAsText(e),t.value=""}updateConfig(o,t){this.client.updateConfig(o,t)}resetData(){this.tabletData={x:0,y:0,pressure:0,tiltX:0,tiltY:0,tiltXY:0,primaryButtonPressed:!1,secondaryButtonPressed:!1},this.pressedButtons=new Set,this.lastPressedButton=null,this.tabletEvents=[],this.lastStrumEvent=null,this.packetCount=0}handleThemeToggle(){this.dispatchEvent(new CustomEvent("theme-toggle",{bubbles:!0,composed:!0}))}getLastPluckedStringIndex(){var e;if(!this.lastStrumEvent||!((e=this.strummerConfig)!=null&&e.notes))return null;const o=this.lastStrumEvent.notes[0];if(!o)return null;const t=this.strummerConfig.notes.findIndex(r=>r.notation===o.note.notation&&r.octave===o.note.octave);return t>=0?t:null}get fullConfig(){var o;return(o=this.strummerConfig)!=null&&o.config?this.strummerConfig.config:null}get hasUnsavedChanges(){var t;return!((t=this.strummerConfig)!=null&&t.config)||!this.savedConfigSnapshot?!1:JSON.stringify(this.strummerConfig.config)!==this.savedConfigSnapshot}extractButtonsFromData(o){const t=new Set,e=o;for(let r=1;r<=30;r++)e[`button${r}`]&&t.add(r);return t}handlePanelToggle(o){this.panelVisibility={...this.panelVisibility,[o.detail.panelId]:o.detail.visible},Ne(this.panelVisibility)}handlePanelClose(o){this.panelVisibility={...this.panelVisibility,[o]:!1},Ne(this.panelVisibility)}handleCurveConfigChange(o){const t=o.detail;for(const[e,r]of Object.entries(t))this.updateConfig(`strummer.${e}`,r)}handleCurveControlChange(o){const{parameterKey:t,control:e}=o.detail;this.updateConfig(`strummer.${t}.control`,e)}getActionRulesConfig(){var o,t;if((t=(o=this.fullConfig)==null?void 0:o.strummer)!=null&&t.actionRules)return St.fromDict(this.fullConfig.strummer.actionRules)}getPressedButtonIds(){const o=new Set;this.tabletData.primaryButtonPressed&&o.add("button:primary"),this.tabletData.secondaryButtonPressed&&o.add("button:secondary");for(const t of this.pressedButtons)o.add(`button:${t}`);return o}handleActionRulesConfigChange(o){const{actionRules:t}=o.detail;this.updateConfig("strummer.actionRules",t)}render(){var t,e,r,i,s,a,c,u,d,m,$,w,_,F,R,Q,tt,et,pt,ot,mt,rt,gt,bt,Tt,v,M,Ut,qt,Zt,Yt,Xt,Wt,Kt,Jt,Qt,te,ee,oe,re,ie,se,ae,ne,le,ce,de,ue,he,pe,me,ge,be,ve,fe,ye;const o=this.websocketConnected;return n`
      <div class="dashboard">
        <!-- Header -->
        <div class="dashboard-header">
          <div class="header-logo-container">
            <svg class="header-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 150">
              <rect class="logo-bg" y="0" width="400" height="150" rx="10" ry="10"/>
              <g>
                <path class="logo-title" d="M101.37,67.54c-.57-1.05-1.42-1.99-2.56-2.84-1.14-.84-2.42-1.52-3.85-2.03-1.42-.51-2.91-.89-4.46-1.15-4.6-.68-8.9-2.18-12.89-4.48-.34-.18-.71-.57-1.09-1.16-.39-.59-.58-1.16-.58-1.71,0-2,.34-4.02,1.01-6.03.67-2.02,1.53-3.59,2.58-4.73,1.69-1.89,4.72-3.54,9.11-4.96,4.39-1.41,9.33-2.12,14.82-2.12,3.28,0,5.82.25,7.6.75,1.79.5,2.68,1.28,2.68,2.32,0,1.71-.23,3.03-.7,3.96s-.97,1.55-1.5,1.86c-.54.31-1.48.72-2.82,1.25-1.44.5-2.68,1.03-3.74,1.57s-1.97,1.07-2.72,1.57c-.75.5-1.22.75-1.4.75-.23,0-.34-.09-.34-.27,0-.39.4-.97,1.21-1.76.81-.79,1.81-1.47,2.99-2.07,1.25-.66,1.88-1.08,1.88-1.26,0-.3-.7-.44-2.08-.44-4.22,0-8.11.38-11.69,1.13-3.58.75-6.4,1.74-8.46,2.97-2.06,1.23-3.09,2.48-3.09,3.76,0,.8.43,1.36,1.28,1.69s2.74.88,5.66,1.66c2.92.78,5.53,1.66,7.83,2.67,3.3,1.41,5.75,2.88,7.35,4.41,1.59,1.53,2.39,3.24,2.39,5.13,0,1.3-.31,2.6-.94,3.91-.63,1.31-1.54,2.51-2.75,3.61-1.21,1.09-2.6,1.99-4.17,2.7-1.34.57-3.04,1.1-5.08,1.61-2.04.5-4.25.89-6.63,1.18-2.38.28-4.65.43-6.82.43-3.99,0-7.19-.38-9.62-1.13s-3.64-1.89-3.64-3.42c0-.68.41-1.75,1.23-3.2s1.79-2.42,2.91-2.92c.98-.39,1.93-.61,2.84-.67.91-.06,1.37.05,1.37.33,0,.07-.03.14-.1.21s-.15.13-.24.17c-.09.05-.18.09-.27.14-.46.18-.83.32-1.11.43-.29.1-.51.21-.68.31-.17.1-.26.25-.26.43,0,.48,2.36.72,7.08.72,4.1,0,7.46-.15,10.08-.44,2.62-.3,4.93-.83,6.94-1.61,2-.77,3.83-1.85,5.47-3.21Z"/>
                <path class="logo-title" d="M136.99,66.65v2.29c-2.55,2.99-4.69,5.25-6.43,6.79-1.73,1.54-3.18,2.31-4.34,2.31s-2.12-.33-3.02-.99c-.9-.66-1.71-1.57-2.43-2.73s-1.57-2.78-2.55-4.85c-1.16,1.44-2.21,2.77-3.14,4.02-.93,1.24-1.58,2.07-1.95,2.48-.36.41-.7.62-.99.62-.62,0-1.06-.39-1.33-1.18-.27-.79-.41-1.93-.41-3.44,0-2.05.25-4.03.73-5.93s1.2-3.75,2.12-5.55c.92-1.8,2.11-3.74,3.55-5.83,1.45-2.08,3.07-4.27,4.87-6.54,2.48-3.14,4.63-5.71,6.43-7.71,1.8-1.99,3.37-3.5,4.7-4.51s2.44-1.52,3.33-1.52c1.09,0,1.64.49,1.64,1.47,0,.84-2.02,3.88-6.05,9.11-4.03,5.23-9.91,12.37-17.64,21.41v2.94c5.17-5.54,9.34-9.65,12.49-12.34,3.16-2.69,5.6-4.03,7.33-4.03.71,0,1.25.42,1.64,1.25.39.83.58,1.79.58,2.89,0,2.23-.96,4.3-2.87,6.2-1.91,1.9-4.85,4.08-8.82,6.55.68,1.03,1.29,1.77,1.81,2.24.52.47,1.18.7,1.98.7.71,0,1.47-.24,2.29-.72s1.66-1.08,2.51-1.81c.85-.73,2.17-1.91,3.95-3.55ZM123.49,68.39c.87-.57,1.94-1.45,3.23-2.65,1.29-1.2,2.39-2.44,3.3-3.73.91-1.29,1.37-2.36,1.37-3.23,0-.36-.16-.55-.48-.55-.87,0-2.35.83-4.46,2.5-2.11,1.66-4.16,3.79-6.17,6.39.87,0,1.94.42,3.21,1.26Z"/>
                <path class="logo-title" d="M142.25,67.88v.85c0,1.34.33,2.39.99,3.14.66.75,1.53,1.13,2.6,1.13s2.27-.26,3.47-.79c1.2-.52,2.39-1.22,3.57-2.08,1.18-.87,2.63-2.03,4.34-3.49v2.08c-2.58,3.1-4.99,5.47-7.25,7.13-2.26,1.65-4.55,2.48-6.87,2.48-2.03,0-3.63-.79-4.82-2.36-1.19-1.57-1.78-3.73-1.78-6.46,0-2.39.56-4.56,1.67-6.51,1.12-1.95,2.94-4,5.47-6.17,1.73-1.48,3.45-2.6,5.16-3.35s3.24-1.13,4.58-1.13c1.07,0,1.92.25,2.55.74.63.49.94,1.22.94,2.2,0,1.44-.54,2.87-1.61,4.29-1.07,1.42-2.71,2.84-4.9,4.24-2.2,1.4-4.9,2.75-8.12,4.05ZM142.6,65.66c2.05-.8,3.81-1.79,5.26-2.97,1.46-1.18,2.53-2.32,3.23-3.4.69-1.08,1.04-1.87,1.04-2.38s-.24-.79-.72-.79c-.41,0-1.08.26-2,.79-.92.52-1.86,1.21-2.8,2.05-.95.84-1.79,1.83-2.55,2.97-.75,1.14-1.24,2.38-1.47,3.73Z"/>
                <path class="logo-title" d="M169.22,48.91h1.47c1.21-2.16,2.3-3.7,3.28-4.6.98-.9,2.1-1.35,3.35-1.35s1.88.29,1.88.85c0,.27-.49,1.01-1.47,2.22-.98,1.21-1.72,2.22-2.22,3.04.77.09,1.46.17,2.07.24.6.07,1.08.13,1.42.17-1.3,2.42-2.93,4.89-4.89,7.42-.64-.04-1.17-.09-1.61-.12-.43-.04-.87-.07-1.32-.1-.44-.03-.99-.07-1.62-.12-1.23,1.98-2.26,3.75-3.09,5.31-.83,1.56-1.47,2.99-1.91,4.29s-.67,2.53-.67,3.69c0,1.57.63,2.36,1.88,2.36.87,0,2-.46,3.4-1.38,1.4-.92,3.28-2.34,5.62-4.25v2.29c-6.15,6.68-10.7,10.02-13.64,10.02-1.03,0-1.85-.4-2.48-1.2-.63-.8-.94-1.82-.94-3.08,0-.84.18-1.85.53-3.01.35-1.16.99-2.92,1.9-5.26-.32.27-.62.54-.91.8-.29.26-.55.5-.79.72s-.5.44-.77.68c-.27.24-.55.48-.82.73v-2.36c2.39-2,5.29-5.53,8.68-10.56-.34-.02-.66-.04-.96-.05-.3-.01-.65-.02-1.06-.02-1.34,0-2.35.09-3.01.27-.27.07-.53.14-.77.22s-.4.12-.5.12-.14-.07-.14-.21c0-.75.47-1.88,1.4-3.38.75-1.28,1.46-2.22,2.14-2.84.67-.62,1.49-1.03,2.46-1.25.97-.22,2.33-.32,4.08-.32Z"/>
                <path class="logo-title" d="M195.3,66.72v2.29c-2.44,2.39-4.43,4.25-5.96,5.57-1.54,1.32-2.97,2.35-4.31,3.08s-2.64,1.09-3.91,1.09-2.4-.5-3.45-1.49c-1.05-.99-1.87-2.29-2.46-3.9-.59-1.61-.89-3.31-.89-5.11,0-1.55.34-2.93,1.03-4.14.68-1.21,2-2.77,3.96-4.68,2.32-2.28,4.48-4.04,6.48-5.28,1.99-1.24,3.56-1.86,4.7-1.86.82,0,1.52.29,2.08.85.57.57.85,1.29.85,2.15,0,.73-.38,1.77-1.13,3.11-.75,1.34-1.6,2.51-2.53,3.5-.93.99-1.67,1.49-2.22,1.49-.59,0-.89-.32-.89-.96.02-.18.04-.35.05-.51.01-.16.02-.32.02-.48,0-.27-.1-.43-.29-.46-.19-.03-.43.05-.7.26-2.28,1.6-3.84,2.72-4.68,3.37-.84.65-1.51,1.31-2,1.97-.49.66-.73,1.36-.73,2.08,0,1.34.43,2.44,1.3,3.28.87.84,1.99,1.26,3.38,1.26s3.16-.55,5.18-1.66,4.39-2.72,7.13-4.84Z"/>
                <path class="logo-title" d="M220.73,66.65v2.15c-1.98,2.03-3.7,3.69-5.14,4.97-1.45,1.29-2.71,2.26-3.79,2.92-1.08.66-2,.99-2.75.99-1.78,0-2.67-1.05-2.67-3.15,0-1.69.55-3.64,1.66-5.86,1.1-2.22,2.69-4.84,4.77-7.84-1.03.57-1.99,1.23-2.91,1.97-.91.74-1.72,1.52-2.43,2.32-.71.81-1.3,1.5-1.78,2.07-1.48,1.66-2.91,3.37-4.27,5.11-1.37,1.74-2.29,2.88-2.77,3.4-.48.52-.93.79-1.37.79-1.78,0-2.67-2.19-2.67-6.56,0-1.44.22-3.02.65-4.75.43-1.73,1.59-4.02,3.49-6.87,3.99-5.97,7.4-10.85,10.24-14.65,2.84-3.79,5.19-6.67,7.06-8.61,1.87-1.95,3.12-2.9,3.76-2.85.8.07,1.44.23,1.93.48.49.25.73.54.73.85,0,.57-.39,1.51-1.18,2.82s-2.14,3.36-4.05,6.13c-2.07,2.94-3.54,5.01-4.41,6.2-.87,1.2-2.16,2.89-3.88,5.09s-3.29,4.16-4.72,5.88-3.05,3.58-4.87,5.59v4.1c3.05-3.39,5.7-6.17,7.93-8.34,2.23-2.16,4.12-3.8,5.67-4.9,1.55-1.11,2.69-1.66,3.42-1.66.68,0,1.32.41,1.91,1.21.59.81.89,1.48.89,2,0,.23-.11.51-.34.85-1.64,1.96-2.95,3.58-3.91,4.87-.97,1.29-1.71,2.44-2.24,3.45-.52,1.01-.79,1.89-.79,2.61,0,1.07.51,1.61,1.54,1.61,1.09,0,3.52-1.47,7.28-4.41Z"/>
                <path class="logo-title" d="M224.73,60.53c3.46-3.14,6.82-5.48,10.08-7.01,3.26-1.53,5.78-2.29,7.55-2.29.48,0,.92.2,1.33.6.41.4.73.86.97,1.38.24.52.36.91.36,1.16,0,.41-.16.71-.48.91-.32.19-.88.43-1.67.7.16.37.36.83.62,1.4.25.57.44,1.03.58,1.38s.21.67.21.94c0,.55-.55,1.57-1.66,3.06-1.11,1.49-1.88,2.59-2.32,3.3-.44.71-.67,1.57-.67,2.6,0,1.69.78,2.53,2.32,2.53s4.09-1.49,7.49-4.48v2.08c-5.77,6.4-9.89,9.6-12.37,9.6-.89,0-1.52-.29-1.9-.87-.38-.58-.56-1.44-.56-2.58,0-1.8.65-4.41,1.95-7.83-3.33,3.69-5.8,6.32-7.42,7.88-1.62,1.56-2.95,2.34-4,2.34-.5,0-1.13-.43-1.88-1.3-.75-.87-1.42-1.99-2-3.37-.58-1.38-.87-2.81-.87-4.29,0-1.07.1-1.96.31-2.68.21-.72.6-1.45,1.2-2.2.59-.75,1.54-1.74,2.84-2.97ZM241.1,56.77c-5.93,2.71-10.15,5.01-12.66,6.9-2.52,1.89-3.78,3.84-3.78,5.84,0,.73.12,1.33.38,1.79.25.47.59.7,1.03.7.25,0,.69-.16,1.33-.48,2.39-1.41,4.58-3.25,6.56-5.52s4.36-5.35,7.14-9.25Z"/>
                <path class="logo-title" d="M261.13,48.91h1.47c1.21-2.16,2.3-3.7,3.28-4.6.98-.9,2.1-1.35,3.35-1.35s1.88.29,1.88.85c0,.27-.49,1.01-1.47,2.22-.98,1.21-1.72,2.22-2.22,3.04.77.09,1.46.17,2.07.24.6.07,1.08.13,1.42.17-1.3,2.42-2.93,4.89-4.89,7.42-.64-.04-1.17-.09-1.61-.12-.43-.04-.87-.07-1.32-.1-.44-.03-.99-.07-1.62-.12-1.23,1.98-2.26,3.75-3.09,5.31-.83,1.56-1.47,2.99-1.91,4.29s-.67,2.53-.67,3.69c0,1.57.63,2.36,1.88,2.36.87,0,2-.46,3.4-1.38,1.4-.92,3.28-2.34,5.62-4.25v2.29c-6.15,6.68-10.7,10.02-13.64,10.02-1.03,0-1.85-.4-2.48-1.2s-.94-1.82-.94-3.08c0-.84.18-1.85.53-3.01s.99-2.92,1.9-5.26c-.32.27-.62.54-.91.8-.29.26-.55.5-.79.72s-.5.44-.77.68c-.27.24-.55.48-.82.73v-2.36c2.39-2,5.29-5.53,8.68-10.56-.34-.02-.66-.04-.96-.05-.3-.01-.65-.02-1.06-.02-1.35,0-2.35.09-3.01.27-.27.07-.53.14-.77.22s-.4.12-.5.12-.14-.07-.14-.21c0-.75.47-1.88,1.4-3.38.75-1.28,1.46-2.22,2.14-2.84.67-.62,1.49-1.03,2.46-1.25.97-.22,2.33-.32,4.08-.32Z"/>
                <path class="logo-title" d="M288.61,66.58v2.29c-1.5,1.37-2.71,2.28-3.62,2.73s-2.22.64-3.93.55c-2.96,3.51-5.57,5.26-7.83,5.26-1.28,0-2.44-.42-3.49-1.26-1.05-.84-1.89-1.99-2.51-3.45-.63-1.46-.94-3.09-.94-4.89,0-1.46.48-3.08,1.45-4.85s2.22-3.43,3.76-4.97c1.54-1.54,3.18-2.78,4.94-3.72,1.75-.95,3.38-1.42,4.89-1.42,1.07,0,1.91.17,2.53.5.62.33.92.79.92,1.38,0,.46-.26.98-.79,1.57.87.18,1.46.48,1.78.91.32.42.48,1.19.48,2.31s-.26,2.47-.77,4.14c-.51,1.66-1.21,3.22-2.1,4.68l.62.62h.51c.39,0,.77-.1,1.14-.29.38-.19.71-.4,1.01-.62.3-.22.95-.7,1.95-1.45ZM281.57,57.59c-1.89,1.14-3.51,2.17-4.85,3.09-1.35.92-2.48,1.86-3.42,2.8-.94.95-1.56,1.9-1.88,2.85-.57,2.55-.85,3.93-.85,4.14,0,1.5,1.05,2.26,3.14,2.26.98,0,2.62-.84,4.92-2.53-.39-1.07-.58-2.1-.58-3.08,0-1.44.3-2.9.89-4.39.59-1.49,1.47-3.21,2.63-5.14Z"/>
                <path class="logo-title" d="M311.58,60.46c-4.01,4.47-6.02,7.58-6.02,9.33,0,.98.4,1.47,1.2,1.47.66,0,1.52-.35,2.58-1.04,1.06-.69,2.72-1.93,4.97-3.71v2.36c-3.24,3.19-5.72,5.49-7.45,6.9-1.73,1.41-3.14,2.12-4.24,2.12-1.87,0-2.8-1.23-2.8-3.69,0-.73.11-1.45.34-2.15.23-.71.54-1.44.94-2.2s1.01-1.86,1.83-3.28,1.77-3.04,2.84-4.84c-1.3.66-2.93,1.97-4.89,3.93-1.28,1.23-2.36,2.4-3.25,3.5s-1.84,2.34-2.85,3.69c-1.01,1.36-1.75,2.27-2.22,2.73-.47.47-.94.7-1.42.7-.73,0-1.4-.76-2.02-2.29-.62-1.53-.92-3.3-.92-5.33,0-1.25.14-2.23.43-2.94.28-.71.85-1.71,1.69-3.01,1.57-2.42,2.93-4.19,4.07-5.31,1.14-1.13,2.23-1.69,3.28-1.69.73,0,1.32.13,1.76.38.44.25.67.64.67,1.16,0,.23-.07.47-.21.72-.14.25-.29.48-.46.68s-.53.6-1.08,1.2c-3.6,3.99-5.4,6.57-5.4,7.76,0,.66.22.99.65.99.27,0,.8-.44,1.59-1.32.79-.88,1.8-2.03,3.04-3.45s2.71-2.91,4.41-4.46c1.7-1.55,3.63-3.04,5.79-4.48,1.21-.84,2.21-1.26,3.01-1.26.36,0,.72.5,1.08,1.5.35,1,.53,2.02.53,3.04,0,.5-.49,1.26-1.47,2.29Z"/>
                <path class="logo-title" d="M319.58,67.88v.85c0,1.34.33,2.39.99,3.14.66.75,1.53,1.13,2.6,1.13s2.27-.26,3.47-.79c1.2-.52,2.39-1.22,3.57-2.08,1.19-.87,2.63-2.03,4.34-3.49v2.08c-2.58,3.1-4.99,5.47-7.25,7.13-2.26,1.65-4.55,2.48-6.87,2.48-2.03,0-3.63-.79-4.82-2.36-1.19-1.57-1.78-3.73-1.78-6.46,0-2.39.56-4.56,1.67-6.51,1.12-1.95,2.94-4,5.47-6.17,1.73-1.48,3.45-2.6,5.16-3.35s3.23-1.13,4.58-1.13c1.07,0,1.92.25,2.55.74.63.49.94,1.22.94,2.2,0,1.44-.54,2.87-1.61,4.29-1.07,1.42-2.71,2.84-4.9,4.24-2.2,1.4-4.9,2.75-8.12,4.05ZM319.92,65.66c2.05-.8,3.8-1.79,5.26-2.97,1.46-1.18,2.53-2.32,3.23-3.4.69-1.08,1.04-1.87,1.04-2.38s-.24-.79-.72-.79c-.41,0-1.08.26-2,.79-.92.52-1.86,1.21-2.8,2.05-.95.84-1.79,1.83-2.55,2.97-.75,1.14-1.24,2.38-1.47,3.73Z"/>
              </g>
              <path class="logo-line" fill="none" stroke-width="4" d="M50,89.5c100,6.67,200,6.67,300,0"/>
              <g>
                <path class="logo-subtitle" d="M40.52,123.74h-2.41l-.27,1.44h-2.81l2.7-12.6h3.17l2.7,12.6h-2.81l-.27-1.44ZM40.11,121.4l-.74-4.01-.05-.45-.05.45-.74,4.01h1.58Z"/>
                <path class="logo-subtitle" d="M52.91,116.72v6.16s.02.05.05.05h1.24s.05-.02.05-.05v-6.16h2.43v8.46h-2.39v-.83h-.04c-.13.56-.76.86-1.4.86h-.47c-1.21,0-1.91-.68-1.91-1.91v-6.59h2.43Z"/>
                <path class="logo-subtitle" d="M66.53,125.18c-1.03,0-1.73-.7-1.73-1.73v-4.48h-1.26v-2.25h1.26v-2.52h2.43v2.52h1.62v2.25h-1.62v3.91s.02.05.05.05h1.57v2.25h-2.32Z"/>
                <path class="logo-subtitle" d="M80.28,125.22h-2.75c-1.06,0-1.73-.7-1.73-1.73v-5.08c0-1.06.67-1.73,1.73-1.73h2.75c1.03,0,1.73.7,1.73,1.73v5.08c0,1.03-.7,1.73-1.73,1.73ZM79.53,118.97h-1.24s-.05.02-.05.05v3.85s.02.05.05.05h1.24s.05-.02.05-.05v-3.85s-.02-.05-.05-.05Z"/>
                <path class="logo-subtitle" d="M96.43,125.18v-6.16s-.02-.05-.05-.05h-.97s-.05.02-.05.05v6.16h-2.43v-6.16s-.02-.05-.05-.05h-.97s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.52c.63,0,1.26.31,1.39.86h.04c.13-.56.74-.86,1.39-.86h.56c1.06,0,1.73.72,1.73,1.76v6.73h-2.43Z"/>
                <path class="logo-subtitle" d="M109.97,125.18v-.68h-.04c-.14.49-.65.72-1.26.72h-.65c-1.17,0-1.87-.67-1.87-1.84v-1.6c0-1.28.67-1.82,1.82-1.82h.7c.61,0,1.12.2,1.26.68h.04l-.04-.68v-.94s-.02-.05-.05-.05h-3.12v-2.25h3.78c1.17,0,1.82.65,1.82,1.82v6.64h-2.4ZM109.88,121.58h-1.24s-.05.02-.05.05v1.42s.02.05.05.05h1.24s.05-.02.05-.05v-1.42s-.02-.05-.05-.05Z"/>
                <path class="logo-subtitle" d="M122.21,125.18c-1.03,0-1.73-.7-1.73-1.73v-4.48h-1.26v-2.25h1.26v-2.52h2.43v2.52h1.62v2.25h-1.62v3.91s.02.05.05.05h1.57v2.25h-2.32Z"/>
                <path class="logo-subtitle" d="M133.91,121.94v.94s.02.05.05.05h3.13v2.25h-3.89c-1.06,0-1.73-.7-1.73-1.73v-5.04c0-1.03.67-1.73,1.73-1.73h2.75c1.03,0,1.73.7,1.73,1.73v3.53h-3.78ZM135.26,118.84s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v1.48h1.35v-1.48Z"/>
                <path class="logo-subtitle" d="M148.88,125.18v-.83h-.04c-.13.56-.76.86-1.4.86h-.65c-1.03,0-1.73-.68-1.73-1.62v-5.29c0-.94.7-1.62,1.73-1.62h.65c.65,0,1.28.31,1.4.86h.04l-.04-.83v-4.14h2.43v12.6h-2.39ZM148.85,122.87v-3.85s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v3.85s.02.05.05.05h1.24s.05-.02.05-.05Z"/>
                <path class="logo-subtitle" d="M172.7,121.45l-3.73-3.67c-.43-.43-.72-1.08-.72-1.89v-1.44c0-1.13.76-1.91,1.91-1.91h3.38c1.13,0,1.91.77,1.91,1.91v2.18h-2.7v-1.48s-.02-.05-.05-.05h-1.69s-.05.02-.05.05v.77c0,.05.02.09.05.13l3.73,3.67c.43.43.72,1.08.72,1.89v1.69c0,1.13-.77,1.91-1.91,1.91h-3.38c-1.15,0-1.91-.77-1.91-1.91v-2.18h2.7v1.48s.02.05.05.05h1.69s.05-.02.05-.05v-1.03c0-.05-.02-.09-.05-.13Z"/>
                <path class="logo-subtitle" d="M187.33,125.22h-2.75c-1.06,0-1.73-.7-1.73-1.73v-5.08c0-1.03.67-1.73,1.73-1.73h2.75c1.03,0,1.73.7,1.73,1.73v1.94h-2.43v-1.33s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v3.85s.02.05.05.05h1.24s.05-.02.05-.05v-1.33h2.43v1.94c0,1.03-.7,1.73-1.73,1.73Z"/>
                <path class="logo-subtitle" d="M198.92,118.97s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.76v2.29h-2.11Z"/>
                <path class="logo-subtitle" d="M207.63,114.63c0-.79.67-1.46,1.46-1.46s1.46.67,1.46,1.46-.65,1.48-1.46,1.48-1.46-.67-1.46-1.48ZM207.88,125.18v-8.46h2.43v8.46h-2.43Z"/>
                <path class="logo-subtitle" d="M217.71,125.18v-12.6h2.43v4.14l-.04.83h.04c.13-.56.76-.86,1.4-.86h.65c1.03,0,1.73.68,1.73,1.73v5.08c0,1.04-.7,1.73-1.73,1.73h-.65c-.65,0-1.28-.31-1.4-.86h-.04v.83h-2.39ZM221.49,122.87v-3.85s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v3.85s.02.05.05.05h1.24s.05-.02.05-.05Z"/>
                <path class="logo-subtitle" d="M233.73,121.94v.94s.02.05.05.05h3.13v2.25h-3.89c-1.06,0-1.73-.7-1.73-1.73v-5.04c0-1.03.67-1.73,1.73-1.73h2.75c1.03,0,1.73.7,1.73,1.73v3.53h-3.78ZM235.08,118.84s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v1.48h1.35v-1.48Z"/>
                <path class="logo-subtitle" d="M244.44,122.06v-2.25h4.61v2.25h-4.61Z"/>
                <path class="logo-subtitle" d="M255.98,125.18v-12.6h2.7v12.6h-2.7Z"/>
                <path class="logo-subtitle" d="M269.84,125.18v-6.16s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.65c1.03,0,1.73.68,1.73,1.73v6.77h-2.43Z"/>
                <path class="logo-subtitle" d="M284.15,125.22h-2.75c-1.06,0-1.73-.7-1.73-1.73v-1.19h2.43v.76s.02.05.05.05h1.24s.05-.02.05-.05v-.67s-.04-.07-.07-.09l-2.45-1.15c-.85-.4-1.26-.9-1.26-1.73v-1.01c0-1.03.67-1.73,1.73-1.73h2.75c1.03,0,1.73.67,1.73,1.73v1.1h-2.43v-.67s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v.52c0,.05.04.09.07.11l2.23,1.04c.99.47,1.48.97,1.48,1.76v1.21c0,1.03-.7,1.73-1.73,1.73Z"/>
                <path class="logo-subtitle" d="M295.72,125.18c-1.03,0-1.73-.7-1.73-1.73v-4.48h-1.26v-2.25h1.26v-2.52h2.43v2.52h1.62v2.25h-1.62v3.91s.02.05.05.05h1.57v2.25h-2.32Z"/>
                <path class="logo-subtitle" d="M307.48,118.97s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.76v2.29h-2.11Z"/>
                <path class="logo-subtitle" d="M318.87,116.72v6.16s.02.05.05.05h1.24s.05-.02.05-.05v-6.16h2.43v8.46h-2.39v-.83h-.04c-.13.56-.76.86-1.4.86h-.47c-1.21,0-1.91-.68-1.91-1.91v-6.59h2.43Z"/>
                <path class="logo-subtitle" d="M337.07,125.18v-6.16s-.02-.05-.05-.05h-.97s-.05.02-.05.05v6.16h-2.43v-6.16s-.02-.05-.05-.05h-.97s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.52c.63,0,1.26.31,1.39.86h.04c.13-.56.74-.86,1.39-.86h.56c1.06,0,1.73.72,1.73,1.76v6.73h-2.43Z"/>
                <path class="logo-subtitle" d="M349.31,121.94v.94s.02.05.05.05h3.13v2.25h-3.89c-1.06,0-1.73-.7-1.73-1.73v-5.04c0-1.03.67-1.73,1.73-1.73h2.75c1.03,0,1.73.7,1.73,1.73v3.53h-3.78ZM350.66,118.84s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v1.48h1.35v-1.48Z"/>
                <path class="logo-subtitle" d="M364.25,125.18v-6.16s-.02-.05-.05-.05h-1.24s-.05.02-.05.05v6.16h-2.43v-8.46h2.39v.83h.04c.13-.56.76-.86,1.4-.86h.65c1.03,0,1.73.68,1.73,1.73v6.77h-2.43Z"/>
                <path class="logo-subtitle" d="M376.53,125.18c-1.03,0-1.73-.7-1.73-1.73v-4.48h-1.26v-2.25h1.26v-2.52h2.43v2.52h1.62v2.25h-1.62v3.91s.02.05.05.05h1.57v2.25h-2.32Z"/>
              </g>
            </svg>
          </div>
          <div class="header-content">
            <div class="header-row">
              <div class="header-controls">
                <sp-action-button
                  data-spectrum-pattern="action-button-quiet"
                  quiet
                  @click=${this.handleThemeToggle}
                  aria-label=${this.themeColor==="light"?"Switch to dark mode":"Switch to light mode"}>
                  ${this.themeColor==="light"?n`<sp-icon-moon slot="icon"></sp-icon-moon>`:n`<sp-icon-light slot="icon"></sp-icon-light>`}
                </sp-action-button>
              </div>
            </div>
            <div class="connection-row">
              ${this.renderConnectionStatus()}
            </div>
            <div class="config-header">
              <span class="config-filename">${((t=this.currentConfigName)==null?void 0:t.replace(/\.json$/i,""))??"No config loaded"}</span>
            </div>
            <div class="config-separator"></div>
            <div class="config-row">
              <div class="config-management-group">
                ${this.availableConfigs.length>0?n`
                  <sp-picker
                    size="s"
                    label="Config"
                    value=${this.currentConfigName??""}
                    ?disabled=${!this.websocketConnected}
                    @change=${h=>this.handleLoadConfig(h.target.value)}>
                    ${this.availableConfigs.map(h=>n`
                      <sp-menu-item value=${h} ?selected=${h===this.currentConfigName}>${h}</sp-menu-item>
                    `)}
                  </sp-picker>
                `:""}
                <sp-button data-spectrum-pattern="button-primary-s" size="s" variant="primary" ?disabled=${!this.websocketConnected||!this.hasUnsavedChanges} @click=${this.handleSaveConfig}>
                  Save
                </sp-button>
                <sp-action-button size="s" quiet ?disabled=${!this.websocketConnected} @click=${()=>{this.newConfigName="",this.showNewConfigDialog=!0}} title="New Config">
                  <sp-icon-add slot="icon"></sp-icon-add>
                </sp-action-button>
                <sp-action-button size="s" quiet ?disabled=${!this.websocketConnected||!this.currentConfigName} @click=${()=>{var h;this.newConfigName=((h=this.currentConfigName)==null?void 0:h.replace(/\.json$/i,""))??"",this.showRenameConfigDialog=!0}} title="Rename Config">
                  <sp-icon-edit slot="icon"></sp-icon-edit>
                </sp-action-button>
                <input type="file" accept=".json" id="config-upload-input" style="display: none" @change=${this.handleConfigUpload}>
                <sp-button data-spectrum-pattern="button-secondary-s" size="s" variant="secondary" ?disabled=${!this.websocketConnected} @click=${()=>{var h,we;return(we=(h=this.shadowRoot)==null?void 0:h.querySelector("#config-upload-input"))==null?void 0:we.click()}}>
                  Import
                </sp-button>
                <sp-button data-spectrum-pattern="button-secondary-s" size="s" variant="secondary" ?disabled=${!this.fullConfig} @click=${this.handleExportConfig}>
                  Export
                </sp-button>
              </div>
            </div>
            ${this.renderConfigDialogs()}
            <div class="version-info">
              <span class="version-label">UI: v${this.uiVersion}</span>
              ${this.serverVersion?n`<span class="version-label">Server: v${this.serverVersion}</span>`:""}
            </div>
          </div>
        </div>

        ${o?n`
        <!-- Panel Toggle Bar -->
        <panel-toggle-bar
          .visibility=${this.panelVisibility}
          @panel-toggle=${this.handlePanelToggle}>
        </panel-toggle-bar>

        <!-- All Panels Grid -->
        <div class="panels-grid">
          <!-- Tablet Visualizer Panel -->
          ${this.panelVisibility.tabletVisualizer?n`
            <dashboard-panel title="Tablet Visualizer" panelId="tabletVisualizer" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("tabletVisualizer")}>
              <div class="visualizer-wrapper">
                <strum-visualizer
                  mode="tablet"
                  .socketMode=${o}
                  .tabletConnected=${o}
                  .externalTabletData=${this.tabletData}
                  .externalPressedButtons=${this.pressedButtons}
                  .stringCount=${((r=(e=this.strummerConfig)==null?void 0:e.notes)==null?void 0:r.length)??6}
                  .notes=${((i=this.strummerConfig)==null?void 0:i.notes)??[]}
                  .externalLastPluckedString=${this.getLastPluckedStringIndex()}>
                </strum-visualizer>
              </div>
              <div class="data-values compact">
                <div class="data-item">
                  <span class="data-label">X</span>
                  <span class="data-value ${this.tabletData.x===0?"zero":""}">${st(this.tabletData.x)}</span>
                </div>
                <div class="data-item">
                  <span class="data-label">Y</span>
                  <span class="data-value ${this.tabletData.y===0?"zero":""}">${st(this.tabletData.y)}</span>
                </div>
                <div class="data-item">
                  <span class="data-label">Btn</span>
                  <span class="data-value ${this.pressedButtons.size>0?"active":""}">${this.lastPressedButton!==null?this.lastPressedButton:"–"}</span>
                </div>
              </div>
            </dashboard-panel>
          `:""}

          <!-- Stylus Visualizer Panel -->
          ${this.panelVisibility.stylusVisualizer?n`
            <dashboard-panel title="Stylus Visualizer" panelId="stylusVisualizer" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("stylusVisualizer")}>
              <div class="visualizer-wrapper">
                <tablet-visualizer
                  mode="tilt"
                  .socketMode=${o}
                  .tabletConnected=${o}
                  .externalTabletData=${this.tabletData}
                  .externalPressedButtons=${this.pressedButtons}>
                </tablet-visualizer>
              </div>
              <div class="data-values compact">
                <div class="data-item">
                  <span class="data-label">Pressure</span>
                  <span class="data-value ${this.tabletData.pressure===0?"zero":""}">${st(this.tabletData.pressure)}</span>
                </div>
                <div class="data-item">
                  <span class="data-label">Tilt X</span>
                  <span class="data-value ${this.tabletData.tiltX===0?"zero":""}">${st(this.tabletData.tiltX)}</span>
                </div>
                <div class="data-item">
                  <span class="data-label">Tilt Y</span>
                  <span class="data-value ${this.tabletData.tiltY===0?"zero":""}">${st(this.tabletData.tiltY)}</span>
                </div>
              </div>
            </dashboard-panel>
          `:""}

          <!-- MIDI Input Panel -->
          ${this.panelVisibility.midiInput?n`
            <dashboard-panel title="MIDI Input" panelId="midiInput" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("midiInput")}>
              <div class="midi-panel-content">
                <div class="midi-status-row">
                  <div class="status-badge small ${this.serverMidiConnected?"connected":"disconnected"}">
                    <span class="status-dot"></span>
                    ${this.serverMidiConnected?"connected":"disconnected"}
                  </div>
                </div>
                <div class="midi-notes compact">
                  <span class="midi-notes-label">Notes:</span>
                  <span class="midi-notes-value">${this.serverMidiNotes.length>0?this.serverMidiNotes.map(h=>`${h.notation}${h.octave}`).join(", "):"—"}</span>
                </div>
                ${this.lastMidiPortName?n`
                  <div class="midi-source">from: ${this.lastMidiPortName}</div>
                `:""}
              </div>
            </dashboard-panel>
          `:""}

          <!-- Events Panel -->
          ${this.panelVisibility.events?n`
            <dashboard-panel title="Events" panelId="events" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("events")}>
              <strum-events-display
                .events=${this.tabletEvents}
                .isEmpty=${this.tabletEvents.length===0}
                .lastStrumEvent=${this.lastStrumEvent}
                .deviceInfo=${{packetCount:this.packetCount,isMock:!1,isTranslated:!0}}>
              </strum-events-display>
            </dashboard-panel>
          `:""}

          <!-- Note Velocity Panel -->
          ${this.panelVisibility.noteVelocity?n`
            <dashboard-panel title="Note Velocity" panelId="noteVelocity" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("noteVelocity")}>
              <curve-visualizer
                label="Note Velocity"
                parameterKey="noteVelocity"
                control="${((c=(a=(s=this.fullConfig)==null?void 0:s.strummer)==null?void 0:a.noteVelocity)==null?void 0:c.control)??"pressure"}"
                outputLabel="Velocity"
                color="#51cf66"
                .config=${((d=(u=this.fullConfig)==null?void 0:u.strummer)==null?void 0:d.noteVelocity)??{min:0,max:127,curve:4,spread:"direct",multiplier:1}}
                @config-change=${this.handleCurveConfigChange}
                @control-change=${this.handleCurveControlChange}>
              </curve-visualizer>
            </dashboard-panel>
          `:""}

          <!-- Note Duration Panel -->
          ${this.panelVisibility.noteDuration?n`
            <dashboard-panel title="Note Duration" panelId="noteDuration" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("noteDuration")}>
              <curve-visualizer
                label="Note Duration"
                parameterKey="noteDuration"
                control="${((w=($=(m=this.fullConfig)==null?void 0:m.strummer)==null?void 0:$.noteDuration)==null?void 0:w.control)??"tiltXY"}"
                outputLabel="Duration"
                color="#f59f00"
                .config=${((F=(_=this.fullConfig)==null?void 0:_.strummer)==null?void 0:F.noteDuration)??{min:.15,max:1.5,curve:1,spread:"inverse",multiplier:1}}
                @config-change=${this.handleCurveConfigChange}
                @control-change=${this.handleCurveControlChange}>
              </curve-visualizer>
            </dashboard-panel>
          `:""}

          <!-- Pitch Bend Panel -->
          ${this.panelVisibility.pitchBend?n`
            <dashboard-panel title="Pitch Bend" panelId="pitchBend" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("pitchBend")}>
              <curve-visualizer
                label="Pitch Bend"
                parameterKey="pitchBend"
                control="${((tt=(Q=(R=this.fullConfig)==null?void 0:R.strummer)==null?void 0:Q.pitchBend)==null?void 0:tt.control)??"yaxis"}"
                outputLabel="Bend"
                color="#339af0"
                .config=${((pt=(et=this.fullConfig)==null?void 0:et.strummer)==null?void 0:pt.pitchBend)??{min:-1,max:1,curve:4,spread:"central",multiplier:1}}
                @config-change=${this.handleCurveConfigChange}
                @control-change=${this.handleCurveControlChange}>
              </curve-visualizer>
            </dashboard-panel>
          `:""}

          <!-- Strumming Settings Panel -->
          ${this.panelVisibility.strummingSettings?n`
            <dashboard-panel title="Strumming Settings" panelId="strummingSettings" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("strummingSettings")}>
              <div class="settings-form">
                <div class="setting-row">
                  <label>Pluck Velocity Scale</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((rt=(mt=(ot=this.fullConfig)==null?void 0:ot.strummer)==null?void 0:mt.strumming)==null?void 0:rt.pluckVelocityScale)??4}" step="0.1" min="0.1" max="10"
                    @change=${h=>this.updateConfig("strummer.strumming.pluckVelocityScale",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Pressure Threshold</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((Tt=(bt=(gt=this.fullConfig)==null?void 0:gt.strummer)==null?void 0:bt.strumming)==null?void 0:Tt.pressureThreshold)??.1}" step="0.01" min="0" max="1"
                    @change=${h=>this.updateConfig("strummer.strumming.pressureThreshold",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>MIDI Channel</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((Ut=(M=(v=this.fullConfig)==null?void 0:v.strummer)==null?void 0:M.strumming)==null?void 0:Ut.midiChannel)??1}" step="1" min="1" max="16"
                    @change=${h=>this.updateConfig("strummer.strumming.midiChannel",Number(h.target.value))}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Upper Note Spread</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((Yt=(Zt=(qt=this.fullConfig)==null?void 0:qt.strummer)==null?void 0:Zt.strumming)==null?void 0:Yt.upperNoteSpread)??3}" step="1" min="0" max="12"
                    @change=${h=>this.updateConfig("strummer.strumming.upperNoteSpread",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Lower Note Spread</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((Kt=(Wt=(Xt=this.fullConfig)==null?void 0:Xt.strummer)==null?void 0:Wt.strumming)==null?void 0:Kt.lowerNoteSpread)??3}" step="1" min="0" max="12"
                    @change=${h=>this.updateConfig("strummer.strumming.lowerNoteSpread",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Reverse Direction</label>
                  <sp-switch
                    data-spectrum-pattern="switch-s"
                    ?checked=${((te=(Qt=(Jt=this.fullConfig)==null?void 0:Jt.strummer)==null?void 0:Qt.strumming)==null?void 0:te.invertX)??!1}
                    @change=${h=>this.updateConfig("strummer.strumming.invertX",h.target.checked)}>
                  </sp-switch>
                </div>
              </div>
            </dashboard-panel>
          `:""}

          <!-- Strum Release Panel -->
          ${this.panelVisibility.strumRelease?n`
            <dashboard-panel title="Strum Release" panelId="strumRelease" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              .hasActiveControl=${!0}
              .active=${((re=(oe=(ee=this.fullConfig)==null?void 0:ee.strummer)==null?void 0:oe.strumRelease)==null?void 0:re.active)??!1}
              @active-change=${h=>this.updateConfig("strummer.strumRelease.active",h.detail.active)}
              @panel-close=${()=>this.handlePanelClose("strumRelease")}>
              <div class="settings-form">
                <div class="setting-row">
                  <label>MIDI Note</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((ae=(se=(ie=this.fullConfig)==null?void 0:ie.strummer)==null?void 0:se.strumRelease)==null?void 0:ae.midiNote)??38}" step="1" min="0" max="127"
                    @change=${h=>this.updateConfig("strummer.strumRelease.midiNote",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>MIDI Channel</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((ce=(le=(ne=this.fullConfig)==null?void 0:ne.strummer)==null?void 0:le.strumRelease)==null?void 0:ce.midiChannel)??10}" step="1" min="1" max="16"
                    @change=${h=>this.updateConfig("strummer.strumRelease.midiChannel",Number(h.target.value))}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Max Duration</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((he=(ue=(de=this.fullConfig)==null?void 0:de.strummer)==null?void 0:ue.strumRelease)==null?void 0:he.maxDuration)??.25}" step="0.05" min="0.05" max="2"
                    @change=${h=>this.updateConfig("strummer.strumRelease.maxDuration",h.target.value)}></sp-number-field>
                </div>
                <div class="setting-row">
                  <label>Velocity Multiplier</label>
                  <sp-number-field data-spectrum-pattern="number-field-s" value="${((ge=(me=(pe=this.fullConfig)==null?void 0:pe.strummer)==null?void 0:me.strumRelease)==null?void 0:ge.velocityMultiplier)??1}" step="0.1" min="0.1" max="2"
                    @change=${h=>this.updateConfig("strummer.strumRelease.velocityMultiplier",h.target.value)}></sp-number-field>
                </div>
              </div>
            </dashboard-panel>
          `:""}

          <!-- Actions Panel -->
          ${this.panelVisibility.actions?n`
            <dashboard-panel title="Actions" panelId="actions" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("actions")}>
              <sp-action-button slot="header-actions" size="s" quiet @click=${()=>{var h;return(h=this.actionsConfigRef)==null?void 0:h.openAddAction()}}>
                <sp-icon-add slot="icon"></sp-icon-add>
              </sp-action-button>
              <action-rules-config
                id="actions-config"
                mode="actions"
                .config=${this.getActionRulesConfig()}
                .pressedButtons=${this.getPressedButtonIds()}
                .triggeredActions=${this.triggeredActions}
                .buttonCount=${((ve=(be=this.strummerConfig)==null?void 0:be.deviceCapabilities)==null?void 0:ve.buttonCount)??8}
                .hasPrimaryButton=${!0}
                .hasSecondaryButton=${!0}
                @config-change=${this.handleActionRulesConfigChange}
              ></action-rules-config>
            </dashboard-panel>
          `:""}

          <!-- Groups Panel -->
          ${this.panelVisibility.groups?n`
            <dashboard-panel title="Groups" panelId="groups" .closable=${!0} .draggable=${!1} .minimizable=${!1}
              @panel-close=${()=>this.handlePanelClose("groups")}>
              <sp-action-button slot="header-actions" size="s" quiet @click=${()=>{var h;return(h=this.groupsConfigRef)==null?void 0:h.openAddGroup()}}>
                <sp-icon-add slot="icon"></sp-icon-add>
              </sp-action-button>
              <action-rules-config
                id="groups-config"
                mode="groups"
                .config=${this.getActionRulesConfig()}
                .pressedButtons=${this.getPressedButtonIds()}
                .buttonCount=${((ye=(fe=this.strummerConfig)==null?void 0:fe.deviceCapabilities)==null?void 0:ye.buttonCount)??8}
                .hasPrimaryButton=${!0}
                .hasSecondaryButton=${!0}
                @config-change=${this.handleActionRulesConfigChange}
              ></action-rules-config>
            </dashboard-panel>
          `:""}


        </div>
        `:n`
          <div class="disconnected-message">
            <p>Connect to a WebSocket server to view strummer data</p>
          </div>
        `}
      </div>
    `}};b.styles=mo;y([l({type:String,attribute:"app-title"})],b.prototype,"appTitle",2);y([l({type:String})],b.prototype,"themeColor",2);y([p()],b.prototype,"websocketConnected",2);y([p()],b.prototype,"websocketUrl",2);y([p()],b.prototype,"websocketServerInfo",2);y([p()],b.prototype,"tabletData",2);y([p()],b.prototype,"pressedButtons",2);y([p()],b.prototype,"lastPressedButton",2);y([p()],b.prototype,"tabletEvents",2);y([p()],b.prototype,"lastStrumEvent",2);y([p()],b.prototype,"packetCount",2);y([p()],b.prototype,"strummerConfig",2);y([p()],b.prototype,"currentConfigName",2);y([p()],b.prototype,"availableConfigs",2);y([p()],b.prototype,"showNewConfigDialog",2);y([p()],b.prototype,"showRenameConfigDialog",2);y([p()],b.prototype,"newConfigName",2);y([p()],b.prototype,"panelVisibility",2);y([p()],b.prototype,"serverMidiConnected",2);y([p()],b.prototype,"serverMidiNotes",2);y([p()],b.prototype,"lastMidiPortName",2);y([p()],b.prototype,"serverVersion",2);y([p()],b.prototype,"triggeredActions",2);b=y([J("sketchatone-dashboard")],b);var pi=Object.defineProperty,mi=Object.getOwnPropertyDescriptor,Ye=(o,t,e,r)=>{for(var i=r>1?void 0:r?mi(t,e):t,s=o.length-1,a;s>=0;s--)(a=o[s])&&(i=(r?a(t,e,i):a(i))||i);return r&&i&&pi(t,e,i),i};let It=class extends U{constructor(){super(),this.themeColor="light";const o=localStorage.getItem("sketchatone-theme");o?this.themeColor=o:window.matchMedia("(prefers-color-scheme: dark)").matches&&(this.themeColor="dark"),this._updateDocumentBackground()}_updateDocumentBackground(){const o=this.themeColor==="dark"?"#1a1a1a":"#f5f7fa";document.documentElement.style.backgroundColor=o,document.body.style.backgroundColor=o,document.documentElement.classList.remove("light-theme","dark-theme"),document.documentElement.classList.add(`${this.themeColor}-theme`)}_toggleTheme(){this.themeColor=this.themeColor==="light"?"dark":"light",localStorage.setItem("sketchatone-theme",this.themeColor),this._updateDocumentBackground()}render(){return n`
      <sp-theme system="spectrum" color=${this.themeColor} scale="medium">
        <div class="app">
          <div class="page-content">
            <sketchatone-dashboard
              app-title="Sketchatone Dashboard"
              .themeColor=${this.themeColor}
              @theme-toggle=${this._toggleTheme}>
            </sketchatone-dashboard>
          </div>
        </div>
      </sp-theme>
    `}};It.styles=po;Ye([p()],It.prototype,"themeColor",2);It=Ye([J("sketchatone-tablet-app")],It);
